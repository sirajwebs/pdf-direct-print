/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved *copyright* FedEx 2018
 *
 * Typescript code in this page
 */
import { TokenService } from './../../services/token.service';
import { BookingService } from './../../services/booking.service';
import { SharedataService } from './../../services/sharedata.service';
import { LoginService } from './../../services/login.service';
import { Router } from '@angular/router';
import { Component, OnInit, ChangeDetectorRef, OnDestroy } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { ConstantsVAR, FedexTNT, FedexLoginConstants } from './../../shared/constants/constants-var';
import { ConstantsURL } from './../../shared/constants/constants-urls';
import { Subscription } from 'rxjs/Subscription';
import { AccountListDTO } from './../../shared/models/user.models';
import { JsEncoderService } from './../../services/js-encoder.service';
import { LoginResponseV2, AssociatedAccRequest, AssociatedAccounts, UserProfile } from './../../shared/models/login.models';
import { FedexLogonService } from './../../services/fedex-logon.service';
import { UserAccDetails, FedexAccounts } from './../../shared/models/login.models';
import { SharedFunctionsService } from 'app/services/shared-functions.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  providers: [LoginService, FedexLogonService, SharedFunctionsService]
})
export class LoginComponent implements OnInit, OnDestroy {

  loginTimeout: boolean;
  loginServerError: boolean;
  noAccount = false;
  loginApiError = '';
  apiCallCount = [];
  apiSubscription = [];

  loginForm = new FormGroup({
    userId: new FormControl('', Validators.required),
    pass: new FormControl('', [Validators.required]),
    rembr: new FormControl(''),
  });
  isLoggedIn = false;
  accountList = [];
  defaultAcc = '';
  subscriptions: Array<Subscription> = [];
  userAccountObject: Array<UserAccDetails> = [];

  constructor(private _router: Router,
    private _loginService: LoginService,
    private _jsEcd: JsEncoderService,
    private _shrdFnctns: SharedFunctionsService,
    private _fdxLogin: FedexLogonService,
    private _tokenSrvce: TokenService,
    private _sharedataService: SharedataService,
    private _cd: ChangeDetectorRef,
    private _bookingService: BookingService) {

    /**
     * when user timeout happened, check if idle session over, then show the error message.
     */
    if (sessionStorage.getItem('logoutFlag')) {
      if (sessionStorage.getItem('logoutFlag') === 'TIMEOUT') {
        this.loginTimeout = true;
      } else if (sessionStorage.getItem('logoutFlag') === 'ACTC' ||
        sessionStorage.getItem('logoutFlag') === 'FCL') {
        this.loginServerError = true;
      }
    }
  }

  ngOnInit() {
    document.getElementById('REMOVE_MODAL_BACKDROP').click();
    window.scrollTo(0, 0);
    this.loginForm.patchValue({ 'userId': '', 'pass': '' });
    this.getLastActiveUser();
    /**
     * when user refresh page , need to check this validation to detect if user
     *  is already logged in or not
     */

    this.subscriptions.push(this._sharedataService.loginDetailsMsg.subscribe((loginDetails) => {
      if (loginDetails) {
        if (loginDetails['userProfile']) {
          this._cd.detectChanges();
          this.isLoggedIn = true;
        } else {
          if (localStorage.getItem('isLoggedIn') === 'true') {
            this.isLoggedIn = false;
          }
        }
      }
    }));

    /**
    * check if the loggined user has account to show message
    */
    this.subscriptions.push(this._sharedataService.noAccountMsg.subscribe(data => {
      if (data === true) {
        this.noAccount = true;
        localStorage.setItem('noAccount', 'true');
        this._cd.detectChanges();
      } else if (localStorage.getItem('noAccount') === 'true') {
        this.noAccount = true;
        this._cd.detectChanges();
      }
    }));
    this.loginForm.get('pass').setValue('');
    this.loginForm.get('pass').markAsUntouched();
  }

  login() {
    /**
     * call fedex token then call on login functions on success
     */
    this.loginForm.get('userId').markAsTouched();
    this.loginForm.get('pass').markAsTouched();

    if (this.loginForm.value.userId && this.loginForm.value.pass) {
      this._loginService.deleteAllCookies();
      localStorage.setItem('isLoggedIn', '');
      const loginBody = {
        user: this.loginForm.get('userId').value,
        pass: this.loginForm.get('pass').value
      };

      const apiName = 'login';
      this.apiUnsubscribe(apiName);
      const tknPrprty = this._tokenSrvce.assignTokenCallProperty(ConstantsVAR.FEDEX_TOKEN_API);
      this._sharedataService.setLoaderSrvc(true);

      this.subscriptions.push(this.apiSubscription[apiName] =
        this._tokenSrvce.getToken(tknPrprty.clientID, tknPrprty.clientSecret, tknPrprty.tokenURL).subscribe((data) => {
          this._tokenSrvce.setToken(tknPrprty, data.access_token);
          this._sharedataService.setLoaderSrvc(false);
          this.loginCall(loginBody);
        }, error => {
          this.loginServerError = true;
          this.loginTimeout = false;
          this._sharedataService.setLoaderSrvc(false);
        }));
    }
  }

  loginCall(loginBody) {
    /**
     * validate the login data with fedex API
     */
    this.loginTimeout = false;
    this._sharedataService.setLoaderSrvc(true);
    const apiName = 'loginCall';
    this.apiUnsubscribe(apiName);
    this.subscriptions.push(this.apiSubscription[apiName] = this._loginService.postLogin(loginBody).subscribe((data) => {
      this.setRememberMeCookies();
      this.loginServerError = false;
      this._sharedataService.setLoaderSrvc(false);
      try {
        this.setSuccessfulLogin(data);
      } catch (error) {
        this.loginFailure();
      }
    }, (error) => {
      this._sharedataService.setLoaderSrvc(false);
      this.loginServerError = true;
      this.loginTimeout = false;
      this.serverErrorUser(error);
    }));
  }

  setRememberMeCookies() {
    if (this.loginForm.value.rembr === true) {
      document.cookie = ConstantsVAR.LAST_ACTIVE_ACCOUNT + '=' + this.loginForm.value.userId;
    } else {
      document.cookie = ConstantsVAR.LAST_ACTIVE_ACCOUNT + '=';
    }
  }

  serverErrorUser(error) {
    this.loginApiError = '';
      try {
      switch (error.status) {
        case ConstantsVAR.API_STATUS_CODE_500:
          const loginApiError = error._body.charAt(0) !== '<' ? JSON.parse(error._body).userMessage : '';
          this.loginApiError = 'Sorry! ' + loginApiError.replace('your local ', '');
          break;
        case ConstantsVAR.API_STATUS_CODE_400:
          this.incompleteUser(error);
          break;
        default: break;
      }
      } catch (err) { }
  }

  incompleteUser(error) {
    const apiErr = error._body.charAt(0) !== '<' ? JSON.parse(error._body).errors : [],
      filterErr = apiErr.filter(el => {
        let flag = false;
        for (const err of FedexLoginConstants.LOGIN_FAILURE_TYPE) {
          if (el.code.indexOf(err) > -1) {
            flag = true;
            break;
          }
        }
        return flag;
      });
    this.loginApiError = filterErr[0].message;
  }

  setSuccessfulLogin(data: LoginResponseV2) {
    this._sharedataService.setUserDetails(data.output);
    this.callAccounts(data);

    this._tokenSrvce.assignTokenCall(ConstantsVAR.ACCESS_TOKEN_API);
    this.isLoggedIn = true;
    localStorage.setItem('isLoggedIn', 'true');
    sessionStorage.removeItem('logoutFlag');
    this._fdxLogin.getFedexUserDetails();
  }

  loginFailure() {
    this.isLoggedIn = false;
    this._router.navigate(['/login']);
    this._sharedataService.setUserDetails(null);
    this.loginServerError = true;
  }

  callAccounts(val: LoginResponseV2) {
    /**
     * call the all account list and default account henceforth
     */
    const accntList: Array<FedexAccounts> = val.output.userProfile.expandedAccounts;

    if (accntList.length) {
      this.createFedexUser(val);
        for (let i = 0; i < accntList.length; i++) {
          const accntRqstBdy: AssociatedAccRequest = {
            accountNumber: accntList[i].account.accountNumber
          };
        this.getAccounts(accntRqstBdy, val, accntList.length, i);
        }
      this.setAccountNonAvailability(false);
      } else {
      this.setAccountNonAvailability(true);
    }
  }

  logout(flag) {
    /**
     * logout and delete localstorage and cookies
     */
    this._sharedataService.setLoaderSrvc(true);
    this.subscriptions.push(this._loginService.logout().subscribe((data) => {
      this.logoutHandling(flag);
    }, error => {
      this.logoutHandling(flag);
    }));
  }

  logoutHandling(flag) {
    this._sharedataService.setUserDetails(null);
    this.isLoggedIn = false;
    const rUrl = sessionStorage.getItem('returnEdiURL');
    this._sharedataService.setLoaderSrvc(false);
    this._loginService.deleteAllCookies();
    localStorage.clear();
    sessionStorage.clear();
    if (rUrl) { sessionStorage.setItem('returnEdiURL', rUrl); }
    sessionStorage.setItem('logoutFlag', flag);
    this._shrdFnctns.windowReload();
  }

  ngOnDestroy() {
    try {
      sessionStorage.removeItem('returnEdiURL');
    } catch (err) { }
    this._cd.detach();
    this.subscriptions.forEach((subscription: Subscription) => { subscription.unsubscribe(); });
    Object.keys(this.apiSubscription).forEach(apiName => { this.apiUnsubscribe(apiName); });
  }

  getAccounts(accntRqstBdy: AssociatedAccRequest, userVal: LoginResponseV2, accntListLength: number, i: number) {
    /**
     * get list of account from TNT account linked
     * check for unique account no. values
     */
    this._sharedataService.setLoaderSrvc(true);

    this.subscriptions.push(this._loginService.actc(accntRqstBdy).subscribe((data) => {
      const assocAccounts = data.output.associatedAccounts;
      if (assocAccounts) {
        for (const value of assocAccounts) {
          const acc = value.accountNumber.substr(ConstantsVAR.ACCOUNT_TRIM_POS);
        if (FedexLoginConstants.COMPANY_IDENTIFIER.includes(value.companyIdentifier)
            && this.accountList.indexOf(acc) === -1) {
            this.accountList.push(acc);
          this.createTNTuser(value, acc, accntRqstBdy, userVal);
          }
        }
      }
      this.onForkJoinActcCall(i, accntListLength);
    }, error => {
      this._sharedataService.setLoaderSrvc(false);
      this.logout('ACTC');
    }));
  }

  onForkJoinActcCall(i: number, accntListLength: number) {
    if (i === accntListLength - 1) {
      const accDetails = this.storeCustAccDetails();
      this.isBookingsExist(accDetails);
        }
      }

  setAccountNonAvailability(isAvalable: boolean) {
    this.noAccount = isAvalable;
    this._sharedataService.setNoAccount(isAvalable);
    localStorage.setItem('noAccount', isAvalable ? 'true' : '');
      }

  storeCustAccDetails() {
    /**
     * store the account details for fedex/tnt in localstorage
     * // TODO // this section will be updated based on fedex api integration
     */
    const accounts: Array<string> = [];
    let def = '';
    for (const acc of this.userAccountObject) {
      accounts.push(acc.cusAccId);
      if (acc.defAcc) { def = acc.cusAccId; }
    }
    const requestBody: AccountListDTO = {
      cAccNoLi: accounts
    };
    localStorage.setItem(ConstantsVAR.ACC_KEY, this._jsEcd.encode(JSON.stringify(requestBody))); // TODO delete
    localStorage.setItem(ConstantsVAR.DEF_ACC_KEY, this._jsEcd.encode(def)); // TODO delete
    this._sharedataService.setAccDetails(this.userAccountObject);
    return requestBody;
  }

  isBookingsExist(requestBody) {
    /**
    * check if booking is exist in the database, navigate based on the response.
    */

    if (sessionStorage.getItem('returnEdiURL')) {
      window.location.href = sessionStorage.getItem('returnEdiURL');
    } else {
      this._sharedataService.setLoaderSrvc(true);
      const apiName = 'isBookingsExist';
      this.apiUnsubscribe(apiName);

      this.subscriptions.push(this.apiSubscription[apiName] =
        this._bookingService.checkBkngAvailbility(requestBody).subscribe((val) => {
          this._sharedataService.setLoaderSrvc(false);
          if (val === 'true') {
            this._router.navigate(['/booking/dashboard']);
          } else if (val === 'false') {
            this._router.navigate(['/booking/wizard']);
          } else {
            this._router.navigate(['/login']);
          }
        }, error => {
          this._sharedataService.setLoaderSrvc(false);
        }));
    }
  }

  frgtPsswrd() {
    window.open(ConstantsURL.CONST_FORGOT_PASSWORD + ConstantsURL.CONST_LOCALE, '_blank');
  }

  getLastActiveUser() {
    /**
     * get the last active user from the browser cookies
     */
    const cookies = document.cookie.split(';');
    for (let i = 0; i < cookies.length; i++) {
      const cookie = cookies[i];
      const eqPos = cookie.indexOf('=');
      const name = eqPos > -1 ? cookie.substr(0, eqPos) : cookie;

      if (name === ConstantsVAR.LAST_ACTIVE_ACCOUNT) {
        const uName = cookie.split('=')[1] !== 'undefined' ? cookie.split('=')[1] : '';
        this.loginForm.patchValue({ 'userId': uName });
        if (this.loginForm.get('userId').value) {
          this.loginForm.get('rembr').setValue(true);
        }
      }
    }
  }

  apiUnsubscribe(apiName) {
    if (this.apiSubscription[apiName]) { this.apiSubscription[apiName].unsubscribe(); }
  }

  /**** FEDEX LOGIN INTEGRATION ****/


  createFedexUser(data: LoginResponseV2) {
    const userprofile = data.output.userProfile;
    for ( const user of userprofile.expandedAccounts){
      this.userAccountObject.push({
        ctryCd : userprofile.registeredContactAndAddress.address.countryCode,
        accTyp : FedexTNT.FDX,
        cusAccNm: user.account.accountDisplayName,
        cusAccId: user.account.accountNumber.key,
        defAcc: this.checkDefaultAccount(user.account, userprofile)
      });
    }
  }

  createTNTuser(data: AssociatedAccounts, acc: string, accntRqstBdy: AssociatedAccRequest, userVal: LoginResponseV2) {
   /* for TNT country code should be trimmed from account no e.g. NL000009845, NL is country code */
    const countryCode = data.accountNumber.substr(0, ConstantsVAR.ACCOUNT_TRIM_POS);

    this.resetFedexDefaultAccount();
    this.userAccountObject.push({
        ctryCd : countryCode,
        accTyp : FedexTNT.TNT,
      cusAccNm: data.displayName,
      cusAccId: acc,
      defAcc: this.checkDefaultAccount(accntRqstBdy, userVal.output.userProfile)
    });
    this._sharedataService.setAccDetails(this.userAccountObject); // store user here
  }

  resetFedexDefaultAccount() {
    for (const acc of this.userAccountObject) {
      if (acc.accTyp === FedexTNT.FDX && acc.defAcc) {
        acc.defAcc = false;
      }
    }
    }

  checkDefaultAccount(expaccnts: AssociatedAccRequest, userProfile: UserProfile): boolean {
    const isDef = (expaccnts.accountNumber.key === userProfile.defaultAccount.key) ? true : false;
    return isDef;
  }

  /**** FEDEX LOGIN INTEGRATION ****/
}

