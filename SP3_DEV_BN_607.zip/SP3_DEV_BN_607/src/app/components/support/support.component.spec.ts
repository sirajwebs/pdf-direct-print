/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved *copyright* FedEx 2018
 *
 * Typescript code in this page
 */

/**
 * testing required imports
 */
import { TestBed, async, ComponentFixture, fakeAsync, tick } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';
import { SupportListDTO } from './../../shared/models/supportList.models';

/**
 * components required imports
 */
import { CalltokenComponent } from './../../shared/calltoken/calltoken.component';
import { SupportComponent } from './support.component';
import { Router, Routes } from '@angular/router';
import { Component, OnInit, ViewChild, HostListener, OnDestroy, ChangeDetectorRef } from '@angular/core';
import { SharedataService } from './../../services/sharedata.service';
import { Subscription } from 'rxjs/Subscription';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { HttpModule, Http, RequestOptions } from '@angular/http';
import { HttpClient, HttpHeaders, HttpParams, HttpResponse, HttpRequest } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TextMaskPipe } from './../../shared/pipes/text-mask.pipe';



describe('SupportComponent', () => {
  let component: SupportComponent;
  let fixture: ComponentFixture<SupportComponent>;
  let debugElement: DebugElement;
  let htmlElement: HTMLElement;
  let http: Http;
  let HttpClient: HttpClient;

  const supportListData: SupportListDTO = {
        cNme: 'ALGERIA',
        lddn: '00213 560 95 68 50 ',
        nfa: ' 00213 560 95 68 50 ',
        extrnl: 'tnt.contact@falconexpress.dz',
        Checked: 'Feb-18'
  }

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ 
        SupportComponent,
        CalltokenComponent
      ],
      imports: [
        HttpModule,
        FormsModule,
        ReactiveFormsModule
      ],
      providers: [SharedataService]
    }).compileComponents();
    fixture = TestBed.createComponent(SupportComponent);
    debugElement = fixture.debugElement;
    fixture.autoDetectChanges();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SupportComponent);
    component = fixture.componentInstance;
    debugElement = fixture.debugElement;
    fixture.detectChanges();
  });

  it('should create the app', async(() => {
    expect(fixture.debugElement.componentInstance).toBeTruthy();
  }));
  
  it('should render title', () => {
    expect(fixture.debugElement.query(By.css('span.dashboard-text support-text'))
    .nativeElement.innerText).toEqual('Global Customer Support Contact Information');
  });

  it('should have table with columns: country name, local phone number, phone number from abroad, Email', () => {
    expect(document.getElementById('cntry_nm').innerHTML).toEqual('country name');
    expect(document.getElementById('lcl_ph_no').innerHTML).toEqual('local phone number');
    expect(document.getElementById('ph_no_ab').innerHTML).toEqual('phone number from abroad');
    expect(document.getElementById('eml').innerHTML).toEqual('Email');
  });

  it('should not render when data count is 0', () => {
    component.supportList.length = 0;
    fixture.detectChanges();
  });

  it('should render contact list when data is greater than 0', () => {
    component.supportList = [supportListData]
    fixture.detectChanges();
    expect(component.supportList.length).toBeGreaterThan(0);
    expect(document.getElementById('cNme0').innerHTML).toEqual(supportListData[0].cNme);
    expect(document.getElementById('lddn0').innerHTML).toEqual(supportListData[0].lddn);
    expect(document.getElementById('nfa0').innerHTML).toEqual(supportListData[0].nfa);
    expect(document.getElementById('extrnl0').innerHTML).toEqual(supportListData[0].extrnl);
  });
});
