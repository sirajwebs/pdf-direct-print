import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { SaveAddressBookComponent } from './save-address-book.component';
import { FormsModule,ReactiveFormsModule} from '@angular/forms';
import { DebugElement } from '@angular/core';
import { ToasterComponent } from '../toaster/toaster.component';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { FedexAddressbookService } from 'app/services/fedex-addressbook.service';
import { AddressFormData, AddressBookResponse, AddressRequestObject, AddressCopyData } from './../../models/addressbook.models';
import { SharedataService } from 'app/services/sharedata.service';
import { HttpModule, Http, RequestOptions } from '@angular/http';
import { HttpClient, HttpHeaders, HttpParams, HttpResponse, HttpRequest } from '@angular/common/http';
import { JsEncoderService } from 'app/services/js-encoder.service';
import * as addressbook from 'app/shared/models/addressbook.models';
import { Component, OnInit, Output, EventEmitter, OnDestroy, Input, OnChanges, SimpleChanges } from '@angular/core';
//import { AddressbookPrivilegeService } from 'app/services/privilege/addressbook-privilege.service';
import { of } from 'rxjs/observable/of'; 
describe('SaveAddressBookComponent', () => {
  let component: SaveAddressBookComponent;
  let fixture: ComponentFixture<SaveAddressBookComponent>;
  let debugElement: DebugElement;
  //let service:  AddressbookPrivilegeService;
    const mockaddressbook: addressbook.AddressBookDTO[] = [{
      name: 'testing' ,
      types: [],
      address_components: [],
  }];

  const mockdata: addressbook.AddressComponentDTO[] = [{
    long_name: 'Ab',
    short_name: 'Cd' ,
    types: []
  }];
  
  //const data = {personalCtrl: true, centralView: true, centralMod: true}
  //component.addressBookPrvlg = component.addressBookPrvlg['personalCtrl'];
  // beforeEach(async(() => {
  //     TestBed.configureTestingModule({
  //       declarations: [SaveAddressBookComponent, ToasterComponent],
  //       imports: [FormsModule,
  //                 ReactiveFormsModule,
  //                 HttpModule,
  //                ],
  //               providers: [{provide:FedexAddressbookService, useValue:mockaddressbook,mockdata},SharedataService,JsEncoderService]
  //     })
  //     .compileComponents();
  //     // fixture = TestBed.createComponent(SaveAddressBookComponent);
  //     // debugElement = fixture.debugElement;
  //     // fixture.autoDetectChanges();
  //   }));
  
  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [SaveAddressBookComponent, ToasterComponent],
      imports: [FormsModule,
                ReactiveFormsModule,
                HttpModule,
               ],
              providers: [FedexAddressbookService,SharedataService,JsEncoderService]
    })
    fixture = TestBed.createComponent(SaveAddressBookComponent);
    component = fixture.componentInstance;
    //component.addressBookPrvlg = component.addressBookPrvlg['personalCtrl']
   // service = TestBed.get(AddressbookPrivilegeService); 

    debugElement = fixture.debugElement;
    //fixture.detectChanges();

   });

   it('should be created', () => {
    expect(component).toBeTruthy();
   });
 
   it('Should show save address button', () => {
       spyOn(component,'privilegeCheck');
       component.showSaveAddrBkBtn();
       fixture.detectChanges();
       expect(component.privilegeCheck).toHaveBeenCalled();
     });
 
      it('should show suceessfull message', () => {
       spyOn(component,'closeModal');
     
       component.fromFedexAddressBook = [{
       addrIdFlag: undefined
       }]
   
       component.flashAddressSavedMsg();
        fixture.detectChanges();
        const val = component.fromFedexAddressBook;
       expect(val).toBeTruthy();
        expect(component.fromFedexAddressBook['addrIdFlag']).toBeUndefined;
       expect(component.closeModal).toHaveBeenCalled();
     });
 
 
       it('Should be enable save address book button', () => {
         spyOn(component,'addrBkRqrdFields');
         
         component.enableSaveAddrBkBtn();
         fixture.detectChanges();
         expect(component.addressBookPrvlg).toEqual('true');
         expect(component.addrBkRqrdFields).toHaveBeenCalled();
       });
 
       it('Reset all data', () => {
          component.resetAllData();
          fixture.detectChanges();
          expect(component.contactIdExists).toBeNull;
       });
 
 
       it('privillage check', () => {
         component.fromFedexAddressBook = {
           addrIdFlag :'p'
         }
 
         component.selectedAddrBkType = {
           d: "",
           p: "PERSONAL",
           r: "",
           s: ""
         }
        
         
         component.privilegeCheck();
         fixture.detectChanges();
         //expect(component.addressBookPrvlg['personalCtrl']).not.toBeNull();
         expect(component.addressBookPrvlg).toEqual('true');
      });
 
      it('should copy address book id', ()=>{
       spyOn(component,'fedexAddressValue');
       component.fedexAddrIDzCopied();
       fixture.detectChanges();
       expect(component.fedexAddressValue).toHaveBeenCalled();
      });
 
 
      it('should save in address book', () => {
     spyOn(component, 'fedexAddressValue')
     component.saveToAddressBook();
     fixture.detectChanges();
     expect(component.fedexAddressValue).toHaveBeenCalled();
     });
 
 
     it('should show error message', () => {
       spyOn(component, 'closeModal')
       const data = 'error'
       component.showError(data);
       fixture.detectChanges();
       expect(component.closeModal).toHaveBeenCalled();
     });
 
     it('should show fedex address value', () => {
       component.fromFedexAddressBook = [{
        addrIdFlag: ''
       }]
        component.fedexAddressValue();
        fixture.detectChanges();
        expect(component.saveAddrssFlag).toBeTruthy();
      });
 
     it('should update address', () => {
       component.updateAddress();
       fixture.detectChanges();
       expect(component.apiError).toBeFalsy();
   
     });
 
     it('should show addressbook required field', () => {
       component.addrBkRqrdFields();
       fixture.detectChanges();
       expect(component.formIsValidated).toBeTruthy();
     });
     
     it('should update email', () =>{
      const number = 12;
      const email = "test@gmail.com";
      component.updateEmail(number, email);
      fixture.detectChanges();
   });

   it('should not save address in address book', () =>{
    component.fromFedexAddressBook = [{
      nickName: ' '
      }]
    component.saveAddress();
    fixture.detectChanges();
    expect(component.apiError).toBe(false);
    expect(component.fromFedexAddressBook.markAsTouched).toBeTruthy();

 });

 it('should save address book', () =>{
  component.fromFedexAddressBook = [{
    nickName: 'nickname'
    }]
   component.saveAddress();
   fixture.detectChanges();
   });

  
it('should call initiateCopy', () =>{
   const a = false;
   const b = true;
   const c = function(){};
   component.fromFedexAddressBook = [{
    a :false
   }]
    component.initiateCopy(a, b, c);
    fixture.detectChanges();
    expect(component.fromFedexAddressBook['a']).toBe('false');
    });


    it('check difference', () => {
      const changes: SimpleChanges = {};
      component.ngOnChanges(changes);
      fixture.detectChanges();
      const checkDiff = component.initializeSameAsBtn(changes)
      expect(checkDiff).toBeTruthy();
    });
  
    it('should show save modal', () =>{
      component.showSaveModal();
      fixture.detectChanges();
      expect(component.showSaveModal).toBeFalsy();
    });
    
    it('should show error message while saving', () =>{
    component.saveAddress();
    fixture.detectChanges();
    expect(component.apiError).toBeTruthy();
    });

    it('should call close modal', () =>{
      component.closeModal() ;
      fixture.detectChanges();
      expect(component.closeModal).toBeTruthy();
    });

});
 