/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved *copyright* FedEx 2018
 *
 * Typescript code in this page
 */

import { UploadComponent } from './../upload-files/upload.component';
import { Component, OnInit, EventEmitter, Output, Input, OnChanges, SimpleChanges, ViewChild, OnDestroy } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Subscription } from 'rxjs/Subscription';
import {FORMS} from 'app/shared/constants/forms.properties';
@Component({
  selector: 'app-insurance-invoice',
  templateUrl: './insurance-invoice.component.html',
  styleUrls: ['./insurance-invoice.component.css']
})

export class InsuranceInvoiceComponent implements OnInit, OnChanges, OnDestroy {
  
  readonly FORMS = FORMS;
  public insurancesBody: any; // *** check datatypes
  fileName = '';
  afterUpload = true;
  disableBrowse = false;
  disableUpload = true;
  checkOrNot = null;
  templtFileSize = 0;
  invalidInvoice = false;
  invalidInsr = false;
  invoiceExceeds = false;
  insuranceValueError = false;
  invoiceValueError = false;
  subscriptions: Array<Subscription> = [];

  @Input() public readonlyField;
  @Input() public hideInsNull: boolean;
  @Input() public templateFileSize;
  @Input() public templateFileLength;
  @Input() public setInsrncDataFlag;
  @Input() public setInsrncDetails;
  @Input() public bookingFlag;
  @Input() public setFilesData;
  @Output() public getDocDetails = new EventEmitter<any>();
  @Output() public insrncValueChange = new EventEmitter<any>();
  @Output() public insuranceData = new EventEmitter<any>();
  @Output() public fileData = new EventEmitter<any>();
  @Output() public emitServiceInformationDetails = new EventEmitter<any>();
  @ViewChild(UploadComponent) public _upld: UploadComponent;

  insuranceForm = new FormGroup({
    goodsDescription: new FormControl('', Validators.required),
    invoiceValue: new FormControl('', [Validators.required,
    Validators.min(FORMS.INSURANCE.INVC_VAL.MIN), Validators.max(FORMS.INSURANCE.INVC_VAL.MAX)]),
    insuranceCurrency: new FormControl(FORMS.INSURANCE.INSRNC_CURR.DEFAULT),
    insuranceValue: new FormControl('', [Validators.min(FORMS.INSURANCE.INSRNC_VAL.MIN), Validators.max(FORMS.INSURANCE.INSRNC_VAL.MAX)]),
    invoiceCurrency: new FormControl(FORMS.INSURANCE.INVC_CURR.DEFAULT),
    uploadTextInvoice: new FormControl(FORMS.INSURANCE.UPLOAD_INVC_TEXT.DEFAULT),
    browseFile: new FormControl(FORMS.INSURANCE.BROWSE_FILE)
  });
  
  constructor() {
    this.subscriptions.push(this.insuranceForm.valueChanges.subscribe(formData => {
      if (!formData.invoiceValue) {
        formData.invoiceValue = null;
        this.insuranceBody();
      } else {
        this.insuranceBody();
      }
    }));
  }

  ngOnInit() {
    this.setInsrncDataFetch();
    if (this.templateFileSize) {
      this.templtFileSize = this.templateFileSize;
    }

    if (this.bookingFlag) {
      /**
       * check wheter user is in booking screen or template screen
       */
      this.checkOrNot = true;
    } else {
      this.checkOrNot = false;
      this.insuranceForm.get('goodsDescription').clearValidators();
      this.insuranceForm.get('goodsDescription').updateValueAndValidity();
      this.insuranceForm.get('invoiceValue').clearValidators();
      this.insuranceForm.get('invoiceValue').setValidators([Validators.min(FORMS.INSURANCE.INVC_VAL.MIN),
      Validators.max(FORMS.INSURANCE.INVC_VAL.MAX)]);
      this.insuranceForm.get('invoiceValue').updateValueAndValidity();
    }

    this.subscriptions.push(this.insuranceForm.valueChanges.subscribe(val => {
      Object.keys(this.insuranceForm.controls).forEach(key => {
        if (this.insuranceForm.get(key).dirty) {
          this.insrncValueChange.emit(true);
        }
      });

      const percentage = this.insuranceForm.get('invoiceValue').value * FORMS.INSURANCE.INSRNC_VAL.MAX_PERCENTAGE;
      /**
       * Insurance should not be more than 110% of Invoice
       */
      /*if (percentage < this.insuranceForm.get('insuranceValue').value) {
        this.invoiceExceeds = true;
      } else {
        this.invoiceExceeds = false;
      }*/

      this.invoiceExceeds = (percentage < this.insuranceForm.get('insuranceValue').value);
    }));
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes.setInsrncDetails) {
      if (changes.setInsrncDetails.previousValue !== changes.setInsrncDetails.currentValue) {
        this.setInsrncDataFetch();
      }
    }
  }

  ngOnDestroy() {
    this.subscriptions.forEach((subscription: Subscription) => { subscription.unsubscribe(); });
  }

  setInsrncDataFetch() {
    /**
     * set Insurance block data from booking screen
     * On view booking screen, set values and disable the fields
     */
    if (this.setInsrncDataFlag) {
      if (this.setInsrncDetails) {
        this.insuranceForm.patchValue({
          goodsDescription: this.setInsrncDetails.gDsc,
          invoiceValue: this.setInsrncDetails.invcV,
          invoiceCurrency: this.setInsrncDetails.invcC,
          insuranceValue: this.setInsrncDetails.insV,
          insuranceCurrency: this.setInsrncDetails.insC,
        });

        if (this.readonlyField) {
          /**
           * When viewing booking
           */
          this.insuranceForm.get('goodsDescription').clearValidators();
          this.insuranceForm.get('invoiceValue').clearValidators();
          this.insuranceForm.get('insuranceValue').clearValidators();

          this.insuranceForm.patchValue({
            invoiceValue: this.setInsrncDetails.invcV + ' ' + this.setInsrncDetails.invcC,
            insuranceValue: this.setInsrncDetails.insV + ' ' + this.setInsrncDetails.insC,
          });

          this.insuranceForm.get('goodsDescription').updateValueAndValidity();
          this.insuranceForm.get('invoiceValue').updateValueAndValidity();
          this.insuranceForm.get('insuranceValue').updateValueAndValidity();

          this.disableFieldsForView();
        }

      }
    }
  }

  checkInvalid(field) {
    /**
     * check whether insurance and invoice fields are Invalid
     */
    if (field === 'invoiceValue') {
      this.invalidInvoice = true;
    } else if (field === 'insuranceValue') {
      this.invalidInsr = true;
    }
  }

  setValid(field) {
    /**
     * set flag for valid insurance and invoice fields.
     */
    if (field === 'invoiceValue') {
      this.invalidInvoice = false;
    } else if (field === 'insuranceValue') {
      this.invalidInsr = false;
    }
  }

  checkDot(data, field) {
    /**
     * Check for invalid entry e.g (1.. / 0..1) and throw error
     */
    try {
      if (data.length === 1) {
        if (data === '.') {
          this.checkInvalid(field);
        }
      } else if (data.length > 1) {
        if (data.indexOf('..') > -1) {
          this.checkInvalid(field);
        } else {
          this.setValid(field);
        }
      } else {
        this.setValid(field);
      }
      if (+this.insuranceForm.get(field).value === 0) {
        this.insuranceForm.get(field).markAsPristine();
      }

    } catch (err) {
    }

  }

  insuranceBody() {
    /**
     * Skeleton of Insurance and invoice block, set values according to it.
     */
    let insuranceValueTemp: number;
    if (this.insuranceForm.value.insuranceValue) {
      insuranceValueTemp = this.insuranceForm.value.insuranceValue;
    }
    this.insurancesBody = {
      'goodsDesc': this.insuranceForm.value.goodsDescription,
      'invoiceVal': this.insuranceForm.value.invoiceValue,
      'invoiceValCurrency': this.insuranceForm.value.invoiceCurrency,
      'insuranceVal': insuranceValueTemp,
      'insuranceValCurrency': this.insuranceForm.value.insuranceCurrency,
    };
    this.insuranceData.emit(this.insurancesBody);
  }


  filesUploaded(files) {
    /**
     * show list of files uploaded
     */
    this.fileData.emit(files);
  }

  getDocs(val) {
    /**
     * Get attached documents from template / add or deleted documents from booking screen and display
     */
    if (val) {
      this.getDocDetails.emit(val);
    }
  }

  disableFieldsForView() {
    /**
     * Disable insurance and invoice block on view booking
     */
    Object.keys(this.insuranceForm.controls).forEach(key => {
      this.insuranceForm.get(key).disable();
    });
  }


  formValidation() {
    /**
     * insurance / invoice form validation
     * Implementation - Insurance is optional and Invoice is mandatory on booking screen. 
     * Implementation - Insurance as well as Invoice is not mandatory on template screen.
     * Implementation - Check invalid value, maximum and minimum values for insurance and invoice fields.
     */
    Object.keys(this.insuranceForm.controls).forEach(key => {
      if (key === 'insuranceValue') {
        if (+this.insuranceForm.get(key).value === 0) {
          this.insuranceForm.get(key).clearValidators();
          this.insuranceForm.get(key).updateValueAndValidity();
        } else {
          this.insuranceForm.get(key).setValidators([Validators.min(FORMS.INSURANCE.INSRNC_VAL.MIN),
          Validators.max(FORMS.INSURANCE.INSRNC_VAL.MAX)]);
          this.insuranceForm.get(key).updateValueAndValidity();
        }
      }
    });
    if (this.insuranceForm.invalid) {
      Object.keys(this.insuranceForm.controls).forEach(key => {
        if (this.insuranceForm.get(key).invalid) {
          this.insuranceForm.get(key).markAsTouched();
        }
      });
      return false;
    } else {
      if (!this.invalidInvoice && !this.invalidInsr && !this.invoiceExceeds) {
        return true;
      } else {
        return false;
      }
    }
  }

  resetUploadCmpnt() {
    /**
     * Reset Upload component
     */
    if (this._upld) { this._upld.resetAllData(); }
  }

}
