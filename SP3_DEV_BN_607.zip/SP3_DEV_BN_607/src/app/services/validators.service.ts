
/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved *copyright* FedEx 2018
 *
 * Typescript code in this page
 */
import { ValidatorFn, AbstractControl } from '@angular/forms';


export function MinMaxValue(min, max): ValidatorFn {
  return (control: AbstractControl): { [key: string]: any } => {
    const input = control.value;
    if (min < input && input > max) {
      return { 'MinMaxValue': { input } };
    } else {
      return null;
    }
  };
}
