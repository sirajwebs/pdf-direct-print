/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved *copyright* FedEx 2018
 *
 * Typescript code in this page
 */
import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/of';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
import 'rxjs/add/observable/throw';
import { ConstantsURL as Constants } from '../shared/constants/constants-urls';
import { BaseService } from './base.service';
import { ConstantsVAR } from './../shared/constants/constants-var';

@Injectable()
export class BookingService extends BaseService {
  constructor(private _http: Http) {
    super();
  }

  getBookingEditDetails(data): Observable<any> {
    return this._http
      .get(Constants.CONST_FETCH_BOOKING_EDIT_DETAILS_URL + data, this.setRequestOptions(ConstantsVAR.ACCESS_TOKEN))
      .map((res) => {
        return this.extractData(res);
      }).catch(this.handleError);
  }

  getBookingListDashboard(custAccNo): Observable<any> {
    const requestBody = {
      'cAccNoLi': custAccNo
    };
    return this._http
      .post(Constants.CONST_BOOKING_LIST_DASHBOARD_URL, requestBody, this.setRequestOptions(ConstantsVAR.ACCESS_TOKEN))
      .map((res) => {
        return this.extractData(res);
      }).catch(this.handleError);
  }

  getBookingListDashboardForASC(custAccNo, flag: boolean): Observable<any> {
    const requestBody = {
      'cAccNoLi': custAccNo,
      'tflg': flag
    };
    return this._http
      .post(Constants.CONST_ASC_DASHBOARD_1, requestBody, this.setRequestOptions(ConstantsVAR.ACCESS_TOKEN))
      .map((res) => {
        return this.extractData(res);
      }).catch(this.handleError);
  }

  getBookingListDashboardForCB(custAccNo): Observable<any> {
    const requestBody = {
      'cAccNoLi': custAccNo
    };
    return this._http
      .post(Constants.CONST_CMPLTE_BKNG_DASHBOARD, requestBody, this.setRequestOptions(ConstantsVAR.ACCESS_TOKEN))
      .map((res) => {
        return this.extractData(res);
      }).catch(this.handleError);
  }

  deleteBooking(data): Observable<any> {
    return this._http
      .delete(Constants.CONST_INBOUND_BOOKING + data + Constants.CONST_DELETE_SERVICE,
      this.setRequestOptions(ConstantsVAR.ACCESS_TOKEN))
      .map((res) => {
        return this.extractDataText(res);
      }).catch(this.handleError);
  }

  saveNewBooking(requestBody, fileVal): Observable<any> {
    const formData = new FormData();
    if (fileVal) {
      for (let i = 0; i < fileVal.length; i++) {
        formData.append('ip.file', fileVal[i]);
      }
    }
    formData.append('booking.json', JSON.stringify(requestBody));
    return this._http.post(Constants.CONST_SAVE_NEW_BOOKING_URL, formData,
    this.setRequestOptions(ConstantsVAR.ACCESS_TOKEN))
      .map((res) => {
        return this.extractDataText(res);
      }).catch(this.handleErrorMsg);
  }

  updateBooking(requestBody, fileVal): Observable<any> {
    const formData = new FormData();
    if (fileVal) {
      for (let i = 0; i < fileVal.length; i++) {
        formData.append('ip.file', fileVal[i]);
      }
    }
    formData.append('booking.json', JSON.stringify(requestBody));
    return this._http.post(Constants.CONST_UPDATE_BOOKING_URL, formData,
    this.setRequestOptions(ConstantsVAR.ACCESS_TOKEN))
      .map((res) => {
        return this.extractDataText(res);
      }).catch(this.handleErrorMsg);
  }

  saveAsDraftBooking(requestBody, fileVal): Observable<any> {
    const formData = new FormData();
    if (fileVal) {
      for (let i = 0; i < fileVal.length; i++) {
        formData.append('ip.file', fileVal[i]);
      }
    }
    formData.append('booking.json', JSON.stringify(requestBody));
    return this._http.post(Constants.CONST_SAVE_AS_DRAFT_BOOKING_URL, formData,
    this.setRequestOptions(ConstantsVAR.ACCESS_TOKEN))
      .map((res) => {
        return this.extractDataText(res);
      }).catch(this.handleError);
  }

  fetchServiceInformationDetails(data): Observable<any> {
    return this._http
      .post(Constants.CONST_DEFAULT_SERVICES, data, this.setRequestOptions(ConstantsVAR.ACCESS_TOKEN))
      .map((res) => {
        return this.extractDataNStatus(res);
      }).catch(this.handleError);
  }

  generateBookingReference(data): Observable<any> {
    return this._http
      .get(Constants.CONST_INBOUND_BOOKING + Constants.CONST_GENERATE_BOOKINGREF_URL + data,
      this.setRequestOptions(ConstantsVAR.ACCESS_TOKEN))
      .map((res) => {
        return this.extractDataText(res);
      }).catch(this.handleError);
  }

  getUniqueCustomrRef(tempCstmrRefno) {
    return this._http.get(Constants.CONST_INBOUND_BOOKING +
      Constants.CONST_CHECK_CUSTOMER_REF + tempCstmrRefno, this.setRequestOptions(ConstantsVAR.ACCESS_TOKEN))
      .map((res) => {
        return this.extractDataText(res);
      }).catch(this.handleError);
  }

  getUniqueCntntRef(tempCntntRef) {
    return this._http.get(Constants.CONST_INBOUND_BOOKING +
      Constants.CONST_CHECK_CONTENT_REF + tempCntntRef, this.setRequestOptions(ConstantsVAR.ACCESS_TOKEN))
      .map((res) => {
        return this.extractDataText(res);
      }).catch(this.handleError);
  }

  getConfirmPickUp(requestBody) {
    return this._http
      .post(Constants.CONST_CNF_DATE_PICKUP_URL, requestBody, this.setRequestOptions(ConstantsVAR.ACCESS_TOKEN))
      .map((res) => {
        return this.extractDataNStatus(res);
      }).catch(this.handleError);
  }

  getExpectedDueDate(requestBody) {
    return this._http
      .post(Constants.CONST_EXPECT_DUE_DT, requestBody, this.setRequestOptions(ConstantsVAR.ACCESS_TOKEN))
      .map((res) => {
        return this.extractData(res);
      }).catch(this.handleError);
  }

  checkBkngAvailbility(requestBody) {
    return this._http
      .post(Constants.CONST_BOOKING_EXISTS, requestBody, this.setRequestOptions(ConstantsVAR.ACCESS_TOKEN))
      .retryWhen(this.handleRetry)
      .map((res) => {
        return this.extractDataText(res);
      }).catch(this.handleError);
  }

  bookingSearch(data, accLi: Array<any>) {
    const requestBody = {
      'key': data,
      'accNumDto': {
        'cAccNoLi': accLi
      }
    };

    return this._http.post(Constants.CONST_BOOKING_SEARCH, requestBody, this.setRequestOptions(ConstantsVAR.ACCESS_TOKEN))
      .map((res) => {
        return this.extractDataNStatus(res);
      }).catch(this.handleError);
  }

  uploadBookingFile(body, fileVal, fileName): Observable<any> {
    const requestBody = {
      'upUser': body['userName'],
      'cntyCd': body['country'],
      'emId': body['email'], // required for prepord or prod build
     // 'emId': 'SPIRIT_ENS_Whitelist@corp.ds.fedex.com', // to be removed when giving preprod or prod build
      'ediUsr': 1 // EDI user? 1 = YES
    };
    const formData = new FormData();
    if (fileVal) {
      formData.append('ip.file', fileVal, fileName);
    }
    formData.append('edi.json', JSON.stringify(requestBody));
    return this._http.post(Constants.CONST_UPLOAD_BOOKING_URL, formData, this.setRequestOptions(ConstantsVAR.ACCESS_TOKEN))
      .map((res) => {
        return this.extractDataText(res);
      }).catch(this.handleErrorAll);
  }

  getEdiDownloadFile(fileID, fileTYPE): Observable<any> {
    return this._http.get(Constants.CONST_UPLOAD_BOOKING_DOWNLOAD_URL +
      '?fileId=' + fileID + '&flTyp=' + fileTYPE, this.setRequestOptions(ConstantsVAR.ACCESS_TOKEN))
      .map((res) => {
        return this.extractData(res);
      }).catch(this.handleError);
  }

  getUploadedBookingList(upUser): Observable<any> {
    return this._http
      .get(Constants.CONST_UPLOADED_BOOKING_LIST_URL + upUser, this.setRequestOptions(ConstantsVAR.ACCESS_TOKEN))
      .map((res) => {
        return this.extractData(res);
      }).catch(this.handleError);
  }

}

