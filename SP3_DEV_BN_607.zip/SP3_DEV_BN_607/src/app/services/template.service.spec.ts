/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved (c) Fedex 2018
 *
 * Typescript code in this page
 */
import { TestBed, async, inject, tick } from '@angular/core/testing';
import { HttpEvent, HttpEventType } from '@angular/common/http';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { TemplateService } from './template.service';
import { HttpClient, HttpResponse, HttpRequest, HttpParams } from '@angular/common/http';
import {
  HttpModule,
  Http,
  Response,
  Request,
  RequestMethod,
  RequestOptions,
  ResponseOptions,
  URLSearchParams,
  XHRBackend
} from '@angular/http';
import { MockBackend, MockConnection } from '@angular/http/testing';
import { ConstantsURL } from '../shared/constants/constants-urls';
import * as templateModel from './../shared/models/template.models';
describe('CreateTemplateDropdownService', () => {
  let service: TemplateService;
  let httpMock: HttpTestingController;
  let mockBackend: MockBackend;
  const mockAccount = { cAccNoLi: ['070071313'] };
  const Status = ['Active', 'Inactive'];
  const mockTempDataRequest: templateModel.TemplateBodyDTO = {
    tNm: 'saveNewTemplate',
    tId: null,
    cAccNo: parseInt(mockAccount.cAccNoLi[0], 10),
    pyr: 'R',
    gSidReFn: true,
    ctRfSmeBkRf: true,
    sSidRef: true,
    cRFg: true,
    sPrEs: true,
    cnRFg: true,
    sCnf: 'S',
    gDsc: 'some desc',
    insC: 'EUR',
    insV: 100,
    invcV: 100,
    invcC: 'EUR',
    svcs: [{ 'id': 3, 'e': true, 'd': false }, { 'id': 1, 'e': true, 'd': true }, { 'id': 2, 'e': true, 'd': false }],
    pkgs: [{ 'id': '2', 'q': '1', 'l': '10', 'wd': '20', 'h': '10', 'wg': '10' }],
    adr: [{ 'typ': 'S' }, { 'typ': 'P' }, { 'typ': 'R' }, { 'typ': 'D' }],
    aSCDt: 'true',
    sSrvs: 'false',
    aShTm: 5,
    aPkDm: 'true',
    defTmp: false,
    ptId: null,
    docs: []
  }

  const FileData = [{
    lastModified: 1545916498135,
    lastModifiedDate: 'Thu Dec 27 2018 18:44:58 GMT+0530 (India Standard Time)',
    name: '500.pdf',
    size: 552212,
    type: 'application/pdf'
  }];

  const URL = ConstantsURL;
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, HttpModule],
      providers: [
        { provide: URL, useValue: URL },
        TemplateService,
        { provide: MockBackend, useClass: MockBackend },
        { provide: XHRBackend, useExisting: MockBackend }]
    });

    service = TestBed.get(TemplateService);
    httpMock = TestBed.get(HttpTestingController);
    mockBackend = TestBed.get(MockBackend);

    spyOn(Http.prototype, 'request').and.callThrough();
  });

  afterEach(() => mockBackend.verifyNoPendingRequests());

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  /**
   * Template Dashboard list service call
   */
  // it('Template Dashboard success request call', () => {
  //   service.getTemplateListDashboard(mockAccount).subscribe((data) => {
  //     expect(data).toBeTruthy();
  //   });
  //   const mockReq = httpMock.expectOne(URL.CONST_TEMPLATE_LIST_DASHBOARD_URL);
  //   expect(mockReq.request.method).toBe('POST');
  //   expect(mockReq.request.responseType).toEqual('json');
  //   mockReq.flush(mockAccount);
  //   httpMock.verify();
  // });

  // it('Template Dashboard failure request call', () => {
  //   service.getTemplateListDashboard(mockAccount).subscribe((data) => {
  //     expect(data.ok).toBeFalsy();
  //   });
  //   const mockReq = httpMock.expectOne(URL.CONST_TEMPLATE_LIST_DASHBOARD_URL);
  //   expect(mockReq.request.method).toBe('POST');
  //   mockReq.flush(mockAccount);
  //   httpMock.verify();
  // });

  // it(`should get template list`, () => {
  //   service.getTemplateListDashboard(mockAccount).subscribe((next) => {
  //     expect(next).toBeTruthy();
  //   });
  //   httpMock.expectOne(URL.CONST_TEMPLATE_LIST_DASHBOARD_URL).flush(null, { status: 200, statusText: 'Ok' });
  // });

  /**
 * get list of templates mapped to logged user
   */
  it('Template dashboard list and sucess POST call status 200', () => {

    const mockResponse: templateModel.TemplateListDTO = {
      tId: 9, tNm: 'AutomationTemp_R', tSts: 'Active', def: false,
      dt: '14-02-2019', accno: '070071313'
    }

    mockBackend.connections.subscribe((connection: MockConnection) => {
      expect(connection.request.url).toBe(URL.CONST_TEMPLATE_LIST_DASHBOARD_URL);
      expect(connection.request.method).toBe(RequestMethod.Post);
      expect(connection.request.headers.get('Authorization')).toContain('Bearer ');
      connection.mockRespond(new Response(new ResponseOptions({
        body: JSON.stringify([mockResponse]),
        status: 200
      })));
    });

    service.getTemplateListDashboard(mockAccount).subscribe((data) => {
      expect(data.length).toBeGreaterThan(0);
  });

    });

  it('Template dashboard no list and POST success call status 204', () => {

    mockBackend.connections.subscribe((connection: MockConnection) => {
      expect(connection.request.url).toBe(URL.CONST_TEMPLATE_LIST_DASHBOARD_URL);
      expect(connection.request.method).toBe(RequestMethod.Post);
      expect(connection.request.headers.get('Authorization')).toContain('Bearer ');
      connection.mockRespond(new Response(new ResponseOptions({
        status: 204
      })));
  });

    service.getTemplateListDashboard(mockAccount).subscribe((data) => {
      expect(data).toBeFalsy();
    });
  });

  it('Template dashboard no list and POST failure call status 401 / 500 ', () => {

    mockBackend.connections.subscribe((connection: MockConnection) => {
      expect(connection.request.url).toBe(URL.CONST_TEMPLATE_LIST_DASHBOARD_URL);
      expect(connection.request.method).toBe(RequestMethod.Post);
      expect(connection.request.headers.get('Authorization')).toContain('Bearer ');
      connection.mockRespond(new Response(new ResponseOptions({
        status: 401 || 500
      })));
    });

    service.getTemplateListDashboard(mockAccount).subscribe((data) => {
      expect(data).toBeFalsy();
    });
  });
  /**
   * Activate / Deactivate Template from list
   */
  it('Template Dashboard Active request GET success call status 200', () => {
       const actDeactBody = {
      'tId': 43,
      'act': 'Active'
    };

    mockBackend.connections.subscribe((connection: MockConnection) => {
      expect(connection.request.url).toBe(URL.CONST_TEMPLATE_CONTEXT + actDeactBody.tId +
        URL.CONST_ACT_DEACT_TEMPLATE_URL + actDeactBody.act);
      expect(connection.request.method).toBe(RequestMethod.Get);
      expect(connection.request.headers.get('Authorization')).toContain('Bearer ');
      connection.mockRespond(new Response(new ResponseOptions({
        body: '',
        status: 200
      })));
    });

    service.actDeactTemplate(actDeactBody).subscribe((data) => {
      expect(data).toBe('');
    });

  });


  it('Template Dashboard Active request GET failure call status 400 / 500', () => {
       const actDeactBody = {
      'tId': 43,
      'act': 'Active'
    };

    mockBackend.connections.subscribe((connection: MockConnection) => {
      expect(connection.request.url).toBe(URL.CONST_TEMPLATE_CONTEXT + actDeactBody.tId +
        URL.CONST_ACT_DEACT_TEMPLATE_URL + actDeactBody.act);
      expect(connection.request.method).toBe(RequestMethod.Get);
      expect(connection.request.headers.get('Authorization')).toContain('Bearer ');
      connection.mockRespond(new Response(new ResponseOptions({
        status: 400 || 500
      })));
    });

    service.actDeactTemplate(actDeactBody).subscribe((data) => {
      expect(data).toBeFalsy();
    });

  });

  it('Template Dashboard Deactive request GET success call status 200', () => {
    const inactDeactBody = {
      'tId': 43,
      'act': 'Inactive'
    };

    mockBackend.connections.subscribe((connection: MockConnection) => {
      expect(connection.request.url).toBe(URL.CONST_TEMPLATE_CONTEXT + inactDeactBody.tId +
        URL.CONST_ACT_DEACT_TEMPLATE_URL + inactDeactBody.act);
      expect(connection.request.method).toBe(RequestMethod.Get);
      expect(connection.request.headers.get('Authorization')).toContain('Bearer ');
      connection.mockRespond(new Response(new ResponseOptions({
        body: '',
        status: 200
      })));
    });

    service.actDeactTemplate(inactDeactBody).subscribe((data) => {
      expect(data).toBe('');
    });
  });

  it('Template Dashboard Deactive request GET failure call status 400 / 500', () => {
    const inactDeactBody = {
      'tId': 43,
      'act': 'Inactive'
    };

    mockBackend.connections.subscribe((connection: MockConnection) => {
      expect(connection.request.url).toBe(URL.CONST_TEMPLATE_CONTEXT + inactDeactBody.tId +
        URL.CONST_ACT_DEACT_TEMPLATE_URL + inactDeactBody.act);
      expect(connection.request.method).toBe(RequestMethod.Get);
      expect(connection.request.headers.get('Authorization')).toContain('Bearer ');
      connection.mockRespond(new Response(new ResponseOptions({
        status: 400 || 500
      })));
    });

    service.actDeactTemplate(inactDeactBody).subscribe((data) => {
      expect(data).toBeFalsy();
    });
  });

  /**
   * get template to delete
   */

  it('Delete template success GET call status 200', () => {
    const delBody = {
      'tId': 43,
      'accno': mockAccount.cAccNoLi
    };

    mockBackend.connections.subscribe((connection: MockConnection) => {
      expect(connection.request.url).toBe(URL.CONST_TEMPLATE_CONTEXT + delBody.tId +
        URL.CONST_TEMP_DELETE_GET + delBody.accno);
      expect(connection.request.method).toBe(RequestMethod.Get);
      expect(connection.request.headers.get('Authorization')).toContain('Bearer ');
      connection.mockRespond(new Response(new ResponseOptions({
        body: '',
        status: 200
      })));
    });

    service.getDeleteTemplate(delBody).subscribe((data) => {
      expect(data).toBeTruthy();
    });
  });

  it('Delete template success GET call status 409', () => {
    const delBody = {
      'tId': 43,
      'accno': mockAccount.cAccNoLi
    };

    mockBackend.connections.subscribe((connection: MockConnection) => {
      expect(connection.request.url).toBe(URL.CONST_TEMPLATE_CONTEXT + delBody.tId +
        URL.CONST_TEMP_DELETE_GET + delBody.accno);
      expect(connection.request.method).toBe(RequestMethod.Get);
      expect(connection.request.headers.get('Authorization')).toContain('Bearer ');
      connection.mockRespond(new Response(new ResponseOptions({
        body: '',
        status: 409
      })));
    });

    service.getDeleteTemplate(delBody).subscribe((data) => {
      expect(data).toBeFalsy();
    });
  });

   /**
   * confirm to delete template
   */
  it('Confirm Delete template success Delete call status 200', () => {
    const delBody = {
      'tId': 43,
      'accno': mockAccount.cAccNoLi
    };

    mockBackend.connections.subscribe((connection: MockConnection) => {
      expect(connection.request.url).toBe(URL.CONST_TEMPLATE_CONTEXT + delBody.tId +
        URL.CONST_TEMP_BOOKING_DELETE + delBody.accno);
      expect(connection.request.method).toBe(RequestMethod.Delete);
      expect(connection.request.headers.get('Authorization')).toContain('Bearer ');
      connection.mockRespond(new Response(new ResponseOptions({
        body: '',
        status: 200
      })));
    });

    service.DeleteTemplateNew(delBody.tId , delBody.accno).subscribe((data) => {
      expect(data).toBeTruthy();
    });
  });

 it('Confirm Delete template faliure Delete call status 401 / 500', () => {
    const delBody = {
      'tId': 43,
      'accno': mockAccount.cAccNoLi
    };

    mockBackend.connections.subscribe((connection: MockConnection) => {
      expect(connection.request.url).toBe(URL.CONST_TEMPLATE_CONTEXT + delBody.tId +
        URL.CONST_TEMP_BOOKING_DELETE + delBody.accno);
      expect(connection.request.method).toBe(RequestMethod.Delete);
      expect(connection.request.headers.get('Authorization')).toContain('Bearer ');
      connection.mockRespond(new Response(new ResponseOptions({
        body: '',
        status: 401 || 500
      })));
    });

    service.DeleteTemplateNew(delBody.tId , delBody.accno).subscribe((data) => {
      expect(data).toBeFalsy();
    });
  });

  /**
   * create duplicate template
   */

  it('Create Duplicate template success GET call status 201', () => {
    const duplicateBody = {
      'refTId': 43,
      'nTNm': 'DuplicateTempName'
    };

    mockBackend.connections.subscribe((connection: MockConnection) => {
      expect(connection.request.url).toBe(URL.CONST_TEMPLATE_CONTEXT + duplicateBody.refTId +
        URL.CONST_DUPLICATE_TEMPLATE + duplicateBody.nTNm);
      expect(connection.request.method).toBe(RequestMethod.Get);
      expect(connection.request.headers.get('Authorization')).toContain('Bearer ');
      connection.mockRespond(new Response(new ResponseOptions({
        body: '',
        status: 201
      })));
    });

    service.duplicateTemplate(duplicateBody).subscribe((data) => {
      expect(data).toBe('');
    });
  });


  it('Create Duplicate template failure GET call status 401 / 500', () => {
    const duplicateBody = {
      'refTId': 43,
      'nTNm': 'DuplicateTempName'
    };

    mockBackend.connections.subscribe((connection: MockConnection) => {
      expect(connection.request.url).toBe(URL.CONST_TEMPLATE_CONTEXT + duplicateBody.refTId +
        URL.CONST_DUPLICATE_TEMPLATE + duplicateBody.nTNm);
      expect(connection.request.method).toBe(RequestMethod.Get);
      expect(connection.request.headers.get('Authorization')).toContain('Bearer ');
      connection.mockRespond(new Response(new ResponseOptions({
        status: 401 / 500
      })));
    });

    service.duplicateTemplate(duplicateBody).subscribe((data) => {
      expect(data).toBeFalsy();
    });
  });

/**
 * Check Template name
 */
  it('Check Template name already exists success GET call status 200 and response data to true', () => {
    mockBackend.connections.subscribe((connection: MockConnection) => {
      expect(connection.request.url).toBe(URL.CONST_CHECK_TEMPLATE_NAME + '?acc_no=' +
      mockAccount.cAccNoLi + '&temp_nm=' + 'duplicatename');
      expect(connection.request.method).toBe(RequestMethod.Get);
      expect(connection.request.headers.get('Authorization')).toContain('Bearer ');
      connection.mockRespond(new Response(new ResponseOptions({
        body: 'true',
        status: 200
      })));
    });

    service.checkTemplateName(mockAccount.cAccNoLi, 'duplicatename').subscribe((data) => {
      expect(data).toBe('true');
    });
  });

  it('Check Template name already exists success GET call status 200 and response data to false', () => {
    mockBackend.connections.subscribe((connection: MockConnection) => {
      expect(connection.request.url).toBe(URL.CONST_CHECK_TEMPLATE_NAME + '?acc_no=' +
      mockAccount.cAccNoLi + '&temp_nm=' + 'duplicatename');
      expect(connection.request.method).toBe(RequestMethod.Get);
      expect(connection.request.headers.get('Authorization')).toContain('Bearer ');
      connection.mockRespond(new Response(new ResponseOptions({
        body: 'false',
        status: 200
      })));
    });

    service.checkTemplateName(mockAccount.cAccNoLi, 'duplicatename').subscribe((data) => {
      expect(data).toBe('false');
    });
  });

  it('Check Template name already exists Failure GET call status 400 / 500', () => {
    mockBackend.connections.subscribe((connection: MockConnection) => {
      expect(connection.request.url).toBe(URL.CONST_CHECK_TEMPLATE_NAME + '?acc_no=' +
      mockAccount.cAccNoLi + '&temp_nm=' + 'duplicatename');
      expect(connection.request.method).toBe(RequestMethod.Get);
      expect(connection.request.headers.get('Authorization')).toContain('Bearer ');
      connection.mockRespond(new Response(new ResponseOptions({
        status: 400 || 500
      })));
    });

    service.checkTemplateName(mockAccount.cAccNoLi, 'duplicatename').subscribe((data) => {
      expect(data).toBeFalsy();
    });
  });

  /**
   * Check Template exists for user
   */

  it('Check any Template exists for user success POST call status 200', () => {
    mockBackend.connections.subscribe((connection: MockConnection) => {
      expect(connection.request.url).toBe(URL.CONST_TEMPLATE_EXISTS, mockAccount);
      expect(connection.request.method).toBe(RequestMethod.Post);
      expect(connection.request.headers.get('Authorization')).toContain('Bearer ');
      connection.mockRespond(new Response(new ResponseOptions({
        body: true,
        status: 200
      })));
    });

    service.checkTemplateAvailblty(mockAccount).subscribe((data) => {
      expect(data).toBeTruthy();
    });
  });

  it('Check any Template exists false for user success POST call status 200', () => {
    mockBackend.connections.subscribe((connection: MockConnection) => {
      expect(connection.request.url).toBe(URL.CONST_TEMPLATE_EXISTS, mockAccount);
      expect(connection.request.method).toBe(RequestMethod.Post);
      expect(connection.request.headers.get('Authorization')).toContain('Bearer ');
      connection.mockRespond(new Response(new ResponseOptions({
        body: 'false',
        status: 200
      })));
    });

    service.checkTemplateAvailblty(mockAccount).subscribe((data) => {
      expect(data).toBe('false');
    });
  });

  it('Check any Template exists for user failure POST call status 409', () => {
    mockBackend.connections.subscribe((connection: MockConnection) => {
      expect(connection.request.url).toBe(URL.CONST_TEMPLATE_EXISTS, mockAccount);
      expect(connection.request.method).toBe(RequestMethod.Post);
      expect(connection.request.headers.get('Authorization')).toContain('Bearer ');
      connection.mockRespond(new Response(new ResponseOptions({
        status: 409
      })));
    });

    service.checkTemplateAvailblty(mockAccount).subscribe((data) => {
      expect(data).toBeFalsy();
    });
  });

  /**
   * Get all template detail from selected template ID
   */

  it('Get Template detail success GET call status 200', () => {
    const templateId = 23;
    const mockResponse = {
      'templateServiceEntity': [{ 'id': 2, 'e': true, 'd': false }, { 'id': 1, 'e': true, 'd': true }, { 'id': 3, 'e': true, 'd': false }],
      'tId': templateId,
      'defTmp': false,
      'tmpSts': 'Active',
      'tNm': 'fgdgdfg',
      'cAccNo': mockAccount.cAccNoLi,
      'pyr': 'R',
      'sSidRef': true,
      'cRFg': true,
      'sPrEs': true,
      'cnRFg': true,
      'gSidReFn': true,
      'ctRfSmeBkRf': true,
      'sCnf': 'S',
      'svcs': [{ 'id': 2, 'e': true, 'd': false }, { 'id': 1, 'e': true, 'd': true }, { 'id': 3, 'e': true, 'd': false }],
      'aSCDt': true,
      'aPkDm': true,
      'sSrvs': false,
      'aShTm': 5,
      'adr': [
        {
          'tel': null, 'pCd': null, 'pIn': null, 'l2': null, 'l1': null, 'e': null,
          'cntry': null, 'cd': null, 'cPsn': null, 'cNme': null, 'cty': null, 'typ': 'P'
        },
        {
          'tel': null, 'pCd': null, 'pIn': null, 'l2': null, 'l1': null, 'e': null,
          'cntry': null, 'cd': null, 'cPsn': null, 'cNme': null, 'cty': null, 'typ': 'S'
        },
        {
          'tel': null, 'pCd': null, 'pIn': null, 'l2': null, 'l1': null, 'e': null,
          'cntry': null, 'cd': null, 'cPsn': null, 'cNme': null, 'cty': null, 'typ': 'R'
        },
        {
          'tel': null, 'pCd': null, 'pIn': null, 'l2': null, 'l1': null, 'e': null,
          'cntry': null, 'cd': null, 'cPsn': null, 'cNme': null, 'cty': null, 'typ': 'D'
        }],
      'pkgs': [{ 'id': 2, 'q': 1, 'wd': null, 'wg': null, 'l': null, 'h': null, 'enc': null }],
      'gDsc': null,
      'invcV': null,
      'invcC': 'EUR',
      'insV': null,
      'insC': 'EUR',
      'docs': [],
      'ptId': 0
    }
    mockBackend.connections.subscribe((connection: MockConnection) => {
      expect(connection.request.url).toBe(URL.CONST_FETCH_TEMPLATE_DETAILS_URL + templateId);
      expect(connection.request.method).toBe(RequestMethod.Get);
      expect(connection.request.headers.get('Authorization')).toContain('Bearer ');
      connection.mockRespond(new Response(new ResponseOptions({
        body: JSON.stringify(mockResponse),
        status: 200
      })));
    });

    service.getTemplateDetails(templateId).subscribe((data) => {
      expect(data).toBeTruthy();
    });
  });

  it('Get Template detail Failure GET call status 400 / 500', () => {
    const templateId = 23;

    mockBackend.connections.subscribe((connection: MockConnection) => {
      expect(connection.request.url).toBe(URL.CONST_FETCH_TEMPLATE_DETAILS_URL + templateId);
      expect(connection.request.method).toBe(RequestMethod.Get);
      expect(connection.request.headers.get('Authorization')).toContain('Bearer ');
      connection.mockRespond(new Response(new ResponseOptions({
        status: 400 || 500
      })));
    });

    service.getTemplateDetails(templateId).subscribe((data) => {
      expect(data).toBeFalsy();
    });
  });

  /**
   * get service list for template
   */

  it('Get Service list Success GET call status 200', () => {
    const mockResponse =
      [{ serviceId: 1, serviceName: 'Express' },
      { serviceId: 2, serviceName: 'Premium' },
      { serviceId: 3, serviceName: 'Economy' }];

    mockBackend.connections.subscribe((connection: MockConnection) => {
      expect(connection.request.url).toBe(URL.CONST_CREATE_TEMPLATE_DROPDOWN_SERVICE_LIST_URL);
      expect(connection.request.method).toBe(RequestMethod.Get);
      expect(connection.request.headers.get('Authorization')).toContain('Bearer ');
      connection.mockRespond(new Response(new ResponseOptions({
        body: JSON.stringify(mockResponse),
        status: 200
      })));
    });

    service.getServiceListDrpdwn().subscribe((data) => {
      expect(data).toBeTruthy();
    });
  });

  it('Get Service list Failure GET call status 400 / 500', () => {

    mockBackend.connections.subscribe((connection: MockConnection) => {
      expect(connection.request.url).toBe(URL.CONST_CREATE_TEMPLATE_DROPDOWN_SERVICE_LIST_URL);
      expect(connection.request.method).toBe(RequestMethod.Get);
      expect(connection.request.headers.get('Authorization')).toContain('Bearer ');
      connection.mockRespond(new Response(new ResponseOptions({
        status: 400 || 500
      })));
    });

    service.getServiceListDrpdwn().subscribe((data) => {
      expect(data).toBeFalsy();
    });
  });

  /**
   * Get package lsit for templates
   */

  it('Get Package list Success GET call status 200', () => {
    const mockResponse =
      [{ packageId: 1, packageNm: 'Pallet' },
      { packageId: 2, packageNm: 'Box' },
      { packageId: 3, packageNm: 'Envelope' }]

    mockBackend.connections.subscribe((connection: MockConnection) => {
      expect(connection.request.url).toBe(URL.CONST_GET_TEMPLATE_DROPDOWN_PACKAGE_LIST_URL);
      expect(connection.request.method).toBe(RequestMethod.Get);
      expect(connection.request.headers.get('Authorization')).toContain('Bearer ');
      connection.mockRespond(new Response(new ResponseOptions({
        body: JSON.stringify(mockResponse),
        status: 200
      })));
    });

    service.getPackageListDrpdwn().subscribe((data) => {
      expect(data).toBeTruthy();
    });
  });

  it('Get Package list Failure GET call status 400 / 500', () => {

    mockBackend.connections.subscribe((connection: MockConnection) => {
      expect(connection.request.url).toBe(URL.CONST_GET_TEMPLATE_DROPDOWN_PACKAGE_LIST_URL);
      expect(connection.request.method).toBe(RequestMethod.Get);
      expect(connection.request.headers.get('Authorization')).toContain('Bearer ');
      connection.mockRespond(new Response(new ResponseOptions({
        status: 400 || 500
      })));
    });

    service.getPackageListDrpdwn().subscribe((data) => {
      expect(data).toBeFalsy();
    });
  });

  /**
   * Save a template
   */

  it('Should Save a template with / without file and data , Success POST call with status 201', () => {

    const formData = { 'template.json': mockTempDataRequest, 'ip.file': [FileData] }
    mockBackend.connections.subscribe((connection: MockConnection) => {
      expect(connection.request.url).toBe(URL.CONST_CREATE_TEMPLATE_SAVE_TEMPLATE_URL, formData);
      expect(connection.request.method).toBe(RequestMethod.Post);
      expect(connection.request.headers.get('Authorization')).toContain('Bearer ');
      connection.mockRespond(new Response(new ResponseOptions({
        body: '',
        status: 201
      })));
    });

    service.saveTemplate(mockTempDataRequest, FileData).subscribe((data) => {
      expect(data).toBe('');
    });

    /**
    without file data
     */
    service.saveTemplate(mockTempDataRequest, null).subscribe((data) => {
      expect(data).toBe('');
    });

  });

  it('Should Save a template with / without file and data , Failure POST call with status 400 / 500', () => {

    const formData = { 'template.json': mockTempDataRequest, 'ip.file': [FileData] }
    mockBackend.connections.subscribe((connection: MockConnection) => {
      expect(connection.request.url).toBe(URL.CONST_CREATE_TEMPLATE_SAVE_TEMPLATE_URL, formData );
      expect(connection.request.method).toBe(RequestMethod.Post);
      expect(connection.request.headers.get('Authorization')).toContain('Bearer ');
      connection.mockRespond(new Response(new ResponseOptions({
        status: 400 || 500
      })));
    });

    service.saveTemplate(mockTempDataRequest, FileData).subscribe((data) => {
      expect(data.ok).toBeFalsy();
    });

    /**
    without file data
     */
    service.saveTemplate(mockTempDataRequest, null).subscribe((data) => {
      expect(data.ok).toBeFalsy();
    });

  });

  /**
   * Update a template
   */

  it('Should Update a template with / without file and data , Success POST call with status 201', () => {
    const formData = { 'template.json': mockTempDataRequest, 'ip.file': [FileData] }
    mockBackend.connections.subscribe((connection: MockConnection) => {
      expect(connection.request.url).toBe(URL.CONST_TEMPLATE_CONTEXT + URL.CONST_UPDATE_EDIT_TEMPLATE, formData);
      expect(connection.request.method).toBe(RequestMethod.Post);
      expect(connection.request.headers.get('Authorization')).toContain('Bearer ');
      connection.mockRespond(new Response(new ResponseOptions({
        body: '',
        status: 201
      })));
    });

    service.updateTemplate(mockTempDataRequest, FileData).subscribe((data) => {
      expect(data).toBe('');
    });

    /**
    without file data
     */
    service.updateTemplate(mockTempDataRequest, null).subscribe((data) => {
      expect(data).toBe('');
    });

  });

  it('Should Update a template with / without file and data , Failure POST call with status 400 / 500', () => {
    const formData = { 'template.json': mockTempDataRequest, 'ip.file': [FileData] }
    mockBackend.connections.subscribe((connection: MockConnection) => {
      expect(connection.request.url).toBe(URL.CONST_TEMPLATE_CONTEXT + URL.CONST_UPDATE_EDIT_TEMPLATE, formData);
      expect(connection.request.method).toBe(RequestMethod.Post);
      expect(connection.request.headers.get('Authorization')).toContain('Bearer ');
      connection.mockRespond(new Response(new ResponseOptions({
        status: 400 || 500
      })));
    });

    service.updateTemplate(mockTempDataRequest, FileData).subscribe((data) => {
      expect(data.ok).toBeFalsy();
    });

    /**
    without file data
     */
    service.updateTemplate(mockTempDataRequest, null).subscribe((data) => {
      expect(data.ok).toBeFalsy();
    });

  });

  /**
   * make default template
   */

  it('make a default template, Success GET call with status 200', () => {
      const makeDefaultBody = {
      'olDtId': 1,
      'nDtId': 2
    };
    mockBackend.connections.subscribe((connection: MockConnection) => {
      expect(connection.request.url).toBe(URL.CONST_TEMPLATE_CONTEXT + makeDefaultBody.nDtId +
      URL.CONST_MAKE_TEMPLATE_DEFAULT_URL + mockAccount.cAccNoLi);
      expect(connection.request.method).toBe(RequestMethod.Get);
      expect(connection.request.headers.get('Authorization')).toContain('Bearer ');
      connection.mockRespond(new Response(new ResponseOptions({
        body: '',
        status: 200
      })));
    });

    service.makeTemplateDefault(makeDefaultBody, mockAccount.cAccNoLi).subscribe((data) => {
      expect(data).toBe('');
    });

  });

  it('make a default template, Failure GET call with status 400 / 500', () => {
      const makeDefaultBody = {
      'olDtId': 1,
      'nDtId': 2
    };
    mockBackend.connections.subscribe((connection: MockConnection) => {
      expect(connection.request.url).toBe(URL.CONST_TEMPLATE_CONTEXT + makeDefaultBody.nDtId +
      URL.CONST_MAKE_TEMPLATE_DEFAULT_URL + mockAccount.cAccNoLi);
      expect(connection.request.method).toBe(RequestMethod.Get);
      expect(connection.request.headers.get('Authorization')).toContain('Bearer ');
      connection.mockRespond(new Response(new ResponseOptions({
        status: 400 || 500
      })));
    });

    service.makeTemplateDefault(makeDefaultBody, mockAccount.cAccNoLi).subscribe((data) => {
      expect(data.ok).toBeFalsy();
    });

  });

  /**
   * create Template
   */

  it('Create Template, Success POST call with status 201', () => {
      const tmpBody = {
      'bId': 1,
      'tNm': 'tempName',
      'tTyp': 'I'
    };
    mockBackend.connections.subscribe((connection: MockConnection) => {
      expect(connection.request.url).toBe(URL.CONST_TEMPLATE_BASIC_CREATE, tmpBody);
      expect(connection.request.method).toBe(RequestMethod.Post);
      expect(connection.request.headers.get('Authorization')).toContain('Bearer ');
      connection.mockRespond(new Response(new ResponseOptions({
        body: '',
        status: 201
      })));
    });

    service.createTemplate(tmpBody).subscribe((data) => {
      expect(data).toBe('');
    });

  });

  it('Create Template, Failure POST call with status 400 / 500', () => {
      const tmpBody = {
      'bId': 1,
      'tNm': 'tempName',
      'tTyp': 'I'
    };
    mockBackend.connections.subscribe((connection: MockConnection) => {
      expect(connection.request.url).toBe(URL.CONST_TEMPLATE_BASIC_CREATE, tmpBody);
      expect(connection.request.method).toBe(RequestMethod.Post);
      expect(connection.request.headers.get('Authorization')).toContain('Bearer ');
      connection.mockRespond(new Response(new ResponseOptions({
        status: 400 || 500
      })));
    });

    service.createTemplate(tmpBody).subscribe((data) => {
      expect(data.ok).toBeFalsy();
    });

  });

});
