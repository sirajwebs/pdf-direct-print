/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved *copyright* FedEx 2018
 *
 * Typescript code in this page
 */
import { ConstantsURL } from './../../shared/constants/constants-urls';
import { CalltokenComponent } from './../../shared/calltoken/calltoken.component';
import { GoogleapisService } from './../../services/googleapis.service';
import { AddressComponent } from './../../shared/components/address/address.component';
import { InsuranceInvoiceComponent } from './../../shared/components/insurance-invoice/insurance-invoice.component';
import { PackageWeightsComponent } from './../../shared/components/package-weights/package-weights.component';
import { SharedataService } from './../../services/sharedata.service';
import { Subscription } from 'rxjs/Subscription';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Component, OnInit, OnDestroy, ViewChild, ChangeDetectorRef, HostListener } from '@angular/core';
import { BookingService } from '../../services/booking.service';
import { TemplateService } from '../../services/template.service';
import { Router } from '@angular/router';
import { isNullOrUndefined } from 'util';
import { ConstantsJson, ConstantsVAR, KeyboardKey, QUERY_PARAMS, BOOKING_STATUS, UNITS } from './../../shared/constants/constants-var';
import { AccountListDTO } from './../../shared/models/user.models';
import { JsEncoderService } from './../../services/js-encoder.service';
import { ProductsOfferedComponent } from './products-offered/products-offered.component';
import {
  PickupDTO, BookingAddressDTO, DueDateDTO,
  ColnTimeInitDTO, BookingPreferenceDTO, DateTime
} from './../../shared/models/bookings.models';
import { SharedFunctionsService } from './../../services/shared-functions.service';
import { TemplateListDTO } from 'app/shared/models/template.models';
import { ColnTimeConstants } from './../../shared/constants/constants-var';
import { AddressbookPrivilegeService } from 'app/services/privilege/addressbook-privilege.service';
import { BookingExpirationComponent } from './booking-expiration/booking-expiration.component';
import { FORMS } from 'app/shared/constants/forms.properties';
import { UserAccDetails } from 'app/shared/models/login.models';


@Component({
  selector: 'app-newbooking',
  templateUrl: './newbooking.component.html',
  styleUrls: ['./newbooking.component.css'],
  providers: [BookingService, TemplateService, AddressComponent,
    GoogleapisService, SharedFunctionsService, AddressbookPrivilegeService]
})

export class NewbookingComponent implements OnInit, OnDestroy {

  apiSubscription = [];
  subscriptions: Array<Subscription> = [];
  bookingTemplateBody = null; // check***
  collapse_expand: boolean[] = [false];
  templateDetailsFetch = null;  // check datatypes ***
  fetchTempDetailsError = null;
  fetchTempDetailsSuccess = null;
  // templateList: Array<TemplateListDTO> = [];
  templateList = [];
  insuranceData = null;  // check datatypes ***
  templateListSuccess = null;
  templateListError = null;
  bookingSndrAddrsFlag: boolean;
  editaddrsflag: boolean;
  setAddressflag: boolean;
  bookingReceiverAddrsFlag: boolean;
  custAccNo = '';
  SetSIDNumberOnEdit = '';
  SetCustRefNoOnEdit = '';
  checkOnBlurHappened = false;
  /*--------------------Insurance-------------------*/
  goodsDesc = '';
  invoiceVal = null;
  invoiceValCurrency = '';
  insuranceVal = null;
  insuranceValCurrency = '';
  file = null;  // check datatypes ***
  countPakgCall = 0;
  packageFormData = null;  // check datatypes ***
  addressArray = [];
  addressType = '';
  logCountry = '';
  hideInsNull = false;

  bookingValueChanges = false;
  disableCstmrRef = false;
  debugMessage = '';
  viewDisplayCount = 0;
  shpmntConfirmBy = '';
  readonlyField = false;
  sId = 0;

  saveBtnClicked = false;
  packWeighFrmVldtn = null;
  insrInvcFrmVldtn = null;
  gnrlInfoFrmVldtn = null;
  sndrAddrssFrmVldtn = null;
  pckpAddrssFrmVldtn = null;
  dstntnAddrssFrmVldtn = null;
  rcvrAddrssFrmVldtn = null;
  colnTimeFrmVldtn = false;

  totalVolume = 0;
  weight = 0;
  quantity = 0;
  packDimensionData = null; // check datatypes ***
  pickFlag = false;
  destiFlag = false;
  pickAdresData = null;  // check datatypes ***
  pickAdresDataOld = null;  // check datatypes ***
  sndrAdrData = null; // check datatypes ***
  destiAdresData = null; // check datatypes ***
  destiAdresDataOld = null; // check datatypes ***
  rcvrAdrData = null; // check datatypes ***
  bkngAddrTmp = null; // check datatypes ***
  saveEdtAddr = false;
  setEdtAddrFlag = '';
  showCntntList = false;
  multplCntntSaveBtn = false;
  uniqueBookRefDataErrorflag = 'false';
  postalAware = JSON.parse(JSON.stringify(ConstantsJson.postalAware));
  addressFlagData = JSON.parse(JSON.stringify(ConstantsJson.addressFlagData));

  makeDefaultSuccess: boolean;
  makeDefaultError: boolean;
  oldDefaultTid = '';
  readonlyAwaiting = null;  // check datatypes ***
  readonlyAwaitingCRNM = null;  // check datatypes ***
  goodsNonDocs = ConstantsVAR.goodsNonDocs;
  contentRefNum = [];
  serviceProductDetails = []; // check datatype ***
  sndrCntry = '';
  sndrTwn = '';
  sndrPo = '';
  destiCntry = '';
  destiTwn = '';
  destiPo = '';
  serviceInfoErrorFlag = false;
  pckAddrDimensionData = null;  // check datatypes ***
  destiAddrdimensionData = null;  // check datatypes ***
  serviceInfoProducts = null;  // check datatypes ***

  incmpltServiceInfo: boolean;
  incmpltPickupInfo: boolean;
  editBnkgRefDisableField = false;
  bkngId = '';
  getBkngDetailsSuccess: boolean;
  getBkngDetailsError: boolean;
  bookingDetailsFetch = null;  // check datatypes ***
  editFlag = false;
  zeroTemplateFound = true;
  bookingId = 0;
  uniqueBookRefError = null;
  totalPrice = null;
  shpmntDtCnfrmBy = '';
  prId = '';
  prDesc = '';
  serviceId = '';
  serviceName = '';
  prType = '';
  tId = '';
  bkngSaveError: boolean;
  bkngSaveDraftError: boolean;
  FormError = false;
  bookingType = 'NEW';

  uniqueCustRefDataErrorflag = 'false';
  uniqueCustRefError: boolean;
  uniqueCntntRefData: boolean;
  duePickUpDateAPI = '';
  pickUplat = 0;
  pickUplng = 0;
  destiLat = 0;
  destiLng = 0;
  pickupData = []; // check datatype ***
  deliveryTimeZoneId = '';
  collectionTimeZoneId = '';
  collectionRequestBody = null;  // check datatypes ***
  actualCollectionDateTime: DateTime = {
    DATE: '',
    TIME: ''
  };
  currentCollectionDateTime: DateTime = {
    DATE: '',
    TIME: ''
  };
  completeClicked = 0;
  apiCallCount = [];
  insrDataCatch = false;

  readonly BOOKING_STATUS = BOOKING_STATUS;
  readonly ConstantsVAR = ConstantsVAR;

  packagedatachange = false;
  confirmPickUpStatus = '';
  apiErrorServiceInfo: boolean;
  accountList = [];
  showCnfrmDtPckp = false;
  DoNotSaveDraft: boolean;
  duePickUpDate = ConstantsJson.duePickUpDate_INIT;
  editTemplateDetailsFetch = null;  // check datatypes ***

  newBookingForm = new FormGroup({
    templateType: new FormControl(''),
    customerAcc: new FormControl(''),
    bookingRefNo: new FormControl({ value: '', disabled: true }, [Validators.pattern('[a-zA-Z0-9]*')]),
    customerRefNo: new FormControl('', [Validators.pattern('^[a-zA-Z0-9-]+$')]),
    contentRefNo: new FormControl(''),
    bkngSndrChck: new FormControl(''),
    bkngRcrAddrChck: new FormControl(''),
    confirmPickup: new FormControl(''),
    serviceType: new FormControl(''),
    bkngStatus: new FormControl(''),
    bkngNumbr: new FormControl(''),
    bkngAwbCon: new FormControl('')
  });

  fileDetailsData = null;  // check datatypes ***
  fileDoc = [];  // check datatypes ***
  defaultAccount = [];  // check datatypes ***

  basicBkngFlg = false;

  basicBooking = '';
  basicAccNo = '';
  addrCompanyName: string;
  isServicePopulating = '';
  noDefaultService: boolean;
  editClctnAddressFlg = true;
  editDelvAddressFlg = true;
  searchValue = '';
  filtersOfFilters = null;  // check datatypes ***
  previousServiceInfo = null;  // check datatypes ***
  previousDueDate = null;  // check datatypes ***
  previousExpecDt = null;  // check datatypes ***
  tempaccountList = [];
  accountNumber: Array<UserAccDetails>; // remove when fedex / tnt integration is complete
  setPackagesList = null; // check datatypes ***
  closeCancel = 0;
  onyes = 0;
  noback = 0;
  isMozilla = ConstantsVAR.MOZILLA_FIREFOX;

  colnTimeFrmApiInit: ColnTimeInitDTO = {
    cutOffTm: '',
    dptOpenTm: '',
    dptCloseTm: ''
  };
  colnTimeBody: BookingPreferenceDTO;
  colnTimeBodyInit: BookingPreferenceDTO;
  getColnDtlsSts = false;
  collectionCountryDt: Date;
  fedexContactAddress = [];
  templateChanged = 0;

  @ViewChild(CalltokenComponent) public _calltoken: CalltokenComponent;
  @ViewChild(PackageWeightsComponent) public _packWeigh: PackageWeightsComponent;
  @ViewChild(InsuranceInvoiceComponent) public _insrInvc: InsuranceInvoiceComponent;
  @ViewChild(ProductsOfferedComponent) public _prdtsOffrd: ProductsOfferedComponent;
  @ViewChild('senderAddress') public _sndrAddrss: AddressComponent;
  @ViewChild('pickupAddress') public _pckpAddrss: AddressComponent;
  @ViewChild('receiverAddress') public _rcvrAddrss: AddressComponent;
  @ViewChild('destinationAddress') public _dstntnAddrss: AddressComponent;
  @ViewChild(BookingExpirationComponent) public _bkngExpr: BookingExpirationComponent;

  @HostListener('focusin', ['$event'])
  onFocus(event) {
    this.FormError = false;
  }

  @HostListener('keydown', ['$event'])
  onEscKey(event) {
    if (event.keyCode === KeyboardKey.KEY_ESC && this.closeCancel === 1) {
      this.closeModal();
      this.changeFocus('Cancel');
    }
    if (event.keyCode === KeyboardKey.KEY_ESC && this.onyes === 1) {
      this.closeModal();
      this.changeFocus('Cancel');
      this.onyes = 0;
    }
    if ((event.shiftKey && event.keyCode === KeyboardKey.KEY_TAB) && this.closeCancel === 1 && this.noback === 1) {
      return false;
    }
  }
  constructor(private _booking: BookingService,
    private _template: TemplateService,
    private _router: Router,
    private _jsEcd: JsEncoderService,
    private _shrdFnctns: SharedFunctionsService,
    private _google: GoogleapisService,
    private _shrdt: SharedataService,
    private _cd: ChangeDetectorRef) { }

  @HostListener('window:scroll', [])
  onWindowScroll() {
    const number = window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop || 0;
    const bodyH = document.getElementById('page-body') ? document.getElementById('page-body').offsetHeight : 0;
    // const colnH = document.getElementById('coln-body') ? document.getElementById('serv-body').offsetHeight : 0;
    // const delH = document.getElementById('del-body') ? document.getElementById('serv-body').offsetHeight : 0;
    const pkgsH = document.getElementById('pkgs-body') ? document.getElementById('pkgs-body').offsetHeight : 0;
    const servH = document.getElementById('serv-body') ? document.getElementById('serv-body').offsetHeight : 0;
    const btnH = document.getElementById('btn-body') ? document.getElementById('btn-body').offsetHeight : 0;
    const tncH = document.getElementById('tnc-body') ? document.getElementById('tnc-body').offsetHeight : 0;
    const invcH = document.getElementById('invc-body') ? document.getElementById('invc-body').offsetHeight : 0;
    const cntnH = document.getElementById('cntn-body') ? document.getElementById('cntn-body').offsetHeight : 0;
    if (number > ConstantsVAR.BKNG_PAGE_SCRLL_HGHT_1000 && number >
      bodyH - pkgsH - servH - btnH - tncH - invcH - cntnH - ConstantsVAR.BKNG_PAGE_SCRLL_HGHT_300) {
      const event = {
        value: true
      };

      this.editClctnAddressFlg = true;
      this.editDelvAddressFlg = true;

      this.onClickClctnOutside(event);
      this.onClickDelvOutside(event);
      this.onClickPackageOutside(event);
      // window.scrollTo(0, bodyH);
    }
  }

  ngOnInit() {
    window.scrollTo(0, 0);
    this.subscriptions.push(this._shrdt.loginDetailsMsg.subscribe((loginDetails) => {
      if (loginDetails) {
        if (loginDetails['userProfile']) {
          this.logCountry = loginDetails['userProfile'].registeredContactAndAddress.address.countryCode;
        }
      }
    }));

    const accKeyVal = this._jsEcd.decode(localStorage.getItem(ConstantsVAR.ACC_KEY));
    if (accKeyVal) {
      this.accountList = JSON.parse(accKeyVal)['cAccNoLi'];
    }

    if (this.accountList) {
      if (this.accountList.length === 1) {
        this.newBookingForm.get('customerAcc').disable();
      }
    }
    this.defaultAccount = [this._jsEcd.decode(localStorage.getItem(ConstantsVAR.DEF_ACC_KEY))];

    this.subscriptions.push(this._shrdt.basicBooking.subscribe((data) => {
      if (data) {
        this.basicBooking = data['id'];
        this.basicAccNo = data['accNo'];
      }
    }));

    this.initiateBookingParamsFetch();

    this.subscriptions.push(this._shrdt.getSearch.subscribe((val) => {
      if (val) {
        this.searchValue = val;
      }
    }));

    this.subscriptions.push(this._shrdt.getFiltersOfFilters.subscribe((val) => {
      if (val) {
        this.filtersOfFilters = val;
      }
    }));

    if (this.basicBooking === ConstantsVAR.INBOUND) {
      this.bookingType = 'INB';
      this.basicBkngFlg = true;
      this.fetchTemplateDetails('basic');
      this.diableFieldsForBasic();
    } else if (this.basicBooking === ConstantsVAR.RETURN) {
      this.bookingType = 'RET';
      this.basicBkngFlg = true;
      this.fetchTemplateDetails('return');
      this.diableFieldsForBasic();
    } else {
      this.basicBkngFlg = false;
      this.fetchTemplateList();
    }
  }

  initiateBookingParamsFetch() {
    const data = this._shrdt.getQueryParamsData(QUERY_PARAMS.BKNG_ID);
    this.bkngId = data;
    if (data) {
      this.bookingType = 'EDIT';
    }
  }

  serviceValueChange() {
    if (this.serviceProductDetails) {
      this.isServicePopulating = 'CLCN-S';
      this.newBookingForm.get('confirmPickup').markAsUntouched();
      const srvcFltr = this.serviceProductDetails.filter((el) => {
        if (el.product_id === '0') {
          this.noDefaultService = true;
        } else {
          if (el.product_id === this.newBookingForm.get('serviceType').value) {
            this.noDefaultService = false;
            const product = {
              id: el.product_id,
              type: this.serviceInfoProducts.product.type
            };
            this.serviceInfoProducts.product = product;
            this.resetServiceSectionData();
            this.apiErrorServiceInfo = false;

            const apiName = 'callServiceInfoChange';
            this.apiUnsubscribe(apiName);

            this.subscriptions.push(this.apiSubscription[apiName] =
              this._booking.fetchServiceInformationDetails(this.serviceInfoProducts).subscribe(data => {
                this.serviceInfoErrorFlag = false;
                if (typeof data === typeof 'string') {
                  this.apiErrorServiceInfo = true;
                  this.newBookingForm.get('confirmPickup').markAsTouched();
                } else {
                  this.apiErrorServiceInfo = false;
                  this.totalPrice = null;
                  data.sort(this.sortServiceProducts);
                  const srvcMatch = data.filter(el2 => {
                    if (el2.product_id === product.id) {
                      this.totalPrice = el2.totalPrice;
                      this.setColnTimeInitData(el2);
                      if (!this._cd['destroyed']) { this._cd.detectChanges(); }
                      this.getpickUplatlng(this.pickAdresData, this.destiAdresData);
                      this.getDelvyLatLng(this.pickAdresData, this.destiAdresData);
                      return el2;
                    }
                  });
                  if (srvcMatch.length) {
                    this.apiErrorServiceInfo = false;
                  } else { this.apiErrorServiceInfo = true; this.isServicePopulating = 'CLCN-E'; }
                }
              }, error => {
                this.totalPrice = null;
                this.serviceInfoErrorFlag = true;
                this.isServicePopulating = 'CLCN-E';
                this.newBookingForm.get('confirmPickup').markAsTouched();
              }));
            this.completeClicked = 0;
          }
        }
      });
    }
  }

  setColnTimeInitData(data) {
    /**
     * initialize collection time init data
     */
    this.colnTimeFrmApiInit = {
      cutOffTm: data.cutOffTm,
      dptOpenTm: data.dptOpenTm,
      dptCloseTm: data.dptCloseTm,
    };
  }

  sortServiceProducts(a, b) {
    const aA = a.productDesc.replace(/[^a-zA-Z]/g, '');
    const bA = b.productDesc.replace(/[^a-zA-Z]/g, '');
    let aN = parseInt(a.productDesc.replace(/[^0-9]/g, ''), ConstantsVAR.DIGIT_10);
    let bN = parseInt(b.productDesc.replace(/[^0-9]/g, ''), ConstantsVAR.DIGIT_10);
    aN = (isNaN(aN)) ? 0 : aN;
    bN = (isNaN(bN)) ? 0 : bN;
    return (aA === bA) ? (aN === bN) ? 0 : (aN < bN) ? -1 : 1 : (aA > bA) ? 1 : -1;
  }

  diableFieldsForBasic() {
    this.newBookingForm.get('templateType').disable();
    this.newBookingForm.get('customerAcc').disable();
    this.newBookingForm.get('bookingRefNo').disable();
    this.newBookingForm.get('customerRefNo').disable();
  }

  disableFieldsForView() {
    Object.keys(this.newBookingForm.controls).forEach(key => {
      this.newBookingForm.get(key).disable();
    });
  }


  getDocDetails(ev) {
    this.fileDoc = ev;
  }

  setAddrCheck() {
    if (this.newBookingForm.value.bkngSndrChck) {
      if (this.pickAdresData) {
        this.sndrAdrData = this.pickAdresData;
        this.pickAdresData.typ = 'P';
        this.sndrAdrData.typ = 'S';
      }
    }
    if (this.newBookingForm.value.bkngRcrAddrChck) {
      if (this.destiAdresData) {
        this.rcvrAdrData = this.destiAdresData;
        this.destiAdresData.typ = 'D';
        this.rcvrAdrData.typ = 'R';
      }
    }
  }

  setCustomerRefNo() {
    if (this.templateDetailsFetch) {
      if (this.templateDetailsFetch.ctRfSmeBkRf) {
        this.newBookingForm.get('customerRefNo').setValue(this.newBookingForm.value.bookingRefNo);
      }
    }
  }

  checkAddressFlag(bnkgDataFetch) {
    let sndrAddrs = [], recevAddrs = [], pickAddrs = [], destiAddrs = [];
    for (let i = 0; i < bnkgDataFetch.adr.length; i++) {
      if (bnkgDataFetch.adr[i].typ === 'S') {
        sndrAddrs = bnkgDataFetch.adr[i];
        delete sndrAddrs['typ'];
      } else if (bnkgDataFetch.adr[i].typ === 'P') {
        pickAddrs = bnkgDataFetch.adr[i];
        this.addrCompanyName = pickAddrs['cNme'];
        delete pickAddrs['typ'];
      } else if (bnkgDataFetch.adr[i].typ === 'R') {
        recevAddrs = bnkgDataFetch.adr[i];
        delete recevAddrs['typ'];
      } else if (bnkgDataFetch.adr[i].typ === 'D') {
        destiAddrs = bnkgDataFetch.adr[i];
        delete destiAddrs['typ'];
      }
    }
    const sndrProps = Object.getOwnPropertyNames(sndrAddrs);
    const pickProps = Object.getOwnPropertyNames(pickAddrs);
    const recevProps = Object.getOwnPropertyNames(recevAddrs);
    const destiProps = Object.getOwnPropertyNames(destiAddrs);
    if (sndrProps.length !== pickProps.length) {
      this.newBookingForm.get('bkngSndrChck').setValue(false, { emitEvent: false });
    }
    if (recevProps.length !== destiProps.length) {
      this.newBookingForm.get('bkngRcrAddrChck').setValue(false, { emitEvent: false });
    }
    for (let j = 0; j < sndrProps.length; j++) {
      const propName = sndrProps[j];
      if (sndrAddrs[propName] !== pickAddrs[propName]) {
        this.newBookingForm.get('bkngSndrChck').setValue(false, { emitEvent: false });
        break;
      } else {
        this.newBookingForm.get('bkngSndrChck').setValue(true, { emitEvent: false });
      }
    }
    for (let k = 0; k < recevProps.length; k++) {
      const recevPropName = recevProps[k];
      if (recevAddrs[recevPropName] !== destiAddrs[recevPropName]) {
        this.newBookingForm.get('bkngRcrAddrChck').setValue(false, { emitEvent: false });
        break;
      } else {
        this.newBookingForm.get('bkngRcrAddrChck').setValue(true, { emitEvent: false });
      }
    }
    sndrAddrs['typ'] = 'S';
    destiAddrs['typ'] = 'D';
    recevAddrs['typ'] = 'R';
    pickAddrs['typ'] = 'P';
  }

  fetchBookingEdit(bkngId) {
    this._shrdt.setLoaderSrvc(true);
    document.getElementById('REMOVE_MODAL_BACKDROP').click();
    const apiName = 'fetchBookingEdit';
    this.apiUnsubscribe(apiName);

    this.subscriptions.push(this.apiSubscription[apiName] = this._booking.getBookingEditDetails(bkngId).subscribe((bkngdata) => {
      this._shrdt.setLoaderSrvc(false);
      this.getBkngDetailsSuccess = true;
      this.getBkngDetailsError = false;
      if (bkngdata) {
        this.bookingDetailsFetch = bkngdata;
        this.setPackagesList = bkngdata.pkgs;
        this.tempaccountList = [bkngdata['cusAccDtls']['cusAccId']]; // refactor
        // this.newBookingForm.get('customerAcc').setValue(bkngdata.cAccNo);
        this.newBookingForm.get('customerAcc').setValue(bkngdata['cusAccDtls']['cusAccId']);
        if (bkngdata.sId === BOOKING_STATUS.draft.id || bkngdata.sId === BOOKING_STATUS.awaiting.id) {
          this.readonlyField = false;
        } else {
          this.readonlyField = true;
          this.bookingType = 'VIEW';
          setTimeout(() => { this.changeFocus('focusOnView'); }, ConstantsVAR.MILISEC_500);
        }
        if (bkngdata.sId === BOOKING_STATUS.awaiting.id) {
          this.readonlyAwaiting = true;
          this.newBookingForm.get('bookingRefNo').disable();
          if (bkngdata.cRNm) {
            this.newBookingForm.get('customerRefNo').disable();
            this.readonlyAwaitingCRNM = true;
          }
          setTimeout(() => { this.changeFocus('pcompanyName'); }, ConstantsVAR.MILISEC_500);
        }
        if (bkngdata.sId === BOOKING_STATUS.draft.id) {
          setTimeout(() => { this.changeFocus('showBookingRef'); }, ConstantsVAR.MILISEC_500);
        }

        this.tId = bkngdata.tId;
        this.setEditBknglateValues(bkngdata);
        this.checkAddressFlag(bkngdata);
        this.editFlag = true;

        if (this.bookingType === 'VIEW') {
          let count = ConstantsVAR.VIEW_BKNG_INPUT_FIELD;
          if (bkngdata.cRFg) {
            count++;
          }
          if (bkngdata.sSidRef) {
            count++;
          }
          this.hideInsNull = (!bkngdata.insV) ? true : false;
          this.viewDisplayCount = count;
          if (!this._cd['destroyed']) {
            this._cd.detectChanges();
          }
          this.viewBookingPatches(bkngdata);
          this.disableFieldsForView();
        }

        if (this.editFlag) {
          this.SetSIDNumberOnEdit = this.newBookingForm.get('bookingRefNo').value;
          this.SetCustRefNoOnEdit = this.newBookingForm.get('customerRefNo').value;
        }
        if (this.templateList) {
          this.getTemplateDetails(bkngdata);
        }

        if (this.zeroTemplateFound || (bkngdata.tNm === ConstantsVAR.INBOUND_TMPLT || ConstantsVAR.RETURN_TMPLT)) {
          this.templateList = [
            {
              'tId': this.tId,
              'tNm': bkngdata.tNm,
              'tSts': ConstantsVAR.TEMPLATE_STATUS_ACTIVE,
              'def': true
            }];
        }
      } else {
        // ::: NO DATA IN BOOKING FETCH :::
      }
      this._shrdt.setLoaderSrvc(false);
      this.apiCallCount[apiName] = 0;
    }, error => {
      this.getBkngDetailsSuccess = false;
      this.getBkngDetailsError = true;
      this.retryMechanism(error, apiName, bkngId);
      document.getElementById('errorTemplateFetchLink').click();
      this._shrdt.setLoaderSrvc(false);
    }));

  }

  getTemplateDetails(bkngdata) {
    this.newBookingForm.patchValue({
      'templateType': this.tId
    });
    this._shrdt.setLoaderSrvc(true);
    const apiName = 'getTemplateDetails';
    this.apiUnsubscribe(apiName);

    this.subscriptions.push(this.apiSubscription[apiName] = this._template.getTemplateDetails(this.tId).subscribe((fetchData) => {
      this.editTemplateDetailsFetch = fetchData;
      this._shrdt.setLoaderSrvc(false);
      if (fetchData) {
        this.tId = fetchData.tId;
        this.shpmntConfirmBy = fetchData.sCnf;
        this.newBookingForm.get('customerAcc').disable();

        if (bkngdata.sCnf === 'R') {
          this.showCnfrmDtPckp = true;
        } else {
          this.showCnfrmDtPckp = false;
          this.newBookingForm.get('confirmPickup').clearValidators();
          this.newBookingForm.get('confirmPickup').updateValueAndValidity();
        }
        this.newBookingForm.patchValue({
          'templateType': this.editTemplateDetailsFetch.tId
        });
      } else {
        // ::: NO DATA IN FETCH TEMPLATE :::
      }
      this.apiCallCount[apiName] = 0;
    }, error => {
      this._shrdt.setLoaderSrvc(false);
      this.retryMechanism(error, apiName, bkngdata);
    }));
  }

  bookingStatus(sId) {
    /** filter the name of status using the id passed */
    const statusArr = [];

    for (const key in BOOKING_STATUS) {
      if (key) {
        statusArr.push(BOOKING_STATUS[key]);
      }
    }
    const sts = statusArr.find(el => el.id === sId);
    return sts.name;
  }

  viewBookingPatches(bkngdata) {
    let status;
    this.sId = bkngdata.sId;
    status = this.bookingStatus(bkngdata.sId);

    this.newBookingForm.get('bkngStatus').setValue(status);
    this.newBookingForm.get('bkngAwbCon').setValue(bkngdata.awb);
    this.newBookingForm.get('bkngNumbr').setValue(bkngdata.booking);

    // SERVICES AND DEL DATE
    this.setViewCollDetails();
    this.setViewDelDetails();
    this.totalPrice = bkngdata.estPs;
    this.serviceProductDetails = [
      {
        'product_id': bkngdata.prId,
        'productDesc': bkngdata.prDesc,
        'totalPrice': bkngdata.estPs,
        'dfltService': true,
        'uPrc': 'U'
      }];
    this.newBookingForm.get('serviceType').setValue(this.bookingDetailsFetch.prId);
    this.editDelvAddressFlg = false;
    this.editClctnAddressFlg = false;
    this.colnTimeBodyInit = bkngdata.pref;
  }

  tntTrackTrace(awb) {
    /**
     * method for navigating to track and trace using AWB/CON
    */
    if (this.checkAWB()) {
      const url = ConstantsURL.CONST_TNT_TRACKER + ConstantsURL.CONST_TNT_TRACKER_RES_CNTRY +
        this.logCountry + ConstantsURL.CONT_TNT_TRACKER_CON_NO + awb;
      window.open(url, '_blank');
    }
  }

  checkAWB() {
    return (this.sId === BOOKING_STATUS.collected.id || this.sId === BOOKING_STATUS.exception.id || this.sId === BOOKING_STATUS.intransit.id
      || this.sId === BOOKING_STATUS.outfordelivery.id || this.sId === BOOKING_STATUS.delivered.id);
  }

  setEditBknglateValues(bkngdata) {

    if (bkngdata.sCnf === 'R') {
      this.showCnfrmDtPckp = true;
    } else {
      this.newBookingForm.get('confirmPickup').clearValidators();
      this.newBookingForm.get('confirmPickup').updateValueAndValidity();
      this.showCnfrmDtPckp = false;
    }
    this.templateDetailsFetch = this.bookingDetailsFetch;
    this.serviceId = bkngdata.svcId;
    if (bkngdata) {
      let cnRnmTemp = '';
      (bkngdata.cnRNm.length > 0) ? cnRnmTemp = bkngdata.cnRNm[0].cnNm : cnRnmTemp = '';

      this.newBookingForm.patchValue({
        // customerAcc: bkngdata.cAccNo,
        customerAcc: bkngdata['cusAccDtls']['cusAccId'],
        templateType: bkngdata.tId,
        bookingRefNo: bkngdata.bSidNo,
        customerRefNo: bkngdata.cRNm,
        contentRefNo: cnRnmTemp,
        serviceType: bkngdata.prId,
      });
    }

    this.bookingId = bkngdata.bId;
    this.shpmntDtCnfrmBy = bkngdata.pyr;
    this.newBookingForm.get('templateType').disable();

    this.setValidators();
    this.insuranceDataPass(bkngdata);
    this.getpackageWeightData(bkngdata.pkgs);
    this.checkArrdessFlags(bkngdata.adr);
    this.getAddressData(bkngdata.adr);

    this.colnTimeBodyInit = bkngdata.pref;

  }

  formValidation() {
    if (this.newBookingForm.invalid) {
      Object.keys(this.newBookingForm.controls).forEach(key => {
        if (this.newBookingForm.get(key).invalid || this.newBookingForm.get(key).hasError('pattern')) {
          this.newBookingForm.get(key).markAsTouched();
        }
      });
      return false;
    } else {
      return true;
    }
  }

  clearValidators() {
    Object.keys(this.newBookingForm.controls).forEach(key => {
      this.newBookingForm.get(key).markAsPristine();
      if (key !== 'bookingRefNo') {
        this.newBookingForm.get(key).clearValidators();
        this.newBookingForm.get(key).updateValueAndValidity();
      }
    });
  }

  ClearBkngRefValidators() {
    this.newBookingForm.get('bookingRefNo').markAsPristine();
  }

  setValidators() {

    if (this.showCnfrmDtPckp) {
      this.newBookingForm.get('confirmPickup').setValidators([Validators.required]);
      this.newBookingForm.get('confirmPickup').updateValueAndValidity();
    } else {
      this.newBookingForm.get('confirmPickup').clearValidators();
      this.newBookingForm.get('confirmPickup').updateValueAndValidity();
    }

    this.newBookingForm.get('serviceType').setValidators([Validators.required]);
    this.newBookingForm.get('serviceType').updateValueAndValidity();

    this.setBookingRefValidator();

  }

  setBookingRefValidator() {
    if (this.templateDetailsFetch.sSidRef) {
      this.newBookingForm.get('bookingRefNo').setValidators([Validators.required, Validators.pattern('[a-zA-Z0-9]*')]);
      this.newBookingForm.get('bookingRefNo').updateValueAndValidity();

      // below code is for setting customer number mandatory
      this.newBookingForm.get('customerRefNo').setValidators([Validators.required, Validators.pattern('^[a-zA-Z0-9-]+$')]);
      this.newBookingForm.get('customerRefNo').updateValueAndValidity();
    } else {
      this.newBookingForm.get('bookingRefNo').clearValidators();
      this.newBookingForm.get('bookingRefNo').updateValueAndValidity();

      // below code is for setting customer number mandatory
      this.newBookingForm.get('customerRefNo').clearValidators();
      this.newBookingForm.get('customerRefNo').updateValueAndValidity();
    }
  }

  fileData(evt) {
    this.file = evt;
  }

  saveBooking() {
    if (!((!(this.duePickUpDate.wDys && this.duePickUpDate.dDt) && this.showCnfrmDtPckp) || !this.totalPrice ||
      !this.newBookingForm.get('serviceType').value || (!this.newBookingForm.get('confirmPickup').value && this.showCnfrmDtPckp))) {
      this._shrdt.setLoaderSrvc(true);
      this.saveBtnClicked = true;
      this.setValidators();

      this.packWeighFrmVldtn = this._packWeigh.formValidation();
      this.insrInvcFrmVldtn = this._insrInvc.formValidation();
      this.gnrlInfoFrmVldtn = this.formValidation();
      this.colnTimeFrmVldtn = this.showCnfrmDtPckp ?
        (this._prdtsOffrd ? this._prdtsOffrd._colnTime.isCollectionTimeFormValid() : false) : true;

      if (this._sndrAddrss) {
        this.sndrAddrssFrmVldtn = this._sndrAddrss.formValidationPattern() && this._sndrAddrss.formValidation(true);
      }
      if (this._pckpAddrss) {
        this.pckpAddrssFrmVldtn = this._pckpAddrss.formValidationPattern() && this._pckpAddrss.formValidation(true);
      }
      if (this._rcvrAddrss) {
        this.rcvrAddrssFrmVldtn = this._rcvrAddrss.formValidationPattern() && this._rcvrAddrss.formValidation(true);
      }
      if (this._dstntnAddrss) {
        this.dstntnAddrssFrmVldtn = this._dstntnAddrss.formValidationPattern() && this._dstntnAddrss.formValidation(true);
      }

      if (this.isAllFormsValid()) {
        this.FormError = false;
      } else {
        this.FormError = true;
      }
      this._shrdt.setLoaderSrvc(false);

      if (this.gnrlInfoFrmVldtn) {
        this.onBlurMethod('', 'NEWBKNG');
      }
    }
  }

  boxClose() {
    this.FormError = false;
  }

  generateBookingRef() {
    let tempId;
    if (this.templateDetailsFetch) {
      tempId = this.templateDetailsFetch.tId;
      const apiName = 'generateBookingRef';
      this.apiUnsubscribe(apiName);

      this.subscriptions.push(this.apiSubscription[apiName] = this._booking.generateBookingReference(tempId).subscribe((bookrefdata) => {
        this.newBookingForm.patchValue({
          'bookingRefNo': bookrefdata
        });
        if (this.templateDetailsFetch.ctRfSmeBkRf) {
          this.newBookingForm.patchValue({
            'customerRefNo': bookrefdata
          });
        }
        this.apiCallCount[apiName] = 0;
      }, error => {
        this.retryMechanism(error, apiName, '');
      }));
    }
  }

  onBlurMethod(event?, flag?) {

    let check = true;
    if (event) {
      if (event.relatedTarget) {
        if (event.relatedTarget.id === 'SaveAsDraft'
          || event.relatedTarget.id === 'Complete'
          || event.relatedTarget.id === 'save-changes') {
          check = false;
        }
      }
    }
    if (check) {
      this.checkCustomer(flag); // call this directly when SID check not required
    }
  }

  checkCustomer(flag) {
    if ((this.templateDetailsFetch ? this.templateDetailsFetch.cRFg : false) ||
      (this.editTemplateDetailsFetch ? this.editTemplateDetailsFetch.cRFg : false)) {
      const tempCstmrRefno = this.newBookingForm.get('customerRefNo').value;
      this.uniqueCustRefDataErrorflag = 'false';
      if (tempCstmrRefno) {
        if (this.editFlag && this.SetCustRefNoOnEdit === tempCstmrRefno) {
          this.uniqueCustRefError = null;
          this.uniqueCustRefDataErrorflag = 'false';
          this.callBkngDraft(flag);
        } else {
          const apiName = 'checkCustomer';
          this.apiUnsubscribe(apiName);

          this.subscriptions.push(this.apiSubscription[apiName] =
            this._booking.getUniqueCustomrRef(tempCstmrRefno).subscribe(uniqueCustrefdata => {
              this.uniqueCustRefDataErrorflag = uniqueCustrefdata.toString().toLowerCase();
              this.uniqueCustRefError = false;
              if (uniqueCustrefdata.toString().toLowerCase() === 'false'
                && this.uniqueBookRefDataErrorflag.toString().toLowerCase() === 'false') {
                this.callBkngDraft(flag);
              } else if (uniqueCustrefdata.toString().toLowerCase() === 'true') {
                this.callBkngDraft(flag, 'ERR');
              }
              this.apiCallCount[apiName] = 0;
            }, error => {
              this.uniqueCustRefError = true;
              this.retryMechanism(error, apiName, flag);
            }));
        }
      } else {
        this.callBkngDraft(flag);
      }
    } else {
      if (this.uniqueBookRefDataErrorflag.toString().toLowerCase() === 'false') {
        this.callBkngDraft(flag);
      }
    }
  }

  callBkngDraft(flag, err?) {
    if (flag === 'NEWBKNG') {
      if (this.isAllFormsValid() && !err) {
        this.FormError = false;
        // when booking is sender confirm (awaiting) then update else new booking
        if (this.bookingType === 'EDIT' && this.bookingDetailsFetch.sId === BOOKING_STATUS.awaiting.id) {
          this.createBookingBody('UPDATE');
        } else {
          if (this.bookingType === 'EDIT') { this.bookingType = 'NEW'; }
          this.createBookingBody('NEWBKNG');
        }
      } else {
        this.FormError = true;
      }
    } else if (flag === 'DRAFT') {
      // this section can be optimize
      if (this.gnrlInfoFrmVldtn && !(this.bookingType === 'EDIT') && !err) {
        this.FormError = false;
        this.createBookingBody('DRAFT');
      } else if (this.gnrlInfoFrmVldtn && (this.bookingType === 'EDIT') && !err) {
        this.FormError = false;
        this.createBookingBody('DRAFT');
      } else {
        this.FormError = true;
      }
    }
  }

  isAllFormsValid() {
    return (this.gnrlInfoFrmVldtn && this.colnTimeFrmVldtn && this.packWeighFrmVldtn && this.insrInvcFrmVldtn && this.sndrAddrssFrmVldtn
      && this.pckpAddrssFrmVldtn && this.rcvrAddrssFrmVldtn && this.dstntnAddrssFrmVldtn);
  }


  OnContetnRef($event) {
    const tempCntntRefno = this.newBookingForm.get('contentRefNo').value;
    if (tempCntntRefno) {
      const apiName = 'OnContetnRef';
      this.apiUnsubscribe(apiName);

      this.subscriptions.push(this.apiSubscription[apiName] =
        this._booking.getUniqueCntntRef(tempCntntRefno).subscribe(uniqueCntntrefdata => {
          this.uniqueCntntRefData = uniqueCntntrefdata;
          this.apiCallCount[apiName] = 0;
        }, error => {
          this.retryMechanism(error, apiName, $event);
        }));
    }
  }

  createBookingBody(flag) {
    this._shrdt.setLoaderSrvc(true);
    this._shrdt.setSearchInput('');
    this.addressArrayCreation();
    let pckupdate;
    let duedate;
    if (this.showCnfrmDtPckp) {
      pckupdate = this._shrdFnctns.formatDate(this.newBookingForm.value.confirmPickup);
      duedate = this._shrdFnctns.formatDate(this.duePickUpDate.dDt);
    } else {
      pckupdate = new Date();
      duedate = new Date();
    }

    let bkngRefNumber;
    (!this.newBookingForm.getRawValue().bookingRefNo) ? bkngRefNumber = ''
      : bkngRefNumber = this.newBookingForm.getRawValue().bookingRefNo;

    let custRefNumber;
    if (!this.newBookingForm.getRawValue().customerRefNo) {
      if (this.templateDetailsFetch.ctRfSmeBkRf) {
        this.newBookingForm.patchValue({
          'customerRefNo': this.newBookingForm.get('bookingRefNo').value
        });
        custRefNumber = this.newBookingForm.get('customerRefNo').value;
      } else {
        custRefNumber = '';
      }
    } else {
      custRefNumber = this.newBookingForm.get('customerRefNo').value;
    }

    if (this.serviceProductDetails) {
      for (let i = 0; i < this.serviceProductDetails.length; i++) {
        if (this.serviceProductDetails[i].product_id === this.newBookingForm.get('serviceType').value) {
          this.prDesc = this.serviceProductDetails[i].productDesc;
          this.prId = this.serviceProductDetails[i].product_id;
        }
        if (i === this.serviceProductDetails.length - 1) {
          if (!this.prDesc) { this.prDesc = ''; }
          if (!this.prId) { this.prId = ''; }
        }
      }
    } else {
      if (!this.prDesc) { this.prDesc = ''; }
      if (!this.prId) { this.prId = ''; }
    }

    if (isNullOrUndefined(this.insuranceVal)) { this.insuranceVal = null; }
    if (isNullOrUndefined(this.invoiceVal)) { this.invoiceVal = null; }

    this.custAccNo = this.newBookingForm.get('customerAcc').value;
    let sSidRef = '';
    let cRFg = '';
    let cnRFg = '';

    if (this.bookingDetailsFetch) {
      sSidRef = this.bookingDetailsFetch.sSidRef;
      cRFg = this.bookingDetailsFetch.cRFg;
      cnRFg = this.bookingDetailsFetch.cnRFg;
      if (!this.contentRefNum) { this.contentRefNum = this.bookingDetailsFetch.cnRNm; }
    } else {
      if (this.templateDetailsFetch) {
        sSidRef = this.templateDetailsFetch.sSidRef;
        cRFg = this.templateDetailsFetch.cRFg;
        cnRFg = this.templateDetailsFetch.cnRFg;
      }
      if (this.editTemplateDetailsFetch) {
        sSidRef = this.editTemplateDetailsFetch.sSidRef;
        cRFg = this.editTemplateDetailsFetch.cRFg;
        cnRFg = this.editTemplateDetailsFetch.cnRFg;
      }
    }

    this.bookingTemplateBody = {
      prDesc: this.prDesc,
      prId: this.prId,
      pyr: this.templateDetailsFetch.pyr,
      sCnf: this.templateDetailsFetch.sCnf,
      tNm: this.templateDetailsFetch.tNm,
      tId: this.templateDetailsFetch.tId,
      bId: this.bookingId,
      cAccNo: this.custAccNo,
      bSidNo: bkngRefNumber,
      cnRNm: this.contentRefNum,
      cRNm: custRefNumber,
      dDt: duedate,
      gDsc: this.goodsDesc,
      insC: this.insuranceValCurrency,
      insV: this.insuranceVal,
      invcC: this.invoiceValCurrency,
      invcV: this.invoiceVal,
      pDt: pckupdate,
      pkgs: this.packageFormData,
      adr: this.addressArray,
      prType: this.prType,
      docs: this.fileDoc,
      estPs: this.totalPrice,
      wDys: this.duePickUpDate ? (+(this.duePickUpDate.wDys)) : '',
      sSidRef: sSidRef,
      cRFg: cRFg,
      cnRFg: cnRFg,
      tmZnId: this.deliveryTimeZoneId,
      clTmZnId: this.collectionTimeZoneId,
      pref: this.colnTimeBody,
      dptDtl: this.colnTimeFrmApiInit,
      cAccCntry: this.logCountry,
      expDt: this.hideBkngExpr() ? null :
        this._shrdFnctns.getOnlyDate(this._bkngExpr.expirationDate)
    };
    this.bookingApiCall(flag);
  }

  bookingApiCall(flag) {
    /**
     * api call to respective booking /options:/new booking/ draft/ update booking
     */
    switch (flag) {
      case 'NEWBKNG': {
        this.completeClicked++;
        this.currentCollectionDateTime = { DATE: '', TIME: '' };
        this.getpickUplatlng(this.pickAdresData, this.destiAdresData);
        const intvl = setInterval(() => {
          if (this.currentCollectionDateTime['DATE'] || this.currentCollectionDateTime['DATE'] === 'ERROR') {
            /*
            * only check for midnight scenario when booking is receiver confirm
            */
            if (!this.showCnfrmDtPckp || (this.showCnfrmDtPckp &&
              (this.actualCollectionDateTime['DATE'] === this.currentCollectionDateTime['DATE'] ||
                this.currentCollectionDateTime['DATE'] === 'ERROR'))) {
              this._shrdt.setLoaderSrvc(false);
              this.checkColnTimeAndCallBookingAPI();
            } else {
              this._shrdt.setLoaderSrvc(false);
              document.getElementById('midnightBookingErrLink').click();
            }
            clearInterval(intvl);
          }
          setTimeout(() => { clearInterval(intvl); }, ConstantsVAR.MILISEC_60000);
        }, ConstantsVAR.MILISEC_500);
        break;
      }
      case 'DRAFT': {
        this.getSaveAsDraftService(this.bookingTemplateBody, this.file); break;
      }
      case 'UPDATE': {
        this.updateService(this.bookingTemplateBody, this.file); break;
      }
      default: this._shrdt.setLoaderSrvc(false); break;
    }
  }

  checkColnTimeAndCallBookingAPI() {
    /**
     * collection time scenarios when fails call #collectionTimeErrLink
     */
    if (this.showCnfrmDtPckp && this.isColnDateSameDay(this.newBookingForm.get('confirmPickup').value) &&
      this.collectionTimeNotAvailable()) {
      document.getElementById('collectionTimeErrLink').click();
    } else {
      this.getSaveService(this.bookingTemplateBody, this.file);
    }
  }

  collectionTimeNotAvailable() {
    /**
     * to check if the collection time still avalable for the day
     */
    const timeNowStr = this.currentCollectionDateTime['TIME'],
      sameDayTm90minModified = this._prdtsOffrd._colnTime.getTimeInDigit(
        this._prdtsOffrd._colnTime.sameDayInitialTmCalculation(timeNowStr, ColnTimeConstants.MIN_TIME_COLLECT_MINUTES_90)),
      sameDayTm30minModified = this._prdtsOffrd._colnTime.getTimeInDigit(
        this._prdtsOffrd._colnTime.sameDayInitialTmCalculation(timeNowStr, ColnTimeConstants.MIN_TIME_COLLECT_MINUTES_30));

    if (timeNowStr.length) {
      /**
       * check if afternoon time is available check with afternoon end time
       * else check with morning end time
       */
      if (sameDayTm30minModified > this._prdtsOffrd._colnTime.getTimeInDigit(this.colnTimeFrmApiInit.cutOffTm)) {
        return true;
      } else {
        /**
         * first checck the afternoon time then morning time.
         */
        let ntAvlbl;
        if (this.isColnTimeValid('AFTRN')) {
          ntAvlbl = (sameDayTm90minModified > this._prdtsOffrd._colnTime.getTimeInDigit(this.colnTimeBody.alClEnTm)
            || sameDayTm30minModified > this._prdtsOffrd._colnTime.getTimeInDigit(this.colnTimeBody.alClStTm)) ? true : false;
        }
        if (this.isColnTimeValid('MRNG') && !ntAvlbl) {
          ntAvlbl = (sameDayTm90minModified > this._prdtsOffrd._colnTime.getTimeInDigit(this.colnTimeBody.pfClEnTm)
            || sameDayTm30minModified > this._prdtsOffrd._colnTime.getTimeInDigit(this.colnTimeBody.pfClStTm)) ? true : false;
        }
        return ntAvlbl;
      }
    } else {
      return true;
    }
  }

  isColnTimeValid(mrngOrAftrnFlag) {
    /**
     * check if the morning or afternoon collection time data
     * is present in the object. data are oonly present 
     * if the time are selected from dropdown
     */
    let isValid;
    switch (mrngOrAftrnFlag) {
      case 'MRNG': isValid = this.colnTimeBody.pfClStTm && this.colnTimeBody.pfClEnTm; break;
      case 'AFTRN': isValid = this.colnTimeBody.alClStTm && this.colnTimeBody.alClEnTm; break;
      default: isValid = false; break;
    }

    return isValid;
  }

  loadNewPickUpData() {
    /**
     * load the pickup / collection date data again from API
     */
    this.pickupData = [];
    this.newBookingForm.value.confirmPickup = '';
    this.newBookingForm.get('confirmPickup').markAsUntouched();
    this.completeClicked = 0;
    this.actualCollectionDateTime = { DATE: '', TIME: '' };
    this.currentCollectionDateTime = { DATE: '', TIME: '' };
    this.getpickUplatlng(this.pickAdresData, this.destiAdresData);
    this.callExpectedDt(this.collectionRequestBody);
    document.getElementById('REMOVE_MODAL_BACKDROP').click();
  }

  getSaveService(bookingBody, file) {
    this._shrdt.setLoaderSrvc(true);
    this.bkngSaveError = false;
    this.bkngSaveDraftError = false;
    const apiName = 'getSaveService';
    this.apiUnsubscribe(apiName);

    this.subscriptions.push(this.apiSubscription[apiName] = this._booking.saveNewBooking(bookingBody, file).subscribe((data) => {
      this._shrdt.setLoaderSrvc(false);
      let isBasic;
      let type = 'N';

      /* FOR WIZARD FROM UI */
      if (this.bookingType === 'INB' || this.bookingType === 'RET') {
        isBasic = true;
        localStorage.setItem('bkngBodyBasic', JSON.stringify(this.bookingTemplateBody));
        localStorage.setItem('tmplBodyBasic', JSON.stringify(this.templateDetailsFetch));
      } else {
        isBasic = false;
        this.makeDefaultTemplate();
      }
      /* FOR WIZARD FROM UI */

      type = this.getBookingType();

      localStorage.setItem('emailCounter', '0');
      this._router.navigate(['/booking/dashboard']);
      const saveData = {
        'bId': data, 'refNum': bookingBody.bSidNo, 'type': type, 'country': this.logCountry,
        'status': true, 'sCnf': this.shpmntConfirmBy, 'isBasic': isBasic, 'accNo': this.custAccNo
      };
      this._shrdt.bkngSveScs(saveData);
      this.apiCallCount[apiName] = 0;
    }, (error) => {
      let err;
      this._shrdt.setLoaderSrvc(false);
      if (typeof error === typeof 'string') {
        err = JSON.parse(error);
        this.debugMessage = (err.ApiError.status === ConstantsVAR.API_STATUS_CODE_409) ? err.ApiError.debugMessage : '';
        if (this._calltoken) { this._calltoken.callBaseService(err.ApiError.status); }
      } else {
        this.debugMessage = '';
        if (this._calltoken) {
          this._calltoken.callBaseService(error);
        }
      }
      this.bkngSaveError = true;
      this.bkngSaveDraftError = false;
      const dta = { 'bookingBody': bookingBody, 'file': file };
      this.retryMechanism(error, apiName, dta);
    }));
  }

  getBookingType() {
    let type = 'N';
    switch (this.bookingType) {
      case 'INB': type = 'I'; break;
      case 'RET': type = 'R'; break;
      case 'NEW': type = 'N'; break;
      case 'EDIT': type = 'E'; break;
      default: type = 'N'; break;
    }
    return type;
  }

  updateService(bookingBody, file) {
    this._shrdt.setLoaderSrvc(true);
    this.bkngSaveError = false;
    this.bkngSaveDraftError = false;
    const apiName = 'updateService';
    this.apiUnsubscribe(apiName);

    this.subscriptions.push(this.apiSubscription[apiName] = this._booking.updateBooking(bookingBody, file).subscribe((data) => {
      this._shrdt.setLoaderSrvc(false);
      this.makeDefaultTemplate();
      this._router.navigate(['/booking/dashboard']);
      const saveData = { 'refNum': bookingBody.bSidNo, 'status': true, 'sCnf': this.shpmntConfirmBy };
      this._shrdt.bkngSveDrftScs(saveData);
      this.apiCallCount[apiName] = 0;
    }, (error) => {
      this._shrdt.setLoaderSrvc(false);
      this.bkngSaveError = true;
      let err;

      if (typeof error === typeof 'string') {
        err = JSON.parse(error);
        this.debugMessage = (err.ApiError.status === ConstantsVAR.API_STATUS_CODE_409) ? err.ApiError.debugMessage : '';
        if (this._calltoken) { this._calltoken.callBaseService(err.ApiError.status); }
      } else {
        this.debugMessage = '';
        if (this._calltoken) {
          this._calltoken.callBaseService(error);
        }
      }
      const dta = { 'bookingBody': bookingBody, 'file': file };
      this.retryMechanism(error, apiName, dta);
    }));
  }

  getSaveAsDraftService(bookingBody, file) {
    this._shrdt.setLoaderSrvc(true);
    this.bkngSaveDraftError = false;
    this.bkngSaveError = false;
    const apiName = 'getSaveAsDraftService';
    this.apiUnsubscribe(apiName);

    this.subscriptions.push(this.apiSubscription[apiName] = this._booking.saveAsDraftBooking(bookingBody, file).subscribe((data) => {
      this._shrdt.setLoaderSrvc(false);
      this.makeDefaultTemplate();
      this._router.navigate(['/booking/dashboard']);
      const saveData = { 'refNum': bookingBody.bSidNo, 'status': true };
      this._shrdt.bkngSveDrftScs(saveData);
      this.apiCallCount[apiName] = 0;
    }, (error) => {
      this._shrdt.setLoaderSrvc(false);
      this.bkngSaveDraftError = true;
      const dta = { 'bookingBody': bookingBody, 'file': file };
      this.retryMechanism(error, apiName, dta);
    }));
  }

  fetchTemplateList() {
    this._shrdt.setLoaderSrvc(true);
    let defaultFound = false;
    const accountListBody: AccountListDTO = {
      'cAccNoLi': this.accountList
    };
    document.getElementById('REMOVE_MODAL_BACKDROP').click();
    const apiName = 'fetchTemplateList';
    this.apiUnsubscribe(apiName);

    this.subscriptions.push(this.apiSubscription[apiName] = this._template.getTemplateListDashboard(accountListBody).subscribe(listdata => {
      this.templateList = listdata;
      this.templateListSuccess = true;
      this.templateListError = false;
      this._shrdt.setLoaderSrvc(false);
      if (this.templateList) {
        if (this.templateList.length > 0) {
          this.templateList.sort(function (a, b) {
            a = a.tNm.toLowerCase();
            b = b.tNm.toLowerCase(); return (a > b) ? 1 : ((b > a) ? -1 : 0);
          });
          this.zeroTemplateFound = false;
          if (this.bookingType === 'EDIT') {
            this.fetchBookingEdit(this.bkngId);
          } else {
            for (let i = 0; i < this.templateList.length; i++) {
              if (this.templateList[i].def === true) {
                this.oldDefaultTid = this.templateList[i].tId;
                this.fetchTemplateDetails(this.templateList[i].tId);
                defaultFound = true;
                break;
              }
              if (i === this.templateList.length - 1) {
                if (!defaultFound) {
                  this._shrdt.setLoaderSrvc(false);
                  document.getElementById('noDefTemplateLink').click();
                }
              }
            }
          }
        } else {
          this.callNoTemplateBlock();
        }
        setTimeout(() => {
          try {
            document.getElementById('templateType').focus();
          } catch (e) { }
        }, ConstantsVAR.MILISEC_900);
      } else {
        this.callNoTemplateBlock();
      }
      this.apiCallCount[apiName] = 0;
    }, error => {
      this._shrdt.setLoaderSrvc(false);
      this.templateListSuccess = false;
      this.templateListError = true;
      this.zeroTemplateFound = true;
      this.retryMechanism(error, apiName, '');
      if (this.bookingType === 'EDIT') {
        this.fetchBookingEdit(this.bkngId);
      } else {
        document.getElementById('errorTemplateFetchLink').click();
      }
    }));
  }

  callNoTemplateBlock() {
    this.zeroTemplateFound = true;
    if (this.bookingType === 'EDIT') {
      this.fetchBookingEdit(this.bkngId);
    } else {
      document.getElementById('noTemplateLink').click();
    }
    this._shrdt.setLoaderSrvc(false);
  }

  fetchTemplateDetails(tempdata) {
    this._shrdt.setLoaderSrvc(true);
    this.templateDetailsFetch = '';
    document.getElementById('REMOVE_MODAL_BACKDROP').click();
    const apiName = 'fetchTemplateDetails';
    this.apiUnsubscribe(apiName);

    this.subscriptions.push(this.apiSubscription[apiName] = this._template.getTemplateDetails(tempdata).subscribe((dataFetch) => {
      this._shrdt.setLoaderSrvc(false);
      if (dataFetch) {
        this.templateDetailsFetch = dataFetch;
        this.setPackagesList = this.templateDetailsFetch.pkgs;
        this.tId = dataFetch.tId;
        this.tempaccountList = [dataFetch['cusAccDtls']['cusAccId']];
        this.accountNumber = [dataFetch['cusAccDtls']];
        this._shrdt.setSelectedAccountIsFedex(this._shrdt.isFedexBoolean(dataFetch['cusAccDtls']['accTyp']));
        // this.newBookingForm.get('customerAcc').setValue(this.tempaccountList[0]);
        this.newBookingForm.get('customerAcc').setValue(dataFetch['cusAccDtls']['cusAccId']);
        this.newBookingForm.get('customerAcc').disable();
        if (this.basicBooking === ConstantsVAR.INBOUND || this.basicBooking === ConstantsVAR.RETURN) {
          this.templateList = [{
            'tId': dataFetch.tId,
            'tNm': dataFetch.tNm,
            'tSts': dataFetch.tmpSts
          }];
          setTimeout(() => {
            try {
              document.getElementById('pcompanyName').focus();
            } catch (e) { }
          }, ConstantsVAR.MILISEC_900);
        }
        this.shpmntConfirmBy = dataFetch.sCnf;
        this.fetchTempDetailsError = false;
        this.fetchTempDetailsSuccess = true;
        this.setTemplateValues(dataFetch);
        this.checkAddressFlag(this.templateDetailsFetch);
        this.checkArrdessFlags(this.templateDetailsFetch.adr);
        if (this.templateDetailsFetch.gSidReFn) {
          this.generateBookingRef();
        }
        this.serviceInformationDetails(true);
        if (!this._cd['destroyed']) {
          this._cd.detectChanges();
        }
        this.templateChanged++;
      } else {
        // ERROR IN TEMPLATE FETCH ::: NO DATA
      }
      this.apiCallCount[apiName] = 0;
    }, error => {
      this._shrdt.setLoaderSrvc(false);
      this.fetchTempDetailsError = true;
      this.fetchTempDetailsSuccess = false;
      this.retryMechanism(error, apiName, tempdata);
      document.getElementById('errorTemplateFetchLink').click();
    }));
  }

  serviceInformationDetails(flag?) {
    if (this.bookingType !== 'VIEW') {
      if (isNullOrUndefined(this.tId)) {
        if (this.editTemplateDetailsFetch) {
          this.tId = this.editTemplateDetailsFetch.tId;
        }
      }
      if (flag) {
        if (this.templateDetailsFetch) {
          for (let i = 0; i < this.templateDetailsFetch.adr.length; i++) {
            if (this.templateDetailsFetch.adr[i].typ === 'P') {
              this.sndrCntry = this.templateDetailsFetch.adr[i].cd;
              this.sndrTwn = this.templateDetailsFetch.adr[i].cty;
              this.sndrPo = this.templateDetailsFetch.adr[i].pCd;
            }
            if (this.templateDetailsFetch.adr[i].typ === 'D') {
              this.destiCntry = this.templateDetailsFetch.adr[i].cd;
              this.destiTwn = this.templateDetailsFetch.adr[i].cty;
              this.destiPo = this.templateDetailsFetch.adr[i].pCd;
            }
          }
          let sAdr, dAdr;
          this.templateDetailsFetch.adr.filter(el => {
            if (el.typ === 'P') {
              sAdr = this.isNullObject(el);
            } if (el.typ === 'D') {
              dAdr = this.isNullObject(el);
            }
          });
        }
      } else {
        if (this.pckAddrDimensionData) {
          this.sndrCntry = this.pckAddrDimensionData.cd;
          this.sndrTwn = this.pckAddrDimensionData.cty;
          this.sndrPo = this.pckAddrDimensionData.pCd;
        }

        if (this.destiAddrdimensionData) {
          this.destiCntry = this.destiAddrdimensionData.cd;
          this.destiTwn = this.destiAddrdimensionData.cty;
          this.destiPo = this.destiAddrdimensionData.pCd;
        }
      }

      if (this.packDimensionData) {
        this.weight = this.packDimensionData.wt;
        this.totalVolume = this.packDimensionData.vol;
        this.quantity = this.packDimensionData.quant;
        this.prType = this.packDimensionData.prType;
      } else {
        if (this.templateDetailsFetch) {
          if (this.templateDetailsFetch.pkgs) {
            this.weight = 0;
            this.quantity = 0;
            let volumeTemp = 0;
            const pcktypArray = [],
              envTempArr = [];
            const untTyp = this._packWeigh ? this._packWeigh.packageForm.get('unitsType').value : '';
            const factor = this._shrdFnctns.unitConversion(untTyp, UNITS.VOLUME);

            for (let j = 0; j < this.templateDetailsFetch.pkgs.length; j++) {

              this.weight += this.weight + this.templateDetailsFetch.pkgs[j].wg;
              this.quantity += this.quantity + this.templateDetailsFetch.pkgs[j].q;

              volumeTemp += +((parseFloat(this.templateDetailsFetch.pkgs[j].l) *
                parseFloat(this.templateDetailsFetch.pkgs[j].h) *
                parseFloat(this.templateDetailsFetch.pkgs[j].wd))
                / (Math.pow(UNITS.M2CM - factor, UNITS.ROUNDOFF_POW)));

              this.totalVolume = this._shrdFnctns.roundUp3digit(volumeTemp);

              pcktypArray.push(this.templateDetailsFetch.pkgs[j].id);
              if (this.templateDetailsFetch.pkgs[j].cnts === this.goodsNonDocs) {
                envTempArr.push(true);
              }

              if (j === (this.templateDetailsFetch.pkgs.length - 1)) {
                // TODO : write in shared function
                if ((pcktypArray.indexOf(FORMS.PACKAGE.TYPE.BOX.ID) > -1) ||
                  (pcktypArray.indexOf(FORMS.PACKAGE.TYPE.PALLET.ID) > -1) ||
                  ((pcktypArray.indexOf(FORMS.PACKAGE.TYPE.ENVELOPE.ID) > -1) &&
                    (envTempArr.indexOf(true) > -1))) {
                  this.prType = FORMS.PACKAGE.PRODUCT_TYPE.NON_DOC;
                } else {
                  this.prType = FORMS.PACKAGE.PRODUCT_TYPE.DOC;
                }
              }
            }
          }
        }
      }

      this.insuranceVal = isNullOrUndefined(this.insuranceVal) ? null : parseFloat(this.insuranceVal);
      this.invoiceVal = isNullOrUndefined(this.invoiceVal) ? null : parseFloat(this.invoiceVal)
      const serviceInfo = {
        'tId': this.tId,
        's_adr': {
          'cnr': this.sndrCntry,
          'twn': this.sndrTwn,
          'po': this.sndrPo
        },
        'd_adr': {
          'cnr': this.destiCntry,
          'twn': this.destiTwn,
          'po': this.destiPo
        },
        'c_time': this.collectionTime(),
        'product': {
          'type': this.prType
        },
        'ins': {
          'i_val': this.insuranceVal,
          'g_val': this.invoiceVal,
        },
        'cur': this.invoiceValCurrency,
        'c_dtls': {
          't_wt': this.weight,
          't_vol': this.totalVolume,
          't_piece': this.quantity
        },
        'ac': {
          'nbr': this.newBookingForm.get('customerAcc').value,
          'cnr': this.logCountry
        },
        'tOPy': ConstantsVAR.TERMS_OF_PAYMENT
      };
      this.serviceInfoProducts = serviceInfo;
      if (!(isNullOrUndefined(serviceInfo.tId) || isNullOrUndefined(serviceInfo.s_adr.cnr) || isNullOrUndefined(serviceInfo.s_adr.twn)
        || (isNullOrUndefined(serviceInfo.s_adr.po) && this.postalAware['PA']) || isNullOrUndefined(serviceInfo.d_adr.cnr) ||
        (isNullOrUndefined(serviceInfo.d_adr.po) && this.postalAware['DA'])
        || isNullOrUndefined(serviceInfo.d_adr.twn) || isNullOrUndefined(serviceInfo.c_time)
        || isNullOrUndefined(serviceInfo.product.type)
        || isNullOrUndefined(serviceInfo.cur) || isNullOrUndefined(serviceInfo.c_dtls.t_wt) || isNullOrUndefined(serviceInfo.c_dtls.t_vol)
        || isNullOrUndefined(serviceInfo.c_dtls.t_piece))) {
        if (this.previousServiceInfo !== {} && this.previousServiceInfo) {
          if ((this.previousServiceInfo.s_adr.cnr !== serviceInfo.s_adr.cnr ||
            this.previousServiceInfo.s_adr.twn !== serviceInfo.s_adr.twn || this.previousServiceInfo.s_adr.po !== serviceInfo.s_adr.po ||
            this.previousServiceInfo.d_adr.cnr !== serviceInfo.d_adr.cnr || this.previousServiceInfo.d_adr.twn !== serviceInfo.d_adr.twn
            || this.previousServiceInfo.d_adr.po !== serviceInfo.d_adr.po
            || this.previousServiceInfo.product.type !== serviceInfo.product.type || this.previousServiceInfo.cur !== serviceInfo.cur ||
            this.previousServiceInfo.c_dtls.t_wt !== serviceInfo.c_dtls.t_wt
            || this.previousServiceInfo.c_dtls.t_vol !== serviceInfo.c_dtls.t_vol
            || this.previousServiceInfo.c_dtls.t_piece !== serviceInfo.c_dtls.t_piece
            || this.previousServiceInfo.ins.g_val !== serviceInfo.ins.g_val
            || this.previousServiceInfo.ins.i_val !== serviceInfo.ins.i_val)) {
            this.previousServiceInfo = serviceInfo;
            this.serviceProductDetails = [];
            this.newBookingForm.get('serviceType').reset();
            this.resetServiceSectionData();
            const per = this.previousServiceInfo.ins.g_val * FORMS.INSURANCE.INSRNC_VAL.MAX_PERCENTAGE;
            if (this.previousServiceInfo.ins.g_val >= ConstantsVAR.MINIMUM_INVOICE_VALUE) {
              if (per < this.previousServiceInfo.ins.i_val) {
                this.apiErrorServiceInfo = true;
                this.incmpltServiceInfo = false;
                this.pickupData = [];
              } else {
                let noWeight = false;
                this.packageFormData.filter(el => {
                  el.wg = parseFloat(el.wg);
                  if (el.wg === 0 || el.wg < ConstantsVAR.MINIMUM_INVOICE_VALUE || isNaN(el.wg) || el.wg > FORMS.PACKAGE.WEIGHT.MAX) {
                    noWeight = true;
                  }
                });
                if (this.previousServiceInfo.c_dtls.t_wt && this.previousServiceInfo.c_dtls.t_vol && !noWeight) {
                  this.callServiceInfoService(serviceInfo, flag);
                  this.incmpltServiceInfo = false;
                } else {
                  this.incmpltServiceInfo = true;
                  this.pickupData = [];
                }
              }
            } else {
              this.apiErrorServiceInfo = true;
              this.incmpltServiceInfo = false;
              this.pickupData = [];
            }
            if (!this.previousServiceInfo.c_dtls.t_wt || isNaN(this.previousServiceInfo.c_dtls.t_vol)) {
              this.incmpltServiceInfo = true;
              this.pickupData = [];
            }
          }
        } else if (!this.previousServiceInfo) {
          this.previousServiceInfo = serviceInfo;
          this.serviceProductDetails = [];
          this.newBookingForm.get('serviceType').reset();
          this.resetServiceSectionData();

          if (this.previousServiceInfo.ins.g_val) {
            if (this.previousServiceInfo.c_dtls.t_wt && this.previousServiceInfo.c_dtls.t_vol) {
              this.callServiceInfoService(serviceInfo, flag);
              this.incmpltServiceInfo = false;
            } else if (this.previousServiceInfo.c_dtls.t_wt === 0 || isNaN(this.previousServiceInfo.c_dtls.t_vol)) {
              this.incmpltServiceInfo = true;
              this.apiErrorServiceInfo = false;
            }
          } else {
            if (this.previousServiceInfo.c_dtls.t_wt && this.previousServiceInfo.c_dtls.t_vol) {
              this.incmpltServiceInfo = false;
              this.apiErrorServiceInfo = true;
            }
          }
        }
      } else {
        this.incmpltServiceInfo = true;
        this.previousServiceInfo = serviceInfo;
        this.serviceProductDetails = [];
        this.pickupData = [];
        this.totalPrice = null;
        this.noDefaultService = false;
        this.duePickUpDate = ConstantsJson.duePickUpDate_INIT;
        this.newBookingForm.get('confirmPickup').setValue('');
        this.newBookingForm.get('serviceType').setValue('');
      }
    } else if (this.bookingType === 'VIEW') {
      this.serviceProductDetails = [
        {
          'product_id': this.bookingDetailsFetch.prId,
          'productDesc': this.bookingDetailsFetch.prDesc,
          'totalPrice': this.bookingDetailsFetch.estPs,
          'dfltService': true,
          'uPrc': 'U'
        }];
      this.totalPrice = this.bookingDetailsFetch.estPs;
      this.newBookingForm.get('serviceType').setValue(this.bookingDetailsFetch.prId);
    }
  }

  collectionTime() {
    const dateTime = new Date();
    dateTime.setDate(dateTime.getDate() + ConstantsVAR.COLN_TIME_DATEPOS_2);

    let minute, second, hour;
    if (dateTime.getMinutes() < ConstantsVAR.DIGIT_10) {
      minute = '0' + dateTime.getMinutes();
    } else {
      minute = dateTime.getMinutes();
    }

    if (dateTime.getSeconds() < ConstantsVAR.DIGIT_10) {
      second = '0' + dateTime.getSeconds();
    } else {
      second = dateTime.getSeconds();
    }
    if (dateTime.getHours() < ConstantsVAR.DIGIT_10) {
      hour = '0' + dateTime.getHours();
    } else {
      hour = dateTime.getHours();
    }
    const currentDTInfo = dateTime.getFullYear() + '-' +
      ('0' + (dateTime.getMonth() + 1)).slice(-ConstantsVAR.COLN_TIME_DATEPOS_2) + '-'
      + ('0' + dateTime.getDate()).slice(-ConstantsVAR.COLN_TIME_DATEPOS_2)
      + 'T' + hour + ':' + minute + ':' + second;

    return currentDTInfo;
  }

  isNullObject(o) {
    return Object.keys(o).every(function (x) {
      return o[x] === null;
    });
  }

  resetServiceSectionData() {
    this.totalPrice = null;
    this.duePickUpDate = ConstantsJson.duePickUpDate_INIT;
    this.previousExpecDt = null;
    this.previousDueDate = null;
    this.pickAdresDataOld = null;
    this.destiAdresDataOld = null;
  }

  callServiceInfoService(serviceInfo, flag?) {
    this.isServicePopulating = 'SRVC-S';
    this.apiErrorServiceInfo = false;
    this.noDefaultService = false;

    const apiName = 'callServiceInfoService';
    this.apiUnsubscribe(apiName);

    this.subscriptions.push(this.apiSubscription[apiName] =
      this._booking.fetchServiceInformationDetails(serviceInfo).subscribe((dataFetch) => {
        this.serviceInfoErrorFlag = false;
        if (typeof dataFetch === typeof 'string') {
          this.apiErrorServiceInfo = true;
          this.serviceProductDetails = [];
          this.pickupData = [];
          this.totalPrice = null;
          this.isServicePopulating = 'SRVC-E';
        } else {
          this.apiErrorServiceInfo = false;
          this.incmpltServiceInfo = false;
          this.serviceProductDetails = dataFetch;

          this.serviceProductDetails.sort(this.sortServiceProducts);
          if (!this.pickAdresDataOld) {
            this.pickAdresDataOld = { 'cd': '', 'cty': '', 'pCd': '' }
          }
          if (!this.destiAdresDataOld) {
            this.destiAdresDataOld = { 'cd': '', 'cty': '', 'pCd': '' }
          }

          let ServiceCount = 0;
          this.serviceProductDetails.filter((el) => {
            if (el.dfltService === true) { ServiceCount++; }
          })

          if (!ServiceCount) {
            this.noDefaultService = true;
            this.newBookingForm.get('serviceType').setValue('');
          } else {
            let serviceTypeTEMP;
            for (let i = 0; i < this.serviceProductDetails.length; i++) {
              if (this.serviceProductDetails[i].dfltService && this.serviceProductDetails[i].uPrc === 'U') {
                this.setServiceAndPrice(this.serviceProductDetails[i]);
                this.setColnTimeInitData(this.serviceProductDetails[i]);
                break;
              } else if (this.serviceProductDetails[i].dfltService && !serviceTypeTEMP) {
                serviceTypeTEMP = this.serviceProductDetails[i];
              }

              if (i === this.serviceProductDetails.length - 1 && serviceTypeTEMP) {
                this.setServiceAndPrice(serviceTypeTEMP);
                this.setColnTimeInitData(serviceTypeTEMP);
              }
            }
            if (this.bookingDetailsFetch && flag) {
              const data = this.bookingDetailsFetch;
              data['product_id'] = this.bookingDetailsFetch.prId;
              data['totalPrice'] = this.bookingDetailsFetch.estPs;
              this.setServiceAndPrice(data);

              const dptDtl: ColnTimeInitDTO = this.fetchDepotDtl();
              this.setColnTimeInitData(dptDtl);
            }
          }
          if ((this.pickAdresDataOld.cd !== this.pickAdresData.cd) || (this.pickAdresDataOld.cty !== this.pickAdresData.cty)
            || (this.pickAdresDataOld.pCd !== this.pickAdresData.pCd) || (this.destiAdresDataOld.cd !== this.destiAdresData.cd)
            || (this.destiAdresDataOld.cty !== this.destiAdresData.cty) || (this.destiAdresDataOld.pCd !== this.destiAdresData.pCd)) {
            this.pickupData = [];
            this.newBookingForm.get('confirmPickup').setValue('');
            this.getpickUplatlng(this.pickAdresData, this.destiAdresData, flag);
            this.getDelvyLatLng(this.pickAdresData, this.destiAdresData);
            this.pickAdresDataOld = this.pickAdresData;
            this.destiAdresDataOld = this.destiAdresData;
          }
          this.isServicePopulating = 'SRVC-E';
        }
        this.apiCallCount[apiName] = 0;
      }, error => {
        this.serviceProductDetails = [];
        this.pickupData = [];
        this.totalPrice = null;
        this.newBookingForm.get('serviceType').setValue('');
        this.newBookingForm.get('confirmPickup').setValue('');
        this.serviceInfoErrorFlag = true;
        this.isServicePopulating = 'SRVC-E';
        this.noDefaultService = false;
        this.duePickUpDate = ConstantsJson.duePickUpDate_INIT;

        this.retryMechanism(error, apiName, serviceInfo);
      }));
  }

  setServiceAndPrice(data) {
    this.newBookingForm.patchValue({
      'serviceType': data.product_id
    });
    this.totalPrice = data.totalPrice;
  }

  fetchDepotDtl() {
    /**
     * fetch service and depot times details from selected service from dropdown field
     */
    const dpt = this.serviceProductDetails.filter(el => {
      return el.product_id === this.newBookingForm.get('serviceType').value;
    });
    return dpt.length ? dpt[0] : [];
  }

  insuranceDataPass(data) {
    this.insuranceData = {
      'gDsc': data.gDsc,
      'insC': data.insC,
      'insV': data.insV,
      'invcV': data.invcV,
      'invcC': data.invcC,
      'doc': data.doc,
    };
    this.fileDetailsData = data.docs;
    return this.insuranceData;
  }

  getpackageWeightData(data) {
    this.packageFormData = data;
  }

  getAddressData(data) {
    this.addressArray = data;
  }

  checkArrdessFlags(val) {
    if (val) {
      for (let i = 0; i < val.length; i++) {
        if (val[i].typ === 'S') {
          this.sndrAdrData = val[i];
        } else if (val[i].typ === 'P') {
          this.pickAdresData = val[i];
          this.addrCompanyName = this.pickAdresData['cNme'];
        } else if (val[i].typ === 'R') {
          this.rcvrAdrData = val[i];
        } else if (val[i].typ === 'D') {
          this.destiAdresData = val[i];
        }
        if (i === (val.length - 1)) {
          this.checkforNullAddress();
        }
      }
    }
  }

  setTemplateValues(dataTmp) {

    this.newBookingForm.patchValue({
      // customerAcc: dataTmp.cAccNo,
      customerAcc: dataTmp['cusAccDtls']['cusAccId'],
      templateType: dataTmp.tId,
      bkngSndrChck: dataTmp.sCpFlg,
      bkngRcrAddrChck: dataTmp.rCpFlg
    });

    if (this.basicBooking === ConstantsVAR.INBOUND || this.basicBooking === ConstantsVAR.RETURN) {
      this.tempaccountList = [this.basicAccNo];
      this.newBookingForm.get('customerAcc').setValue(this.tempaccountList[0]);
    }

    if (dataTmp.sCnf === 'R') {
      this.showCnfrmDtPckp = true;
    } else {
      this.newBookingForm.get('confirmPickup').clearValidators();
      this.newBookingForm.get('confirmPickup').updateValueAndValidity();
      this.showCnfrmDtPckp = false;
    }

    if (dataTmp.svcs) {
      for (let i = 0; i < dataTmp.svcs.length; i++) {
        if (dataTmp.svcs[i].d) {
          this.serviceId = dataTmp.svcs[i].id;
          break;
        }
      }
    }

    this.setValidators();
    this.insuranceDataPass(dataTmp);
    this.getpackageWeightData(this.templateDetailsFetch.pkgs);
    this.getAddressData(this.templateDetailsFetch.adr);
    this.shpmntDtCnfrmBy = dataTmp.sCnf;
  }

  bookingInsuranceData(insrData) {
    this.goodsDesc = insrData.goodsDesc;
    this.invoiceVal = insrData.invoiceVal;
    this.invoiceValCurrency = insrData.invoiceValCurrency;
    this.insuranceVal = insrData.insuranceVal;
    this.insuranceValCurrency = insrData.insuranceValCurrency;
    this.insrDataCatch = true;
  }

  /* Get Package Array For Save Booking From Package- Weight Component */
  bookingPackageData(pckData) {
    if (pckData) {
      if (pckData.length > 0) {
        this.packageFormData = pckData;
      }
    }
  }

  bookingPackageDimensionsData(pckDimData) {
    this.packDimensionData = pckDimData;
    if (this.countPakgCall < ConstantsVAR.COUNT_PCKG_CALL) {
      const intr = setInterval(() => {
        if (this.insrDataCatch) {
          this.onClickPackageOutside('');
          clearInterval(intr);
        }
      }, ConstantsVAR.MILISEC_100);
      setTimeout(() => { clearInterval(intr); }, ConstantsVAR.MILISEC_3000);
      this.countPakgCall++;
    }
  }

  addrFormInvalid(data) {
  }

  contentRefNumbers(cntntRefNo) {
    this.contentRefNum = cntntRefNo;
  }

  bookingSenderAddressData(sndrAddrData) {
    this.setEdtAddrFlag = 'S';
    this.sndrAdrData = sndrAddrData; // send data to booking address page
    this.bkngAddrTmp = sndrAddrData;
  }

  addressEmittedData(data, flag) {
    this.addressFlagData[flag] = data;
    if (this.newBookingForm.get('bkngSndrChck').value) {
      this.addressFlagData['s'] = this.addressFlagData['p'];
    }
    if (this.newBookingForm.get('bkngRcrAddrChck').value) {
      this.addressFlagData['r'] = this.addressFlagData['d'];
    }
  }

  bookingPickupAddressData(pckAddrData) {
    this.setEdtAddrFlag = 'P';
    this.pickAdresData = pckAddrData;   // send data to booking address page
    this.pckAddrDimensionData = pckAddrData;
    if (this.newBookingForm.get('bkngSndrChck').value) {
      this.sndrAdrData = pckAddrData;
    }
    this.bkngAddrTmp = pckAddrData;
    this.addrCompanyName = pckAddrData['cNme'];
  }

  bookingReceiverAddressData(rcvrAddrData) {
    this.setEdtAddrFlag = 'R';
    this.rcvrAdrData = rcvrAddrData;
    this.bkngAddrTmp = rcvrAddrData;
  }

  bookingDestinationAddressData(destiAddrData) {
    this.setEdtAddrFlag = 'D';
    this.destiAdresData = destiAddrData;
    this.bkngAddrTmp = destiAddrData;
    this.destiAddrdimensionData = destiAddrData;
    if (this.newBookingForm.get('bkngRcrAddrChck').value) {
      this.rcvrAdrData = destiAddrData;
    }
  }

  postalAwareFlag(event, addrFlag) {
    this.postalAware[addrFlag] = event;
  }


  createAddrBody(addrData, flag) {
    // TODO: change to object literal
    if (flag === ConstantsVAR.sndrIdFlg) {
      this.addressType = 'S';
      addrData.pIn = null;
    } else if (flag === ConstantsVAR.pckIdFlg) {
      this.addressType = 'P';
    } else if (flag === ConstantsVAR.rcvrIdFlg) {
      this.addressType = 'R';
      addrData.pIn = null;
    } else if (flag === ConstantsVAR.destIdFlg) {
      this.addressType = 'D';
    }

    const addressBody: BookingAddressDTO = {
      'id': 0,
      'tId': this.templateDetailsFetch.tId,
      'cNme': addrData.cNme,
      'cd': addrData.cd,
      'l1': addrData.l1,
      'l2': addrData.l2,
      'cty': addrData.cty,
      'pCd': addrData.pCd,
      'cntry': addrData.cntry,
      'tel': addrData.tel,
      'e': addrData.e,
      'cPsn': addrData.cPsn,
      'pIn': addrData.pIn,
      'typ': this.addressType
    };

    return addressBody;
  }

  addressArrayCreation() {
    this.addressArray = [];
    this.addressArray.push(
      this.createAddrBody(this.sndrAdrData, ConstantsVAR.sndrIdFlg),
      this.createAddrBody(this.pickAdresData, ConstantsVAR.pckIdFlg),
      this.createAddrBody(this.rcvrAdrData, ConstantsVAR.rcvrIdFlg),
      this.createAddrBody(this.destiAdresData, ConstantsVAR.destIdFlg)
    );
  }

  templateFetchError() {
    this._router.navigate(['/booking/dashboard']);
  }

  createTemplateLink() {
    this._router.navigate(['/booking/wizard']);
  }

  isFieldRequired(field) {
    return (this.newBookingForm.get(field).touched && this.newBookingForm.get(field).hasError('required'));
  }

  packgValueChange(data) {
    this.bookingValueChanges = true;
  }

  packgValueChangeEmit(data) {
    this.packagedatachange = true;
  }

  insrncValueChange(data) {
    this.bookingValueChanges = true;
  }

  addrValueChange(data) {
    this.bookingValueChanges = true;
  }


  cancelSaving() {

    if (sessionStorage.getItem('srtFltrChk')) {
      this._shrdt.setSrtFltrChck(true);
    }
    if (this.searchValue) {
      this._shrdt.setSearchInput(this.searchValue);
    }
    if (this.filtersOfFilters) {
      this._shrdt.setFiltersOfFilter(this.filtersOfFilters);
    }

    document.getElementById('REMOVE_MODAL_BACKDROP').click();
    if (this.bookingValueChanges) {
      const cs = document.getElementById('cancelSaving');
      document.getElementById('cancelSavingLink').click();
      this.activeModal();
      const chkCs = setInterval(() => {
        if (cs.style.display === 'block') {
          this.changeFocus('no-cancelSaving');
          clearInterval(chkCs);
        }
      }, ConstantsVAR.MILISEC_100);
      setTimeout(() => { clearInterval(chkCs); }, ConstantsVAR.MILISEC_60000);
    } else {
      setTimeout(() => {
        this.cancelSavingConfirm();
      }, ConstantsVAR.MILISEC_100);
    }
  }

  changeFocus(elementId) {
    try {
      document.getElementById(elementId).focus();
    } catch (e) { }
  }

  closeModal() {
    this.closeCancel = 0;
  }

  activeModal() {
    this.closeCancel = 1;
  }

  isfcs() {
    this.onyes = 1;
    this.noback = 0;
  }

  noBack() {
    this.noback = 1;
  }

  cancelSavingConfirm() {
    if (this.basicBooking === ConstantsVAR.INBOUND || this.basicBooking === ConstantsVAR.RETURN) {
      this._router.navigate(['/booking/wizard']);
    } else {
      this._router.navigate(['/booking/dashboard']);
    }
    this.closeModal();
  }

  closeView() {
    const srtflt = JSON.parse(sessionStorage.getItem('srtFltrChk'));
    if (srtflt) {
      this._shrdt.setSrtFltrChck(true);
    }
    if (this.searchValue) {
      this._shrdt.setSearchInput(this.searchValue);
    }
    if (this.filtersOfFilters) {
      this._shrdt.setFiltersOfFilter(this.filtersOfFilters);
    }
    setTimeout(() => {
      this._router.navigate(['/booking/dashboard']);
    }, ConstantsVAR.MILISEC_100);
  }

  saveAsDraft() {
    this.saveBtnClicked = false;
    this.clearValidators();

    this.newBookingForm.get('bookingRefNo').clearValidators();
    this.newBookingForm.get('bookingRefNo').updateValueAndValidity();

    this.newBookingForm.get('customerRefNo').clearValidators();
    this.newBookingForm.get('customerRefNo').updateValueAndValidity();


    if (this._sndrAddrss) {
      this.sndrAddrssFrmVldtn = this._sndrAddrss.formValidation(false);
    }
    if (this._pckpAddrss) {
      this.pckpAddrssFrmVldtn = this._pckpAddrss.formValidation(false);
    }
    if (this._rcvrAddrss) {
      this.rcvrAddrssFrmVldtn = this._rcvrAddrss.formValidation(false);
    }
    if (this._dstntnAddrss) {
      this.dstntnAddrssFrmVldtn = this._dstntnAddrss.formValidation(false);
    }
    this.gnrlInfoFrmVldtn = this.formValidation();

    if (this.gnrlInfoFrmVldtn) {
      this.FormError = false;
    } else {
      this.FormError = true;
    }

    this.onBlurMethod('', 'DRAFT');
  }

  getpickUplatlng(clctnAdr, destiAdr, flag?) {
    const postalcode = clctnAdr.pCd;
    const cntryName = clctnAdr.cntry;
    const cityName = clctnAdr.cty;

    const geocoder = new google.maps.Geocoder();
    const self = this;
    geocoder.geocode({ 'address': postalcode + ' ' + cityName + ' ' + cntryName }, function (results, status) {
      if (status === google.maps.GeocoderStatus.OK) {
        this.pickUplat = results[0].geometry.location.lat();
        this.pickUplng = results[0].geometry.location.lng();
        if (this.pickUplat && this.pickUplng) {
          if (!this.readonlyField) {
            self.getCnfrmpickup(clctnAdr, destiAdr, this.pickUplat, this.pickUplng, flag);
          }
        } else {
          self.setCollectionDateError();
        }
      } else {
        self.setCollectionDateError();
      }
    });

    if (!(postalcode && this.postalAware['PA']) || !this.pickUplat || !this.pickUplng) {
      if (!this.readonlyField) {
        this.getCnfrmpickup(clctnAdr, destiAdr, this.pickUplat, this.pickUplng, flag);
      }
    } else {
      this.setCollectionDateError();
    }
  }

  setCollectionDateError() {
    this.currentCollectionDateTime['DATE'] = 'ERROR';
    this.isServicePopulating = 'CLCN-E';
    this.newBookingForm.get('confirmPickup').markAsTouched();
  }

  getCnfrmpickup(clctnAdr, destiAdr, lat, lng, flag?) {
    const timestamp = new Date().getTime() / ConstantsVAR.MILISEC_TO_SEC;
    if (lat && lng && timestamp) {
      const apiName = 'getCnfrmpickup';
      this.apiUnsubscribe(apiName);

      this.subscriptions.push(this.apiSubscription[apiName] = this._google.getTimezone(lat, lng, timestamp).subscribe((data) => {
        this.collectionTimeZoneId = data.timeZoneId;
        const date = this._shrdFnctns.getDateFromTimezone(data),
          finalDate = this._shrdFnctns.getDateInJson(date);
        this.collectionCountryDt = date;
        if (this.completeClicked) {
          this.currentCollectionDateTime['DATE'] = this._shrdFnctns.getOnlyDate(date);
          this.currentCollectionDateTime['TIME'] = this._shrdFnctns.getOnlyTimeInHourMinutes(date);
        } else {
          this.actualCollectionDateTime['DATE'] = this._shrdFnctns.getOnlyDate(date);
          this.actualCollectionDateTime['TIME'] = this._shrdFnctns.getOnlyTimeInHourMinutes(date);
        }

        this.getCnfrmpickupCall(finalDate, clctnAdr, destiAdr, lat, lng, flag);
        this.apiCallCount[apiName] = 0;
      }, error => {
        this.setCollectionDateError();
        const dta = { 'clctnAdr': clctnAdr, 'destiAdr': destiAdr, 'lat': lat, 'lng': lng };
        this.retryMechanism(error, apiName, dta);
      }));
    }
  }

  isColnDateSameDay(pickval) {
    const dt = this._shrdFnctns.getOnlyDate(this._shrdFnctns.formatDate(pickval));
    return this.actualCollectionDateTime['DATE'] === dt ? true : false;
  }

  getCnfrmpickupCall(date, clctnAdr, destiAdr, lat, lng, flag?) {
    const requestBody: PickupDTO = {
      uDt: date,
      lat: lat,
      lng: lng,
      svcId: this.newBookingForm.get('serviceType').value,
      pTyp: this.prType,
      sAdr: {
        cnr: clctnAdr.cd,
        twn: clctnAdr.cty,
        po: clctnAdr.pCd
      },
      dAdr: {
        cnr: destiAdr.cd,
        twn: destiAdr.cty,
        po: destiAdr.pCd
      },
      cutOffTm: this.colnTimeFrmApiInit['cutOffTm'], // cuttofftime value,
      dptOpenTm: this.colnTimeFrmApiInit['dptOpenTm'], // depot opentime,
      dptCloseTm: this.colnTimeFrmApiInit['dptCloseTm'] // depot close time
    }

    this.collectionRequestBody = requestBody;
    if (this.bookingType !== 'VIEW') {
      if (!(isNullOrUndefined(requestBody.sAdr.cnr) || isNullOrUndefined(requestBody.sAdr.twn)
        || (isNullOrUndefined(requestBody.sAdr.po) && this.postalAware['PA'])
        || isNullOrUndefined(requestBody.dAdr.cnr) || isNullOrUndefined(requestBody.dAdr.cnr)
        || (isNullOrUndefined(requestBody.dAdr.po) && this.postalAware['DA'])
        || isNullOrUndefined(requestBody.uDt) || isNullOrUndefined(requestBody.lat) || isNullOrUndefined(requestBody.lng)
        || isNullOrUndefined(requestBody.svcId) || isNullOrUndefined(requestBody.pTyp))) {
        this.incmpltPickupInfo = false;
        if (this.previousExpecDt) {
          if ((this.previousExpecDt.lat !== requestBody.lat) ||
            (this.previousExpecDt.lng !== requestBody.lng) ||
            (this.previousExpecDt.svcId !== requestBody.svcId) ||
            (this.previousExpecDt.pTyp !== requestBody.pTyp) ||
            (this.previousExpecDt.sAdr.cnr !== requestBody.sAdr.cnr) ||
            (this.previousExpecDt.sAdr.twn !== requestBody.sAdr.twn) ||
            (this.previousExpecDt.sAdr.po !== requestBody.sAdr.po) ||
            (this.previousExpecDt.dAdr.cnr !== requestBody.dAdr.cnr) ||
            (this.previousExpecDt.dAdr.twn !== requestBody.dAdr.twn) ||
            (this.previousExpecDt.dAdr.po !== requestBody.dAdr.po)) {
            this.previousExpecDt = requestBody;
            this.callExpectedDt(requestBody, flag);
          }
        } else if (!this.previousExpecDt) {
          this.previousExpecDt = requestBody;
          this.callExpectedDt(requestBody, flag);
        }
      } else {
        this.incmpltPickupInfo = true;
        this.pickupData = [];
        this.isServicePopulating = 'CLCN-E'
      }
    } else if (this.bookingType === 'VIEW') {
      this.setViewCollDetails();
    }
  }

  setViewCollDetails() {
    /**
     *  convert date object to string date format
     * FORMAT --- Monday, June 07 2019 (day, month date year)
     */
    const expDate = this._shrdFnctns.convertDateToUserFormat(this.bookingDetailsFetch.pDt);
    this.pickupData = [expDate];
    this.newBookingForm.patchValue({
      'confirmPickup': this.pickupData[0]
    });
  }

  callExpectedDt(requestBody, flag?) {
    const apiName = 'callExpectedDt';
    this.apiUnsubscribe(apiName);

    this.newBookingForm.get('confirmPickup').setValue('');
    this.subscriptions.push(this.apiSubscription[apiName] = this._booking.getConfirmPickUp(requestBody).subscribe((res) => {
      if (typeof res === typeof 'string') {
        this.confirmPickUpStatus = 'NODATA';
        this.isServicePopulating = 'CLCN-E';
        this.newBookingForm.get('confirmPickup').markAsTouched();
        this.pickupData = [];
      } else {
        this.confirmPickUpStatus = 'SUCCESS';
        this.pickupData = res;
        if (!this.newBookingForm.value.confirmPickup || (this.newBookingForm.value.confirmPickup === '')) {
          const pDt_avlbl = this.isSavedPickupDtAvailable();
          if (flag && pDt_avlbl['avlbl']) {
            this.newBookingForm.patchValue({ 'confirmPickup': pDt_avlbl['savedPckupDt'] });
          } else {
            this.newBookingForm.patchValue({ 'confirmPickup': this.pickupData[0] });
          }
        }
        if (!this._cd['destroyed']) { this._cd.detectChanges(); }
        this.isServicePopulating = 'CLCN-E';
        this.clctnDtSelct();
      }
      this.getDelvyLatLng(this.pickAdresData, this.destiAdresData);
      this.apiCallCount[apiName] = 0;
    }, (error) => {
      this.isServicePopulating = 'CLCN-E';
      this.confirmPickUpStatus = 'ERROR';
      this.pickupData = [];
      this.newBookingForm.get('confirmPickup').markAsTouched();
      this.retryMechanism(error, apiName, requestBody);
    }));
  }

  isSavedPickupDtAvailable() {
    /**
     * is saved Pickup Date still Available
     */
    let pDt_avlbl = {
      savedPckupDt: '',
      avlbl: false
    };
    if (this.bookingDetailsFetch) {
      const savedPckupDt = this._shrdFnctns.convertDateToUserFormat(this.bookingDetailsFetch.pDt);
      pDt_avlbl = {
        savedPckupDt: savedPckupDt,
        avlbl: this.pickupData.indexOf(savedPckupDt) > -1
      };
    }
    return pDt_avlbl;
  }

  getDelvyLatLng(clctnAdr, destiAdr) {
    const postalcode = destiAdr.pCd;
    const geocoder = new google.maps.Geocoder();
    const self = this;
    const cntryName = destiAdr.cntry;
    const cityName = destiAdr.cty;

    geocoder.geocode({ 'address': postalcode + ' ' + cityName + ' ' + cntryName }, function (results, status) {
      if (status === google.maps.GeocoderStatus.OK) {
        self.destiLat = results[0].geometry.location.lat();
        self.destiLng = results[0].geometry.location.lng();
        if (self.destiLat && self.destiLng) {
          self.getExpectedDt(clctnAdr, destiAdr, self.destiLat, self.destiLng);
        }
      }
    });
    if (!(postalcode && this.postalAware['DA']) || !this.destiLat || !this.destiLng) {
      this.getExpectedDt(clctnAdr, destiAdr, this.destiLat, this.destiLng);
    }
  }

  getExpectedDt(clctnAdr?, destiAdr?, lat?, lng?) {
    const timestamp = new Date().getTime() / ConstantsVAR.MILISEC_TO_SEC;
    if (lat && lng && timestamp) {
      const apiName = 'getExpectedDt';
      this.apiUnsubscribe(apiName);

      this.subscriptions.push(this.apiSubscription[apiName] = this._google.getTimezone(lat, lng, timestamp).subscribe((data) => {
        this.deliveryTimeZoneId = data.timeZoneId;
        const date = this._shrdFnctns.getDateFromTimezone(data),
          finalDate = this._shrdFnctns.getDateInJson(date);
        this.getExpectedDtCall(finalDate, clctnAdr, destiAdr, lat, lng);
        this.apiCallCount[apiName] = 0;
      }, error => {
        const dta = { 'clctnAdr': clctnAdr, 'destiAdr': destiAdr, 'lat': lat, 'lng': lng };
        this.retryMechanism(error, apiName, dta);
      }));
    }
  }

  getExpectedDtCall(date, clctnAdr, destiAdr, lat, lng) {
    const cDt = this._shrdFnctns.formatDate(this.newBookingForm.get('confirmPickup').value);

    const requestBody: DueDateDTO = {
      'uDt': date, // user date
      'cTm': cDt, // Collection dayte / Pick up date
      'lat': lat, // Lattitude of Delivery postal code
      'lng': lng, // Longitude of Delivery postal code
      'svcId': this.newBookingForm.get('serviceType').value,
      'pTyp': this.prType,
      'sAdr': {                    // Sender address
        'cnr': clctnAdr.cd,
        'twn': clctnAdr.cty,
        'po': clctnAdr.pCd
      },
      'dAdr': {                        // delivery address
        'cnr': destiAdr.cd,
        'twn': destiAdr.cty,
        'po': destiAdr.pCd
      }
    };

    if (this.bookingType !== 'VIEW') {
      if (!isNullOrUndefined(requestBody.uDt) &&
        !isNullOrUndefined(requestBody.cTm) &&
        !isNullOrUndefined(requestBody.lat) &&
        !isNullOrUndefined(requestBody.lng) &&
        !isNullOrUndefined(requestBody.svcId) &&
        !isNullOrUndefined(requestBody.pTyp) &&
        !isNullOrUndefined(requestBody.sAdr.cnr) &&
        !isNullOrUndefined(requestBody.sAdr.twn) &&
        !(isNullOrUndefined(requestBody.sAdr.po) && this.postalAware['PA']) &&
        !isNullOrUndefined(requestBody.dAdr.cnr) &&
        !isNullOrUndefined(requestBody.dAdr.twn) &&
        !(isNullOrUndefined(requestBody.dAdr.po) && this.postalAware['DA'])) {
        if (this.previousDueDate) {
          if ((this.previousDueDate.cTm !== requestBody.cTm) ||
            (this.previousDueDate.lat !== requestBody.lat) ||
            (this.previousDueDate.lng !== requestBody.lng) ||
            (this.previousDueDate.svcId !== requestBody.svcId) ||
            (this.previousDueDate.pTyp !== requestBody.pTyp) ||
            (this.previousDueDate.sAdr.cnr !== requestBody.sAdr.cnr) ||
            (this.previousDueDate.sAdr.twn !== requestBody.sAdr.twn) ||
            (this.previousDueDate.sAdr.po !== requestBody.sAdr.po) ||
            (this.previousDueDate.dAdr.cnr !== requestBody.dAdr.cnr) ||
            (this.previousDueDate.dAdr.twn !== requestBody.dAdr.twn) ||
            (this.previousDueDate.dAdr.po !== requestBody.dAdr.po)) {

            this.previousDueDate = requestBody;
            this.callDueDate(requestBody);
          }
        } else if (!this.previousDueDate) {
          this.previousDueDate = requestBody;
          this.callDueDate(requestBody);
        }
      } else {
        this.duePickUpDate = ConstantsJson.duePickUpDate_INIT;
      }

    } else if (this.bookingType === 'VIEW') {
      this.setViewDelDetails();
    }
  }

  setViewDelDetails() {
    /**
     * set view booking delivery date details 
     */
    const dueDate = this._shrdFnctns.convertDateToUserFormat(this.bookingDetailsFetch.dDt);
    this.duePickUpDate = {
      'dDt': dueDate,
      'wDys': this.bookingDetailsFetch.wDys
    };
  }

  callDueDate(requestBody) {
    const apiName = 'callDueDate';
    this.apiUnsubscribe(apiName);

    this.duePickUpDate = ConstantsJson.duePickUpDate_INIT;
    this.duePickUpDateAPI = '';
    this.subscriptions.push(this.apiSubscription[apiName] = this._booking.getExpectedDueDate(requestBody).subscribe((res) => {
      this.duePickUpDate = res;
      this.duePickUpDateAPI = 'SUCCESS';
      if (!this._cd['destroyed']) {
        this._cd.detectChanges();
      }
      this.apiCallCount[apiName] = 0;
    }, (error) => {
      this.duePickUpDateAPI = 'ERROR';
      this.retryMechanism(error, apiName, requestBody);
    }));
  }

  clctnDtSelct() {
    this.getExpectedDt(this.pickAdresData, this.destiAdresData, this.destiLat, this.destiLng);
  }

  ngOnDestroy() {
    this._cd.detach();
    this.subscriptions.forEach((subscription: Subscription) => { subscription.unsubscribe(); });
    this._shrdt.setBasicBooking('');
    // this._shrdt.setBkngID('');
  }

  onClickClctnOutside(event: Object) {
    if (!this.readonlyField) {
      if (event) {
        if (event && event['value'] === true) {
          if (this.editClctnAddressFlg) {
            this.editClctnAddressFlg = false;
            this.checkforAddress();
            this.serviceInformationDetails();
          }
        } else {
          if (this.bookingType !== 'VIEW') {
            this.editClctnAddressFlg = true;
          }
        }
      } else {
        this.serviceInformationDetails();
      }
    }
  }

  onClickDelvOutside(event: Object) {
    if (!this.readonlyField) {
      if (event) {
        if (event && event['value'] === true) {
          if (this.editDelvAddressFlg) {
            this.editDelvAddressFlg = false;
            this.checkforAddress();
            this.serviceInformationDetails();
          }
        } else {
          if (this.bookingType !== 'VIEW') {
            this.editDelvAddressFlg = true;
          }
        }
      } else {
        this.serviceInformationDetails();
      }
    }
  }

  onClickPackageOutside(event: Object) {
    if (event) {
      if (event && event['value'] === true) {
        if (this.packagedatachange) {
          this.callServiceForPackage();
          this.packagedatachange = false;
        }
      }
    } else {
      this.callServiceForPackage();
    }
  }

  callServiceForPackage() {
    let pkgValidation;
    if (this._packWeigh) {
      pkgValidation = this._packWeigh.formValidationRequiredField();
    } else {
      pkgValidation = true;
    }

    if (!(!pkgValidation || isNullOrUndefined(this.packDimensionData.vol) || isNullOrUndefined(this.packDimensionData.quant) ||
      isNullOrUndefined(this.packDimensionData.wt) || (this.packDimensionData.wt === 0) ||
      isNullOrUndefined(this.packDimensionData.prType))) {
      const flag = this.bookingDetailsFetch ? true : false;
      this.serviceInformationDetails(flag);
    } else {
      if (this.bookingType !== 'VIEW') {
        this.serviceProductDetails = [];
        this.newBookingForm.get('serviceType').reset();
        this.totalPrice = null;
        this.incmpltServiceInfo = true;
        this.pickupData = [];
      }
    }
  }

  checkforAddress() {
    if (this.checkAdrNull(this.pickAdresData)) {
      if (this.bookingType !== 'VIEW') {
        this.editClctnAddressFlg = true;
      }
    }
    if (this.checkAdrNull(this.destiAdresData)) {
      if (this.bookingType !== 'VIEW') {
        this.editDelvAddressFlg = true;
      }
    }
  }

  checkforNullAddress() {
    if (this.checkAdrNull(this.pickAdresData)) {
      if (this.bookingType !== 'VIEW') {
        this.editClctnAddressFlg = true;
      }
    } else {
      this.editClctnAddressFlg = false;
    }
    if (this.checkAdrNull(this.sndrAdrData)) {
      this.newBookingForm.get('bkngSndrChck').setValue(true, { emitEvent: false });
    }
    if (this.checkAdrNull(this.destiAdresData)) {
      if (this.bookingType !== 'VIEW') {
        this.editDelvAddressFlg = true;
      }
    } else {
      this.editDelvAddressFlg = false;
    }
    if (this.checkAdrNull(this.rcvrAdrData)) {
      this.newBookingForm.get('bkngRcrAddrChck').setValue(true, { emitEvent: false });
    }
  }

  checkAdrNull(data) {
    if (data) {
      if ((isNullOrUndefined(data.cNme) || (data.cNme === '')) &&
        (isNullOrUndefined(data.cPsn) || (data.cPsn === '')) &&
        (isNullOrUndefined(data.cd) || (data.cd === '')) &&
        (isNullOrUndefined(data.cntry) || (data.cntry === '')) &&
        (isNullOrUndefined(data.cty) || (data.cty === '')) &&
        (isNullOrUndefined(data.e) || (data.e === '')) &&
        (isNullOrUndefined(data.l1) || (data.l1 === '')) &&
        (isNullOrUndefined(data.l2) || (data.l2 === '')) &&
        (isNullOrUndefined(data.pCd) || (data.pCd === '')) &&
        (isNullOrUndefined(data.pIn) || (data.pIn === '')) &&
        (isNullOrUndefined(data.tel) || (data.tel === ''))) {
        return true;
      } else {
        return false;
      }
    } else {
      return true;
    }
  }

  accountSelect() {
    this.defaultAccount = [this.newBookingForm.get('customerAcc').value];
    this.fetchTemplateList();
  }

  makeDefaultTemplate() {
    const makeDefaultBody = {
      'olDtId': this.oldDefaultTid,
      'nDtId': this.newBookingForm.get('templateType').value
    };
    this._shrdt.setLoaderSrvc(true);
    const apiName = 'makeDefaultTemplate';
    this.apiUnsubscribe(apiName);

    /**
     * this API call should not be pushed to this.subscriptions and not to be unsubscribe on destroy,
     * because it will used after this component destroyed
     */
    this.apiSubscription[apiName] =
      this._template.makeTemplateDefault(makeDefaultBody, this.custAccNo).subscribe(data => {
        this.makeDefaultSuccess = true;
        this.makeDefaultError = false;
        this._shrdt.setLoaderSrvc(false);
        this.apiCallCount[apiName] = 0;
      }, error => {
        this.makeDefaultSuccess = false;
        this.makeDefaultError = true;
        this._shrdt.setLoaderSrvc(false);
        this.retryMechanism(error, apiName, '');
      });
  }

  collectionTimeChange(data) {
    // catch the data and send to new booking api
    this.colnTimeBody = data;
  }

  setColnDtlsSts(sts) {
    this.getColnDtlsSts = sts;
  }

  showCollectionTime() {
    /**
     * show or hide collection time
     * if : confirmPickup value is present and
     * if : View booking then check for collection time initial loaded data
     */
    return this.newBookingForm.get('confirmPickup').value && this.newBookingForm.get('serviceType').value &&
      (this.bookingType === 'VIEW' ? !this._shrdFnctns.checkObjectProprtsForNull(this.colnTimeBodyInit) : true);
  }

  getNoOfDaysForExpr(date, timezoneDate) {
    const currDate = !timezoneDate ? new Date() : timezoneDate;
    const diffTime = new Date(date).getTime() - new Date(this._shrdFnctns.getOnlyDate(currDate)).getTime();
    const diffDays = Math.floor(diffTime / (ConstantsVAR.MINUTES_60 * ConstantsVAR.HOUR_PER_DAY));
    return diffDays;
  }

  setExprDays(timezoneDate) {

    let expVal = 0;

    switch (this.bookingType) {
      case 'EDIT':
        if (this.bookingDetailsFetch && this.editTemplateDetailsFetch) {
          expVal = this.getNoOfDaysForExpr(this.bookingDetailsFetch.expDt, timezoneDate);
          expVal = expVal > 0 ? expVal : this.editTemplateDetailsFetch.expVal;
        }
        break;
      case 'VIEW':
        if (this.bookingDetailsFetch) {
          expVal = this.getNoOfDaysForExpr(this.bookingDetailsFetch.expDt, timezoneDate);
        }
        break;
      default:
        if (this.templateDetailsFetch) {
          expVal = this.templateDetailsFetch.expVal;
        }
        break;
    }
    return expVal;
  }

  hideBkngExpr() {
    return this.showCnfrmDtPckp ||
      (['EDIT', 'VIEW'].includes(this.bookingType) ? !this.bookingDetailsFetch.expDt : !this.templateDetailsFetch.expVal);
  }

  disableSaveChangesBtn() {
    return !this.totalPrice || !this.newBookingForm.get('serviceType').value
      || (!this.newBookingForm.get('confirmPickup').value && this.showCnfrmDtPckp)
  }

  disableCompleteBtn() {
    return (!(this.duePickUpDate.wDys && this.duePickUpDate.dDt) && this.showCnfrmDtPckp)
      || !this.totalPrice || !this.newBookingForm.get('serviceType').value
      || this.isServicePopulating === 'SRVC-S' || this.noDefaultService
      || (!this.newBookingForm.get('confirmPickup').value && this.showCnfrmDtPckp);
  }

  focusCompleteBtn() {
    return !((!(this.duePickUpDate.wDys && this.duePickUpDate.dDt) && this.showCnfrmDtPckp)
      || !this.totalPrice || !this.newBookingForm.get('serviceType').value
      || (!this.newBookingForm.get('confirmPickup').value && this.showCnfrmDtPckp))
  }

  templateSelect() {
    const tempdata = this.newBookingForm.get('templateType').value;
    this.newBookingForm.reset();

    this.subscriptions.forEach((subscription: Subscription) => { subscription.unsubscribe(); });
    Object.keys(this.apiSubscription).forEach(apiName => { this.apiUnsubscribe(apiName); });

    this.saveBtnClicked = null;
    this.showCnfrmDtPckp = null;
    this.pickupData = [];
    this.serviceProductDetails = [];
    this.totalPrice = null;
    this.duePickUpDate = ConstantsJson.duePickUpDate_INIT;
    this.colnTimeFrmApiInit = { cutOffTm: '', dptOpenTm: '', dptCloseTm: '' };
    this.colnTimeBody = { pfClEnTm: '', pfClStTm: '', alClEnTm: '', alClStTm: '' };

    this.sndrAddrssFrmVldtn = null;
    this.dstntnAddrssFrmVldtn = null;
    this.gnrlInfoFrmVldtn = null;
    this.insrInvcFrmVldtn = null;
    this.packWeighFrmVldtn = null;
    this.pckpAddrssFrmVldtn = null;
    this.rcvrAddrssFrmVldtn = null;
    this.colnTimeFrmVldtn = false;

    this.templateDetailsFetch = null;
    this.editTemplateDetailsFetch = null;
    this.readonlyField = null;
    this.pickAdresData = null;
    this.editFlag = false;
    this.sndrAdrData = [];
    this.destiAdresData = [];
    this.rcvrAdrData = [];
    this.setPackagesList = null;
    this.insuranceData = null;
    this.fileDetailsData = null;
    this.bookingDetailsFetch = null;

    this.uniqueCustRefDataErrorflag = 'false';
    this.uniqueBookRefDataErrorflag = 'false';
    this.bookingType = 'NEW';
    this.viewDisplayCount = 0;
    this.disableCstmrRef = null;
    this.confirmPickUpStatus = '';
    this.incmpltPickupInfo = null;
    this.serviceInfoErrorFlag = null;
    this.incmpltServiceInfo = null;
    this.apiErrorServiceInfo = null;
    this.editFlag = null;
    this.countPakgCall = 0;
    this.pckAddrDimensionData = null;
    this.destiAddrdimensionData = null;
    this.packagedatachange = false;
    this.newBookingForm.reset();
    this.pickAdresDataOld = null;
    this.destiAdresDataOld = null;
    this.previousDueDate = null;
    this.previousExpecDt = null;
    this.previousServiceInfo = null;
    this.serviceInfoProducts = null;
    this.tId = null;
    this.postalAware = JSON.parse(JSON.stringify(ConstantsJson.postalAware));
    this.addressFlagData = JSON.parse(JSON.stringify(ConstantsJson.addressFlagData));
    this.packDimensionData = null;
    this._sndrAddrss.resetAllData();
    this._pckpAddrss.resetAllData();
    this._rcvrAddrss.resetAllData();
    this._dstntnAddrss.resetAllData();
    this._insrInvc.resetUploadCmpnt();
    this.fetchTemplateDetails(tempdata);
  }

  apiUnsubscribe(apiName) {
    if (this.apiSubscription[apiName]) { this.apiSubscription[apiName].unsubscribe(); }
  }

  retryMechanism(error, apiName, params, noBaseAPI?) {
    this.apiCallCount[apiName] = this.apiCallCount[apiName] || 1;
    this.apiCallCount[apiName]++;
    if (this._calltoken) {
      if (!noBaseAPI) { this._calltoken.callBaseService(error); }
      if (this.apiCallCount[apiName] <= ConstantsVAR.API_MAX_TRY) {
        this._calltoken.retryServiceCall(error, apiName, params);
      } else {
        this.apiCallCount[apiName] = 0;
      }
    }
  }

  retryCall(data) {
    if (data.apiName === 'fetchBookingEdit') {
      this.fetchBookingEdit(data.data);
    }
    if (data.apiName === 'getTemplateDetails') {
      this.getTemplateDetails(data.data);
    }
    if (data.apiName === 'generateBookingRef') {
      this.generateBookingRef();
    }
    if (data.apiName === 'onBlurMethod') {
      this.onBlurMethod(data.data.event, data.data.flag);
    }
    if (data.apiName === 'checkCustomer') {
      this.checkCustomer(data.data);
    }
    if (data.apiName === 'OnContetnRef') {
      this.OnContetnRef(data.data);
    }
    if (data.apiName === 'getSaveService') {
      this.getSaveService(data.data.bookingBody, data.data.file);
    }
    if (data.apiName === 'updateService') {
      this.updateService(data.data.bookingBody, data.data.file);
    }
    if (data.apiName === 'getSaveAsDraftService') {
      this.getSaveAsDraftService(data.data.bookingBody, data.data.file);
    }
    if (data.apiName === 'fetchTemplateList') {
      this.fetchTemplateList();
    }
    if (data.apiName === 'fetchTemplateDetails') {
      this.fetchTemplateDetails(data.data);
    }
    if (data.apiName === 'callServiceInfoService') {
      this.callServiceInfoService(data.data);
    }
    if (data.apiName === 'callExpectedDt') {
      this.callExpectedDt(data.data);
    }
    if (data.apiName === 'callDueDate') {
      this.callDueDate(data.data);
    }
    if (data.apiName === 'makeDefaultTemplate') {
      this.makeDefaultTemplate();
    }
    if (data.apiName === 'getCnfrmpickup') {
      this.getCnfrmpickup(data.data.clctnAdr, data.data.destiAdr, data.data.lat, data.data.lng);
    }
    if (data.apiName === 'getExpectedDt') {
      this.getExpectedDt(data.data.clctnAdr, data.data.destiAdr, data.data.lat, data.data.lng);
    }
  }
}
