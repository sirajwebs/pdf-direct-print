/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved *copyright* FedEx 2018
 *
 * Typescript code in this page
 */

import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CollectionTimeComponent } from './collection-time.component';
import { ColnTimeConstants, ConstantsVAR } from './../../../../shared/constants/constants-var';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Component, OnInit, Output, EventEmitter, OnDestroy, Input, OnChanges, SimpleChanges } from '@angular/core';
import { ColnTimeInitDTO, BookingPreferenceDTO, DateTime, ColnTime, ColnTimeInputsDTO } from 'app/shared/models/bookings.models';
import { Subscription } from 'rxjs/Subscription';
import { SharedFunctionsService } from './../../../../services/shared-functions.service';
import { DebugElement } from '@angular/core';

describe('CollectionTimeComponent', () => {
  let component: CollectionTimeComponent;
  let fixture: ComponentFixture<CollectionTimeComponent>;
  let debugElement: DebugElement;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [CollectionTimeComponent],
      imports: [FormsModule, ReactiveFormsModule],
      providers: [SharedFunctionsService]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CollectionTimeComponent);
    component = fixture.componentInstance;
    debugElement = fixture.debugElement;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should set view booking details', () => {
    component.colnTimeBodyInit = {
      pfClStTm: '09:00',
      pfClEnTm: '12:00',
      alClStTm: '13:00',
      alClEnTm: '19:00'
    }
    component.colnTimeFrmApiInit = {
      cutOffTm: '19:00',
      dptOpenTm: '09:00',
      dptCloseTm: '19:00'
    }
    component.colnTimeInputs_Copy = {
      MRNG: {
        FROM: [component.colnTimeBodyInit['pfClStTm']],
        TO: [component.colnTimeBodyInit['pfClEnTm']],
      },
      AFTRN: {
        FROM: [component.colnTimeBodyInit['alClStTm']],
        TO: [component.colnTimeBodyInit['alClEnTm']],
      }
    }
    component.setStaticBookingDetails(component.colnTimeBodyInit);
    fixture.detectChanges();
    expect(component.colnTimeInputs_Copy).not.toBeFalsy();
  });

  it('should initiate collection details updates', () => {
    const changes = {
      confirmPickupDate: {
        currentValue: '2019-09-27'
      }
    };
    component.colnTimeFrmApiInit = {
      cutOffTm: '19:00',
      dptOpenTm: '09:00',
      dptCloseTm: '19:00'
    }
    component.updateCollnValues(changes);
    fixture.detectChanges();
    expect(component.savedColnTimesUp.MRNG_OR_AFTRN).toBeFalsy();
    expect(component.savedColnTimesUp.WHOLE_DAY).toBeFalsy();
  });

  it('should do nothing if no changes happened', () => {
    const changes = {
      confirmPickupDate: ''
    };
    component.colnTimeFrmApiInit = {
      cutOffTm: '19:00',
      dptOpenTm: '09:00',
      dptCloseTm: '19:00'
    }
    component.updateCollnValues(changes);
    fixture.detectChanges();
  });

  it('should call setViewBookingDetails if type: VIEW', () => {
    spyOn(component, 'setStaticBookingDetails');
    component.colnTimeBodyInit = {
      pfClStTm: '09:00',
      pfClEnTm: '12:00',
      alClStTm: '13:00',
      alClEnTm: '19:00'
    };
    component.colnTimeFrmApiInit = {
      cutOffTm: '19:00',
      dptOpenTm: '09:00',
      dptCloseTm: '19:00'
    };
    component.bookingType = 'VIEW';
    component.ngOnInit();
    fixture.detectChanges();
    expect(component.setStaticBookingDetails).toHaveBeenCalled();
  });

  it('should call setEditBookingDetails if type: EDIT', () => {
    spyOn(component, 'setEditBookingDetails');
    component.colnTimeBodyInit = {
      pfClStTm: '09:00',
      pfClEnTm: '12:00',
      alClStTm: '13:00',
      alClEnTm: '19:00'
    }
    component.colnTimeFrmApiInit = {
      cutOffTm: '19:00',
      dptOpenTm: '09:00',
      dptCloseTm: '19:00'
    }
    component.bookingType = 'EDIT';
    component.ngOnInit();
    fixture.detectChanges();
    expect(component.setEditBookingDetails).toHaveBeenCalled();
  });

  it('should call updateCollnValues if type other than "VIEW"', () => {
    spyOn(component, 'updateCollnValues');
    component.colnTimeBodyInit = {
      pfClStTm: '09:00',
      pfClEnTm: '12:00',
      alClStTm: '13:00',
      alClEnTm: '19:00'
    }
    component.colnTimeFrmApiInit = {
      cutOffTm: '19:00',
      dptOpenTm: '09:00',
      dptCloseTm: '19:00'
    }
    const changes: SimpleChanges = {};
    component.bookingType = '';
    component.ngOnChanges(changes);
    fixture.detectChanges();
    expect(component.updateCollnValues).toHaveBeenCalled();
  });

  it('should not call updateCollnValues if type = "VIEW"', () => {
    spyOn(component, 'updateCollnValues');
    const changes: SimpleChanges = {};
    component.bookingType = 'VIEW';
    component.ngOnChanges(changes);
    fixture.detectChanges();
    expect(component.updateCollnValues).not.toHaveBeenCalled();
  });

  it('should patch for edit booking with saved data when collection date is same', () => {
    spyOn(component, 'patchInitialValue');
    component.getColnDtlsSts = false;
    component.savedPickupDate = '2019-10-22';
    component.confirmPickupDate = '2019-10-22';
    component.colnTimeBodyInit = {
      pfClStTm: '09:00',
      pfClEnTm: '12:00',
      alClStTm: '13:00',
      alClEnTm: '19:00'
    }
    component.actualCollectionDateTime = {
      DATE: '2019-10-22',
      TIME: '08:00'
    }
    component.setEditBookingDetails();
    fixture.detectChanges();
    expect(component.patchInitialValue).toHaveBeenCalled();
  });

  it('should NOT patch edit booking data when already saved details is already patched', () => {
    component.getColnDtlsSts = true;
    component.setEditBookingDetails();
    fixture.detectChanges();
  });

  it('should patch for edit booking with refreshed data when both morning and afternoon are not available', () => {
    spyOn(component, 'refreshColnTime');
    component.getColnDtlsSts = false;
    component.savedPickupDate = '2019-10-22';
    component.confirmPickupDate = '2019-10-22';
    component.colnTimeBodyInit = {
      pfClStTm: '',
      pfClEnTm: '',
      alClStTm: '',
      alClEnTm: ''
    }
    component.colnTimeFrmApiInit = {
      cutOffTm: '19:00',
      dptOpenTm: '09:00',
      dptCloseTm: '19:00'
    }
    component.actualCollectionDateTime = {
      DATE: '2019-10-22',
      TIME: '08:00'
    }
    component.setEditBookingDetails();
    fixture.detectChanges();
    expect(component.refreshColnTime).toHaveBeenCalled();
    expect(component.savedColnTimesUp.MRNG_OR_AFTRN).toBeTruthy();
  });

  it('should patch for edit booking with refreshed data when only morning are not available', () => {
    spyOn(component, 'isSavedColnTimesUp');
    component.getColnDtlsSts = false;
    component.savedPickupDate = '2019-10-22';
    component.confirmPickupDate = '2019-10-22';
    component.colnTimeBodyInit = {
      pfClStTm: '',
      pfClEnTm: '',
      alClStTm: '13:00',
      alClEnTm: '19:00'
    }
    component.colnTimeFrmApiInit = {
      cutOffTm: '19:00',
      dptOpenTm: '09:00',
      dptCloseTm: '19:00'
    }
    component.actualCollectionDateTime = {
      DATE: '2019-10-22',
      TIME: '08:00'
    }
    component.setEditBookingDetails();
    fixture.detectChanges();
    expect(component.isSavedColnTimesUp).toHaveBeenCalled();
  });

  it('should patch for edit booking with new data when collection date is not same', () => {
    spyOn(component, 'refreshColnTime');
    component.getColnDtlsSts = false;
    component.savedPickupDate = '2019-10-15';
    component.confirmPickupDate = '2019-10-22';
    component.setEditBookingDetails();
    fixture.detectChanges();
    expect(component.refreshColnTime).toHaveBeenCalled();
    expect(component.savedColnTimesUp.WHOLE_DAY).toBeTruthy();
  });

  it('should patch for edit booking with saved data when saved date it not today', () => {
    spyOn(component, 'setSavedColnTimeData');
    component.getColnDtlsSts = false;
    component.savedPickupDate = '2019-10-20';
    component.confirmPickupDate = '2019-10-20';
    component.actualCollectionDateTime = {
      DATE: '2019-10-22',
      TIME: '08:00'
    }
    component.colnTimeFrmApiInit = {
      cutOffTm: '19:00',
      dptOpenTm: '09:00',
      dptCloseTm: '19:00'
    }
    component.setEditBookingDetails();
    fixture.detectChanges();
    expect(component.setSavedColnTimeData).toHaveBeenCalled();
  });

  it('should disable all field and set default value if no data retrieve from draft booking', () => {
    spyOn(component, 'patchMorningValueToDefault');
    spyOn(component, 'patchAfternoonValueToDefault');
    spyOn(component, 'enableOrDisableTimeSelction');
    component.getColnDtlsSts = false;
    component.savedPickupDate = '2019-10-20';
    component.confirmPickupDate = '2019-10-20';
    component.actualCollectionDateTime = {
      DATE: '2019-10-22',
      TIME: '08:00'
    }
    component.colnTimeFrmApiInit = {
      cutOffTm: '19:00',
      dptOpenTm: '09:00',
      dptCloseTm: '19:00'
    }
    component.colnTimeBodyInit = {
      pfClStTm: '',
      pfClEnTm: '',
      alClStTm: '',
      alClEnTm: ''
    }
    component.setSavedColnTimeData();
    fixture.detectChanges();

    expect(component.patchMorningValueToDefault).toHaveBeenCalled();
    expect(component.collectionTimeForm.get('morningDontCollect')).toBeTruthy();

    expect(component.patchAfternoonValueToDefault).toHaveBeenCalled();
    expect(component.collectionTimeForm.get('afternoonDontCollect')).toBeTruthy();

    expect(component.enableOrDisableTimeSelction).toHaveBeenCalled();
  });

  it('should patch Morning Value To Default', () => {
    component.colnTimeFrmApiInit = {
      cutOffTm: '19:00',
      dptOpenTm: '09:00',
      dptCloseTm: '20:00'
    }
    component.colnTimeInputs_Copy = {
      MRNG: {
        FROM: ['09:00', '10:00'],
        TO: ['11:00', '12:00']
      },
      AFTRN: {
        FROM: ['12:00', '13:00'],
        TO: ['19:00', '20:00']
      }
    }
    const from = component.colnTimeInputs_Copy['MRNG']['FROM'],
      to = component.colnTimeInputs_Copy['MRNG']['TO'];
    component.patchMorningValueToDefault();
    fixture.detectChanges();
    expect(component.collectionTimeForm.get('morningFrom').value).toEqual(from[0]);
    expect(component.collectionTimeForm.get('morningTo').value).toEqual(to[to.length - 1]);
  });

  it('should patch Afternoon Value To Default', () => {
    component.colnTimeFrmApiInit = {
      cutOffTm: '19:00',
      dptOpenTm: '09:00',
      dptCloseTm: '19:00'
    }
    component.colnTimeInputs_Copy = {
      MRNG: {
        FROM: ['09:00', '10:00'],
        TO: ['11:00', '12:00']
      },
      AFTRN: {
        FROM: ['12:00', '13:00'],
        TO: ['19:00', '20:00']
      }
    }
    const from = component.colnTimeInputs_Copy['AFTRN']['FROM'],
      to = component.colnTimeInputs_Copy['AFTRN']['TO'];
    component.patchAfternoonValueToDefault();
    fixture.detectChanges();
    expect(component.collectionTimeForm.get('afternoonFrom').value).toEqual(from[0]);
    expect(component.collectionTimeForm.get('afternoonTo').value).toEqual(to[to.length - 1]);
  });

  it('should NOT update Collection Time Dropdown Options', () => {
    component.bookingType = 'VIEW';
    component.updateColnTimeDrpdwnOptns('afternoonTo', component.LocalConstantsVAR.AFTRN, component.LocalConstantsVAR.FROM);
    fixture.detectChanges();
  });

  it('should update Collection Time if morning/afternoon time is already lapse', () => {
    spyOn(component, 'refreshColnTime');
    component.colnTimeBodyInit = {
      pfClStTm: '09:00',
      pfClEnTm: '12:00',
      alClStTm: '13:00',
      alClEnTm: '19:00'
    }
    component.colnTimeFrmApiInit = {
      cutOffTm: '19:00',
      dptOpenTm: '09:00',
      dptCloseTm: '19:00'
    }
    component.actualCollectionDateTimeModified['TIME'] = '12:00';
    component.collectionTimeForm.get('morningFrom').setValue('10:00');
    component.isSavedColnTimesUp('morningFrom');
    fixture.detectChanges();
    expect(component.refreshColnTime).toHaveBeenCalled();
  });

  it('should return default FALSE for isColnTimeValidFor function', () => {
    component.isColnTimeValidFor('');
    fixture.detectChanges();
  });

  it('should append 0 if not in format of "09:00" for hour less than 10', () => {
    component.convertToTimeFormat('9:00');
    fixture.detectChanges();
  });

  it('should NOT convert time format if value is null', () => {
    component.getHoursOrMinutes('', 'hh');
    fixture.detectChanges();
  });

  it('should return minutes in digits', () => {
    component.getMinutesInDigit('34');
    fixture.detectChanges();
  });

  it('should do nothiing when no data passed in getMinutesInDigit functions', () => {
    component.getMinutesInDigit('');
    fixture.detectChanges();
  });

  it('should Disable Time Selction for morning and make active for afternoon', () => {
    spyOn(component, 'enableMorningTime');
    spyOn(component, 'enableAfternoonTime');
    component.collectionTimeForm.get('morningDontCollect').setValue(true);
    component.enableOrDisableTimeSelction(component.LocalConstantsVAR.MRNG, true);
    fixture.detectChanges();
    expect(component.enableMorningTime).toHaveBeenCalled();
    expect(component.collectionTimeForm.get('afternoonDontCollect').value).toBeFalsy();
    expect(component.enableAfternoonTime).toHaveBeenCalled();
  });

  it('should Disable Time Selction for afternoon and make active for morning', () => {
    spyOn(component, 'enableMorningTime');
    spyOn(component, 'enableAfternoonTime');
    component.collectionTimeForm.get('afternoonDontCollect').setValue(true);
    component.enableOrDisableTimeSelction(component.LocalConstantsVAR.AFTRN, true);
    fixture.detectChanges();
    expect(component.enableAfternoonTime).toHaveBeenCalled();
    expect(component.collectionTimeForm.get('morningDontCollect').value).toBeFalsy();
    expect(component.enableMorningTime).toHaveBeenCalled();
  });

  it('should Disable Time Selction for morning only', () => {
    spyOn(component, 'enableMorningTime');
    component.collectionTimeForm.get('morningDontCollect').setValue(true);
    component.enableOrDisableTimeSelction(component.LocalConstantsVAR.MRNG, false);
    fixture.detectChanges();
    expect(component.enableMorningTime).toHaveBeenCalled();
  });

  it('should Disable Time Selction for afternoon only', () => {
    spyOn(component, 'enableAfternoonTime');
    component.collectionTimeForm.get('afternoonDontCollect').setValue(true);
    component.enableOrDisableTimeSelction(component.LocalConstantsVAR.AFTRN, false);
    fixture.detectChanges();
    expect(component.enableAfternoonTime).toHaveBeenCalled();
  });

  it('should add the minimum time to collect with existing data and get the new time (add extra hour if needed)', () => {
    component.sameDayInitialTmCalculation('10:00', 90);
    fixture.detectChanges();
  });

  it('should add the minimum time to collect with existing data and get the new time (dont add extra hour if not needed)', () => {
    component.sameDayInitialTmCalculation('10:00', 30);
    fixture.detectChanges();
  });

});
