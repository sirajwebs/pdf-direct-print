import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BookingOptionsComponent } from './booking-options.component';
import { Component, OnInit, OnDestroy, ViewChild, ChangeDetectorRef, HostListener, OnChanges, SimpleChanges,
  Input, Output, EventEmitter } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TemplateService } from 'app/services/template.service';
import { HttpModule } from '@angular/http';
import { ConstantsJson, ConstantsVAR, KeyboardKey, bookingOptions } from '../../../shared/constants/constants-var';
import { JsEncoderService } from './../../../services/js-encoder.service';
import { BookingOptionDTO } from './../../../shared/models/template.models';

describe('BookingOptionsComponent', () => {
  let component: BookingOptionsComponent;
  let fixture: ComponentFixture<BookingOptionsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BookingOptionsComponent ],
      imports: [FormsModule, ReactiveFormsModule, HttpModule],
      providers: [TemplateService]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BookingOptionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should reset when sender option is changed', () => {
    component.showSender = true;
    component.setDefaultBookingOptions();
    fixture.detectChanges();
    expect(component.bookingOptionForm.get('bookingOptions').value).toBe(false);
  })
});
