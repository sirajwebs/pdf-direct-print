/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved *copyright* Fedex 2018
 *
 * Typescript code in this page
 */
import { ConstantsURL, ConstantsURL_Others } from './shared/constants/constants-urls';
import { CalltokenComponent } from './shared/calltoken/calltoken.component';
import { SharedataService } from './services/sharedata.service';
import { Router } from '@angular/router';
import { LoginService } from './services/login.service';
import { TokenService } from './services/token.service';
import { Component, OnInit, ViewChild, OnChanges, ChangeDetectorRef, OnDestroy } from '@angular/core';
import { Location } from '@angular/common';
import { ConstantsVAR } from './shared/constants/constants-var';
import { Subscription } from 'rxjs/Subscription';
import { FedexLogonService } from './services/fedex-logon.service';
import { SharedFunctionsService } from './services/shared-functions.service';
import { JsEncoderService } from './services/js-encoder.service';
// import { LoginComponent } from './components/login/login.component';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  providers: [FedexLogonService, SharedFunctionsService]
})
export class AppComponent implements OnInit, OnChanges, OnDestroy {
  @ViewChild(CalltokenComponent) public _calltoken: CalltokenComponent;
 // @ViewChild(LoginComponent) public _login: LoginComponent;

  isBrowserNonSupport = false;
  defaultAcc = '';
  previousUrl = '';
  count = 1;
  loginsuccess = false;
  noAccount = false;
  apiCallCount = [];
  apiSubscription = [];
  idleTimeoutLimit = 30;    // timeout limit (in minutes)
  hideHeaderFooter = false;
  CloseEdiDwnld = ConstantsVAR.CLOSE_EDI_DWNLD;
  subscriptions: Array<Subscription> = [];
  currYear = new Date().getFullYear();

  constructor(private _router: Router,
    private _cd: ChangeDetectorRef,
    private _shrdFnctns: SharedFunctionsService,
    private _fdxLogin: FedexLogonService,
    private _jsEcd: JsEncoderService,
    private _tokenSrvce: TokenService,
    private _loginService: LoginService,
    private _sharedDataService: SharedataService,
    _location: Location) {
    this.subscriptions.push(_router.events.subscribe((val) => {
      const url = _location.path();
      if (this.previousUrl) {
        if ((this.previousUrl.indexOf('/complete-booking') > -1) && (url.indexOf('/dashboard') > -1)) {
          this._sharedDataService.setBkngURL(true);
        } else if ((this.previousUrl.indexOf('/complete-booking') === -1) && (url.indexOf('/dashboard') === -1)) {
          this._sharedDataService.setBkngURL(false);
        }
      }
      this.previousUrl = url;
    }));

  }

  ngOnInit() {
    this.setGoogleMapsScriptTag();
    window.scrollTo(0, 0);
    this.isBrowserNonSupport = (navigator.appName === 'Microsoft Internet Explorer' || !!(navigator.userAgent.match(/Trident/)
      || navigator.userAgent.match(/rv:11/)));
    if (!this.isBrowserNonSupport) {
      this._tokenSrvce.callToken();
      if (!this.loginsuccess && localStorage.getItem('isLoggedIn') === 'true') {
        if (!this.getURL().includes(ConstantsURL.CONST_PRINT_URL)) {
          this.checkIfLoginSessionActive(); // REQUIRED *** COMMENT THIS LINE TO BYPASS LOGIN ***
        }
      }
      this.sessionTimeout();
    } else {
      localStorage.clear();
      sessionStorage.clear();
    }
    this.checkPrintUrl();
    // this.loginBypass();   // DELETE *** UNCOMMENT THIS LINE TO BYPASS LOGIN ***
  }

  ngOnDestroy() {
    this._cd.detach();
    this.subscriptions.forEach((subscription: Subscription) => { subscription.unsubscribe(); });
    Object.keys(this.apiSubscription).forEach(apiName => { this.apiUnsubscribe(apiName); });
  }

  setGoogleMapsScriptTag() {
    const scriptElement = document.createElement('script');
    scriptElement.id = ConstantsURL_Others.GOOGLE_SCRIPT_TAG;
    scriptElement.src = ConstantsURL_Others.GOOGLE_MAP_SCRIPT;
    document.getElementsByTagName('head')[0].appendChild(scriptElement);
  }

  getURL() {
    let url = window.location.href;
    try {
      url = url.slice(url.indexOf('#') + 1, url.length);
    } catch (error) { }
    return url;
    // return this._router.url; // not working
  }

  loginBypass() {
    // THIS METHOD **** To Bypass Login ***
    this.loginsuccess = true;
    const data = {
      'transactionId': '49a518cb-0e5c-41a3-a98e-bfd6c5d41716',
      'output': {
        'userProfile': {
          'registeredContactAndAddress': {
            'contact': {
              'personName': { 'firstName': 'Samyukta', 'middleName': '', 'lastName': 'Khuba' },
              'companyName': '', 'phoneNumber': '123456789', 'emailAddress': 'samyukta.khuba.osv@fedex.com'
            },
            'address': {
              'streetLines': ['51 Bellsingel', ''], 'city': 'SCHIPHOL RIJK', 'stateOrProvinceCode': '',
              'postalCode': '1119NT', 'countryCode': 'NL', 'residential': false
            }
          }, 'isManaged': true,
          'defaultAccount': { 'value': '', 'key': '9c679eede608466c2eedd0e5dc8a785c' },
          'customer': { 'cashOnly': false, 'creditCardUpdateBlocked': false, 'ukdomesticAllowed': false },
          'expandedAccounts': [{
              'account': {
              'accountNumber': { 'value': '', 'key': '9c679eede608466c2eedd0e5dc8a785c' },
              'accountNickname': 'Test Account', 'accountDisplayName': 'Test Account-527'
          }
          }],
          'siteWideProfile': { 'companyAdmin': false, 'departmentAdmin': false }
        },
        'loginCookieOutputVO': {
          'fclCookie': 'ssotest-cos1.b485.4169b6eb',
          'nameCookie': 'Samyukta', 'contactNameCookie': 'Samyukta Khuba',
          'uuidCookie': 'D2eoIN8lbp'
        }
      }
    };
    this._sharedDataService.setUserDetails(data.output);
    this._fdxLogin.getFedexUserDetails();
    localStorage.setItem('isLoggedIn', 'true');
    sessionStorage.removeItem('logoutFlag');
    this.noAccount = false;
    this._sharedDataService.setNoAccount(false);
    localStorage.setItem('noAccount', '');
    const accountList = ['070071313', '2010002525', '799940425'];
    localStorage.setItem(ConstantsVAR.DEF_ACC_KEY, this._jsEcd.encode('070071313'));
    // this._sharedDataService.setDefAccount(2010002525);
    // US account -> ['799940425'], country code -> US lastname -> SodhiProxy;
    // german domestic ['070071313'] - test only for domestic germany
    // german ['799940425'] - set to default
    // UK account 2010002525
    // UK account 0510508383
    const customerAccounts = {
      cAccNoLi: accountList
    };
    localStorage.setItem(ConstantsVAR.ACC_KEY, this._jsEcd.encode(JSON.stringify(customerAccounts)));
    const userAccountObject = [
      { 'ctryCd': 'NL', 'accTyp': 'F', 'cusAccNm': 'Test Account-527', 'cusAccId': '9c679eede608466c2eedd0e5dc8a785c', 'defAcc': false },
      { 'ctryCd': 'NL', 'accTyp': 'T', 'cusAccNm': 'TNT - TNT', 'cusAccId': '000009845', 'defAcc': true }];
    this._sharedDataService.setAccDetails(userAccountObject);
    }

  ngOnChanges() {
    this.checkPrintUrl();
  }

  checkPrintUrl() {
    const checkUrl = this.getURL().includes(ConstantsURL.CONST_PRINT_URL);
    if (checkUrl) {
      this.hideHeaderFooter = true;
      this._cd.detectChanges();
    }
    return checkUrl;
  }

  sessionTimeout() {
    /**
     * to check the session timeout every minutes if there is no user event like
     * mouse move, key press , then timeout after 30 minutes
     */
    const IDLE_TIMEOUT = this.idleTimeoutLimit;
    let _idleSecondsCounter = 0;
    const self = this;

    document.onclick = function () { _idleSecondsCounter = 0; };
    document.onmousemove = function () { _idleSecondsCounter = 0; };
    document.onkeypress = function () { _idleSecondsCounter = 0; };
    window.setInterval(CheckIdleTime, 1 * ConstantsVAR.MINUTES_1);    // min * sec * milisec = minutes

    function CheckIdleTime() {
      _idleSecondsCounter++;
      if (_idleSecondsCounter >= IDLE_TIMEOUT) {
        try {
          sessionStorage.removeItem('returnEdiURL');
        } catch (err) { }
        if (localStorage.getItem('isLoggedIn') ? localStorage.getItem('isLoggedIn') === 'true' : false) {
            self.logout('TIMEOUT');
        }
      }
    }
  }

  loginFailure() {
    /**
     * if the login/actc api is failed, then this section handle failure messages
     */
    localStorage.setItem('isLoggedIn', '');
    sessionStorage.setItem('logoutFlag', 'FCL');
    const ediPopup = <HTMLElement>document.getElementById(this.CloseEdiDwnld);
    try {
      document.getElementById('REMOVE_MODAL_BACKDROP').click();
      ediPopup.click();
    } catch (err) { }
    let waitTime = 0;
    if (ediPopup) {
      waitTime = ConstantsVAR.MILISEC_200;
    }
    setTimeout(() => {
      this._router.navigate(['/login']);
      this._sharedDataService.setUserDetails(null);
    }, waitTime);
  }

  windowReload() {
    /**
     * Navigate to login component and change window reference url to login
     * and reload the window
     */
    const ediPopup = <HTMLElement>document.getElementById(this.CloseEdiDwnld);
    try {
      document.getElementById('REMOVE_MODAL_BACKDROP').click();
      ediPopup.click();
    } catch (err) { }
    let waitTime = 0;
    if (ediPopup) {
      waitTime = ConstantsVAR.MILISEC_200;
    }
    setTimeout(() => {
      this._shrdFnctns.windowReload();
    }, waitTime);
  }

  logout(flag) {
    /**
    * logout and delete localstorage and cookies
    */
    const apiName = 'logout';
    this.apiUnsubscribe(apiName);

    this.subscriptions.push(this.apiSubscription[apiName] = this._loginService.logout().subscribe((data) => {
      this.logoutHandling(flag);
    }, error => {
      this.logoutHandling(flag);
    }));
  }

  logoutHandling(flag) {
    const rUrl = sessionStorage.getItem('returnEdiURL');
    this._loginService.deleteAllCookies();
    localStorage.clear();
    sessionStorage.clear();
    if (rUrl) { sessionStorage.setItem('returnEdiURL', rUrl); }
    sessionStorage.setItem('logoutFlag', flag);
    this.windowReload();
  }

  apiUnsubscribe(apiName) {
    if (this.apiSubscription[apiName]) { this.apiSubscription[apiName].unsubscribe(); }
  }

  checkIfLoginSessionActive() {
    this.loginsuccess = true;
    const usr = this._sharedDataService.getUserDetails(),
      acc = this._sharedDataService.getAccDetails();

    if ((usr && acc) ? usr['userProfile'] : false) {
      this._sharedDataService.setUserDetails(usr);
      this._fdxLogin.getFedexUserDetails();
      sessionStorage.removeItem('logoutFlag');
    } else {
      this.loginFailure();
    }
  }

  // hideLoginComponent() {
  //   return this._router.url !== '/login';
  // }
}
