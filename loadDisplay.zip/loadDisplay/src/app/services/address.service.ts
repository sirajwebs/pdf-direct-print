/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved (c) Fedex 2018
 *
 * Typescript code in this page
 */
import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/of';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
import 'rxjs/add/observable/throw';
import { ConstantsURL as Constants } from '../shared/constants/constants-urls';
import { BaseService } from './base.service';
import { ConstantsVAR } from '../shared/constants/constants-var';
import { PostalParams } from 'app/shared/models/global.models';
import { SharedataService } from './sharedata.service';

@Injectable()
export class AddressService extends BaseService {
    readonly apiMethod = {
        POST: 'POST',
        GET: 'GET'
    };
    readonly callType = {
        POSTAL: 'POSTAL',
        CITY: 'CITY'
    };

    constructor(private _http: Http, private _shrd: SharedataService) {
        super();
    }

    validatePostalApi(countryCode: string, postCode): Observable<any> {

        let api;
        const params: PostalParams = {
            URL: '',
            REQ: postCode,
            TYPE: this.callType.POSTAL,
            CD: countryCode,
        };
        if (this._shrd.isFedexAccount()) {
            params.URL = Constants.FEDEX_POSTAL_AND_CITY;
            api = this.apiCall(this.apiMethod.POST, params);
        } else {
            params.URL = Constants.CONST_VALIDATE_CITY + countryCode + Constants.CONST_VALIDATE_CITY_CHILD_URL + postCode;
            api = this.apiCall(this.apiMethod.GET, params);
        }

        return api.retryWhen(this.handleRetry)
            .map((res) => {
                return this.extractData(res);
            }).catch(this.handleError);
    }

    postalAware(countryCode: string): Observable<any> {

        let URL: string;
        if (this._shrd.isFedexAccount()) {
            URL = Constants.FEDEX_COUNTRY_DETAILS + countryCode + '/';
        } else {
            URL = Constants.CONST_COUNTRY_POSTAL_CHECK + countryCode;
        }

        return this._http
            .get(URL, this.setRequestOptions(this.token()))
            .retryWhen(this.handleRetry)
            .map((res) => {
                return this.extractData(res);
            }).catch(this.handleError);
    }

    postalNonAwareCity(countryCode: string, city): Observable<any> {

        let api;
        const params: PostalParams = {
            URL: '',
            REQ: city,
            TYPE: this.callType.CITY,
            CD: countryCode,
        };
        if (this._shrd.isFedexAccount()) {
            params.URL = Constants.FEDEX_POSTAL_AND_CITY;
            api = this.apiCall(this.apiMethod.POST, params);
        } else {
            params.URL = Constants.CONST_VALIDATE_CITY_NOPOSTAL + countryCode + Constants.CONST_VALIDATE_CITY_CHILD_NOPOSTAL + city;
            api = this.apiCall(this.apiMethod.GET, params);
        }

        return api.retryWhen(this.handleRetry)
            .map((res) => {
                return this.extractData(res);
            }).catch(this.handleError);
    }

    apiCall(apiType, params: PostalParams) {
        let api;
        switch (apiType) {
            case 'POST':
                api = this._http
                    .post(params.URL, this.postalCityReqBody(params.TYPE, params.REQ, params.CD),
                        this.setRequestOptions(this.token()));
                break;
            case 'GET':
                api = this._http
                    .get(params.URL, this.setRequestOptions(this.token()));
                break;
            default:
                break;
        }
        return api;
    }

    postalCityReqBody(reqType, reqvalue, countryCode) {
        const body = {
            'matchAndResultsCriteria': {
                'address': {
                    'countryCode': countryCode
                },
                'matchConditions': [],
                'resultsToSkip': '0',
                'resultsRequested': '10000'
            }
        };

        switch (reqType) {
            case 'POSTAL':
                setParam('postalCode', 'MATCH_BY_EXACT_POSTAL_CODE');
                break;
            case 'CITY':
                setParam('city', 'MATCH_BY_EXACT_CITY');
                break;
            default:
                break;
        }

        function setParam(type, conditions) {
            body.matchAndResultsCriteria.address[type] = reqvalue;
            body.matchAndResultsCriteria.matchConditions.push(conditions);
        }
        return body;
    }

    token() {
        return this._shrd.isFedexAccount() ?
            ConstantsVAR.FEDEX_TOKEN : ConstantsVAR.ACCESS_TOKEN;
    }
}
