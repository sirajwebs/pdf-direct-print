/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved * Copyright * Fedex 2018
 *
 * Typescript code in this page
 */
import { Injectable } from '@angular/core';
import { ShipAdminDTO } from './../shared/models/shipadmin.model';
import { Http } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { Subscription } from 'rxjs/Subscription';
import 'rxjs/add/observable/of';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/share';
import 'rxjs/add/operator/map';
import 'rxjs/add/observable/throw';
import 'rxjs/add/operator/retry';
import { ConstantsURL } from '../shared/constants/constants-urls';
import { BaseService } from './base.service';
import { ConstantsVAR, FedexLoginConstants } from './../shared/constants/constants-var';
import { JsEncoderService } from './js-encoder.service';
import { PrivilegeDTO } from './../shared/models/privilege.models';

@Injectable()
export class FedexLogonService extends BaseService {
  apiSubscription = [];
  subscriptions: Array<Subscription> = [];

  constructor(private _http: Http, private _jsEcd: JsEncoderService) {
    super();
  }

  getShipAdminInfoAPI(): Observable<any> {
    return this._http
      .get(ConstantsURL.CONST_LOGIN + ConstantsURL.CONST_SHIPADMIN_INFO_V1,
        this.setRequestOptions(ConstantsVAR.FEDEX_TOKEN))
        .retryWhen(this.handleRetry)
        .map((res) => {
        return this.extractData(res);
      }).catch(this.handleError);
  }

  getPrivilege(shipAdminInfo: ShipAdminDTO) {
    return this._http
      .post(ConstantsURL.CONST_LOGIN + ConstantsURL.CONST_ADMINISTRATION_USERS_V1 + shipAdminInfo.companyID +
        ConstantsURL.CONST_PRIVILEGE_V1, shipAdminInfo, this.setRequestOptions(ConstantsVAR.FEDEX_TOKEN))
      .retry(ConstantsVAR.API_MAX_TRY)
      .map((res) => {
        return this.extractData(res);
      }).catch(this.handleError);
  }

  setShipAdminInfoObj(data) {
    /**
     * set the ship admin object for required IDs
     */
    const shipAdminData: ShipAdminDTO = {
      companyID: data['contactAndAddress']['companyID'],
      contactID: data['memberInfoVO']['contactID'],
      uuID: data['memberInfoVO']['uuID']
    };
    return shipAdminData;
  }

  savePrvlgToStorage(data: Array<PrivilegeDTO>) {
    /**
     * save the API to cache and take the backup into sessionStorage.
     */
    const filterdata = data.filter(el => {
      return FedexLoginConstants.PRIVILEGES_LIST.includes(el.privilegeID);
    });
    const prvlgENCD = this._jsEcd.encodeString(JSON.stringify(filterdata));
    sessionStorage.setItem(FedexLoginConstants.FEDEX_PRIVILEGE_ENCD, prvlgENCD);
  }

  fetchPrvlgFromStorage() {
    /**
     * fetch privilege data from sessionstorage first, if not available then call api again
     */
    let prvlg: Array<PrivilegeDTO> = [];
    try {
      prvlg = this.getPrvlgJson();
    } catch (error) {
      // write code to handle fallback scenarios to call shipadmin and privilege api
      const shpAdminInfo = this.getShpAdmnFromStorage();
      if (shpAdminInfo) {
        delete shpAdminInfo[FedexLoginConstants.FEDEX_ADMIN_DETAILS];
        this.getPrvlgApi(shpAdminInfo);
      }
    }
    return prvlg;
  }

  getPrvlgJson() {
    return JSON.parse(this._jsEcd.decodeString(sessionStorage.getItem(FedexLoginConstants.FEDEX_PRIVILEGE_ENCD)));
  }

  saveShpAdmnToStorage(shipAdminData, alldata) {
    shipAdminData[FedexLoginConstants.FEDEX_ADMIN_DETAILS] = alldata['adminDetailsType'];
    sessionStorage.setItem(FedexLoginConstants.FEDEX_SHIP_ADMIN_INFO, this._jsEcd.encode(JSON.stringify(shipAdminData)));
  }

  getShpAdmnFromStorage() {
    let shpAdmn = [];
    try {
      shpAdmn = this.getShpAdmnJson();
    } catch (error) {
      // write code to handle fallback scenarios, call shipadmininfo api again
      shpAdmn = [];
      this.getShipAdminInfoAPI().subscribe((data) => {
        this.setShipAdminInfo(data);
      });
    }
    return shpAdmn;
  }

  getShpAdmnJson() {
    return JSON.parse(this._jsEcd.decode(sessionStorage.getItem(FedexLoginConstants.FEDEX_SHIP_ADMIN_INFO)));
  }

  setShipAdminInfo(data) {
    if (data['output'].hasOwnProperty('contactProfile')) {
      const shipAdminData = this.setShipAdminInfoObj(data['output']['contactProfile']);
      this.getPrvlgApi(shipAdminData);
      this.saveShpAdmnToStorage(shipAdminData, data['output']['contactProfile']);
    }
  }

  getPrvlgApi(shipAdminData) {
    const apiName = 'getPrivilege';
    this.apiUnsubscribe(apiName);
    this.subscriptions.push(this.apiSubscription[apiName] =
      this.getPrivilege(shipAdminData).subscribe(privilege => {
        this.savePrvlgToStorage(privilege['output']['privilegeVOs']);
      }));
  }

  getFedexUserDetails() {
    const apiName = 'getFedexUserDetails';
    this.apiUnsubscribe(apiName);

    this.subscriptions.push(this.apiSubscription[apiName] =
      this.getShipAdminInfoAPI().subscribe((data) => {
        this.setShipAdminInfo(data);
      }));
  }

  apiUnsubscribe(apiName) {
    if (this.apiSubscription[apiName]) { this.apiSubscription[apiName].unsubscribe(); }
  }

}
