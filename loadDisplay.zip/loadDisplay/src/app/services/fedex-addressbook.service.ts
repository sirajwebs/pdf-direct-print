/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved *copyright* Fedex 2018
 *
 * Typescript code in this page
 */

import {
    AddressSearchDTO, AddressComponentDTO,
    UpdateEmailRequest, AddressBookResponse, SearchAddressResponse, GetEmailResponse,
    AddressRequestObject, AddressRequestPayLoad, GetAddressBookDTO
} from './../shared/models/addressbook.models';
import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { ConstantsURL as Constants } from '../shared/constants/constants-urls';
import { BaseService } from './base.service';
import { ConstantsVAR, AddressBookConst, AddressBookConst_Others, FedexLoginConstants } from './../shared/constants/constants-var';
import { JsEncoderService } from './js-encoder.service';
import { forkJoin } from 'rxjs/observable/forkJoin';
import { FedexLogonService } from './fedex-logon.service';

@Injectable()
export class FedexAddressbookService extends BaseService {

    constructor(
        private _http: Http, private _fdxLogin: FedexLogonService,
        private _jsEnc: JsEncoderService) { super(); }

    setAddressData(longName: string, shortName: string, type: string) {
        /**
         * set data into address component for company name, street line 1 and 2, city, postal code and country
         */
        const data: AddressComponentDTO = {
            long_name: longName ? longName : ConstantsVAR.EMPTY_STRING,
            short_name: shortName ? shortName : ConstantsVAR.EMPTY_STRING,
            types: [type]
        };
        return data;
    }

    emptyForNull(val) {
        /**
         * return null or undefined values as emptystring '',
         */
        return val ? val : ConstantsVAR.EMPTY_STRING;
    }

    apiError(error) {
        /**
         * get API error status code and return API error message
         */
        try {
            switch (error.status) {
                case ConstantsVAR.API_STATUS_CODE_400:
                    error._body = JSON.parse(error._body);
                    return (error._body['errors']) ? error._body['errors'][0].message : AddressBookConst.APIERROR.MESSAGE;
                case ConstantsVAR.API_STATUS_CODE_500:
                    error._body = JSON.parse(error._body);
                    return (error._body['userMessage']) ? error._body['userMessage'] : AddressBookConst.APIERROR.MESSAGE;
                default:
                    return AddressBookConst.APIERROR.MESSAGE;
            }
        } catch (err) {

        }
    }

    getCountryFromGoogle(countryCode: string): Observable<any> {
        /**
         * get full country name by passing two letter country code (eg, US for United States) to google geocode service
         * use google API Key and geocode url component to process the request
         */
        return this._http
            .get(Constants.GOOGLE_GEOCODE_ROOT_URL + Constants.GOOGLE_ROOT_URL_KEY +
            Constants.GOOGLE_API_KEY + Constants.GOOGLE_GEOCODE_ROOT_URL_COMPONENT + countryCode)
            .map((res: Response) => {
                return this.extractData(res);
            }).catch(this.handleError);
    }

    searchAddressBook(value: string, addrType: Array<string>, searchtype?: string): Observable<SearchAddressResponse> {
        /**
         * pass searchObject value (Note: searchObject is Observable of FedexRepsonseObject)
         * searches with company name or nick name and returns data based on search paramter
         * user privilege is also applied with search object
         */

        const searchObject: AddressSearchDTO = {
            searchType: searchtype ? searchtype : AddressBookConst.SearchTypeValue.COMPANY_NAME,
            searchValue: value,
            addressBookType: addrType,
            addressType: AddressBookConst_Others.FdxAddressType
        }
        const central = searchObject.addressBookType.find(el => el === AddressBookConst.bookType.CENTRAL)
        if (central) { searchObject.companyId = this.getCompanyId(); }
        return this._http.post(Constants.FEDEX_ADDRESS_BOOK.SEARCH, searchObject,
            this.setRequestOptions(ConstantsVAR.FEDEX_TOKEN))
            .map((res: Response) => {
                return this.extractData(res);
            }).catch(this.handleErrorAll);
    }

    saveAddressBook(addressObject: AddressRequestObject, addressBookType: Array<string>): Observable<AddressBookResponse> {
        /**
         * save address data to FedEx address Book
         * along with address data pass user privilege to save address
         * if nickname is already there in fedex address book, API will send contact ID: 0 as response
         */

        const saveAddressBookwithPrivelige: AddressRequestPayLoad = {
            partyInfoVO: {
                party:  addressObject ,
                partyType: AddressBookConst.partyType.RECIPIENT, // for 2.4 release
                addressBookType: addressBookType,
                addressAncillaryDetail: AddressBookConst.addressAntcillary
            }
        };
        return this._http.post(Constants.FEDEX_ADDRESS_BOOK.SAVE, saveAddressBookwithPrivelige,
            this.setRequestOptions(ConstantsVAR.FEDEX_TOKEN))
            .map((res: Response) => {
                return this.extractData(res);
            }).catch(this.handleError);
    }

    updateAddressBook(addressObject: AddressRequestObject, contactID: number, partyType: string):
    Observable<AddressBookResponse> {
        /**
         * update address data to FedEx address Book
         * along with address data pass user privilege to update address
         * on successfull response you will get same contactID which have been passed
         */
        const updateAddressBookwithPrivelige: AddressRequestPayLoad = {
            partyInfoVO: {
                party: addressObject,
                partyType: partyType,
                addressAncillaryDetail: AddressBookConst.addressAntcillary
            }
        };
        return this._http.put(Constants.FEDEX_ADDRESS_BOOK.SAVE + '/' + contactID + '/',
            updateAddressBookwithPrivelige, this.setRequestOptions(ConstantsVAR.FEDEX_TOKEN))
            .map((res: Response) => {
                return this.extractData(res);
            }).catch(this.handleError);
    }

    getAddressFromContactID(contactID: number): Observable<GetAddressBookDTO> {
        /**
         * pass Contact ID in URL to get address data related to contact ID
         * contact ID will be find the search/v3 API response when user selects the address
         * populate the required address data from the response in SPIRIT address form
         */
        return this._http.get(Constants.FEDEX_ADDRESS_BOOK.GET + contactID + '/',
            this.setRequestOptions(ConstantsVAR.FEDEX_TOKEN))
            .map((res: Response) => {
                return this.extractData(res);
            }).catch(this.handleErrorAll);
    }

    getContactEmail(contactID: number): Observable<GetEmailResponse> {
        /**
         * pass Contact ID in URL to get email address of the user for the corresponding address data
         * contact ID will be find the search/v3 API response when user selects the address
         * populate the email from the response in SPIRIT address form
         */

        return this._http.get(Constants.FEDEX_ADDRESS_BOOK.EMAIL.URL + contactID + Constants.FEDEX_ADDRESS_BOOK.EMAIL.PREFERENCES,
            this.setRequestOptions(ConstantsVAR.FEDEX_TOKEN))
            .map((res: Response) => {
                return this.extractData(res);
            }).catch(this.handleError);
    }

    updateContactEmail(contactID: number, email: string ): Observable<AddressBookResponse> {
        /**
         * pass Contact ID in URL to update email address of the user for the corresponding address data
         * contact ID will be find the search/v3 API response when user selects the address
         * updated email from the SPIRIT address form will be reflected in FedEx Address Book for corresponding address data
         */
        const updateBody: UpdateEmailRequest = {
            shipPartyPreference: {
                contactId: contactID,
                notifications: [
                    {
                        receivers: [{
                        notificationReceiverType: AddressBookConst.partyType.RECIPIENT, // for this release its recipient
                            medias: [{
                                emailAddresses: [
                                    {
                                        address: email
                                    }
                                ]
                            }]
                            }
                        ]
                    }
                ]
            }
        };
        return this._http.put(Constants.FEDEX_ADDRESS_BOOK.EMAIL.URL + contactID + Constants.FEDEX_ADDRESS_BOOK.EMAIL.PREFERENCES,
        updateBody, this.setRequestOptions(ConstantsVAR.FEDEX_TOKEN))
            .map((res: Response) => {
                return this.extractData(res);
            }).catch(this.handleError);
    }

    fetchAddrBkTypeFrmPrvlg(addrBk) {
        /**
         * create array for search address book
         * e.g. ['PERSONAL','CENTRAL']
         */
        const addrbkTyp = [];
        if (addrBk.personalCtrl) { addrbkTyp.push(AddressBookConst.bookType.PERSONAL); }
        if (addrBk.centralView) { addrbkTyp.push(AddressBookConst.bookType.CENTRAL); } // not required for 2.4 release
        return addrbkTyp;
    }

    getCompanyId() {
        /**
         * get company id from shipadmin API response
         * or get shipadmin data from session storage and decode the value
         * retun the decoded value
         */
        const shpAdmnInfo = this._fdxLogin.getShpAdmnFromStorage();

        if (shpAdmnInfo.length) {
            return shpAdmnInfo.hasOwnProperty(AddressBookConst.COMPANY_ID) ? shpAdmnInfo['companyID'] : false;
        } else {
            return false;
        }
    }

    getAddressAndEmailByContactID(contactID: number): Observable<Array<string>> {
        /**
         * get email address from getContactEmail method by passing contact id as required params
         * get complete address data from getAddressFromContactID method by passing contact id as required params
         * on successfull response, an array of response Objects are returned
         */
        const emailResponse = this.getContactEmail(contactID);
        const addressData = this.getAddressFromContactID(contactID);

        return forkJoin([emailResponse, addressData]);
    }
}
