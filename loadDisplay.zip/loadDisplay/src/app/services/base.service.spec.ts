/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved *copyright* FedEx 2018
 *
 * Typescript code in this page
 */

import { TestBed, inject } from '@angular/core/testing';
import { HttpEvent, HttpEventType } from '@angular/common/http';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { HttpClient, HttpResponse, HttpRequest, HttpParams } from '@angular/common/http';
import { HttpModule } from '@angular/http';
import { BaseService } from './base.service';

describe('SharedataService', () => {
    let service: BaseService;
    let httpMock: HttpTestingController;
    beforeEach(() => {
        TestBed.configureTestingModule({
            imports: [HttpClientTestingModule, HttpModule],
            providers: [BaseService]
        });
        service = TestBed.get(BaseService);
        httpMock = TestBed.get(HttpTestingController);
    });

    it('should be created', () => {
        expect(service).toBeTruthy();
    });

    /* it('response must be in json', () => {
         let response: Response
        const message = service.extractData(response);
    }); */
});
