/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved *copyright* FedEx 2018
 *
 * Typescript code in this page
 */
import { Directive, ElementRef, EventEmitter, Output, HostListener, Input, AfterViewInit, OnChanges, SimpleChanges } from '@angular/core';
import { NgModel, NgControl } from '@angular/forms';
import { } from '@types/googlemaps';

@Directive({
    selector: '[appGetCountry]',
    providers: [NgModel],

})
export class CountryApiDirective implements AfterViewInit, OnChanges {
    @Output() setCountry: EventEmitter<any> = new EventEmitter();
    @Output() setCountryDetails: EventEmitter<any> = new EventEmitter();
    @Input() public cntryPlceId;
    private _el: HTMLElement;
    private cntryObj = [];
    private cntryObj2 = [];

    constructor(private _elRef: ElementRef, private model: NgModel, private control: NgControl) { }

    invoke(some) {
        this.setCountry.emit(some);
    }

    @HostListener('input', ['$event'])
    onEvent($event) {

        if (this.control.control.value) {
            const request = {
                input: this.control.control.value,
                types: ['(regions)']
            };
            const autocompleteserv = new google.maps.places.AutocompleteService();
            autocompleteserv.getPlacePredictions(request, (result, status) => {
                if (result) {
                    this.cntryObj = [];
                    this.cntryObj2 = [];

                    for (let i = 0; i < result.length; i++) {
                        this.setCntryObj(result, i);
                        this.setAltCntryObj(result, i, request);
                        if (i === result.length - 1) {
                            this.setCountry.emit(this.cntryObj);
                            if (!this.cntryObj.length) {
                                this.setCountry.emit(this.cntryObj2);
                            }
                        }
                    }
                }
            });
        } else {
            this.onInputChange('');
        }
    }

    setCntryObj(result, i) {
        if (result[i].types.indexOf('country') >= 0) {
            this.cntryObj.push({
                'cntry_cd': result[i].structured_formatting.main_text,
                'id': result[i].place_id
            });
        }
    }

    setAltCntryObj(result, i, request) {
        if (result[i].types.indexOf('locality') >= 0) {
            const cnt = result[i].description.split(',');
            let val = cnt ? cnt[cnt.length - 1].trim() : '';
            val = val ? val[0].toLowerCase() === request.input[0].toLowerCase() ? val : '' : '';
            if (val) {
                this.cntryObj2.push({
                    'cntry_cd': val,
                    'id': result[i].place_id
                });
            }
        }
    }

    ngAfterViewInit() { }

    ngOnChanges(changes: SimpleChanges) {
        this._el = this._elRef.nativeElement;
        const input = <HTMLDivElement>this._el;
        if (changes) {
            if (changes.cntryPlceId) {
                if (this.cntryPlceId) {
                    const request = {
                        placeId: this.cntryPlceId.id
                    };
                    const autocompleteserv = new google.maps.places.PlacesService(input);
                    const self = this;
                    autocompleteserv.getDetails(request, function (result, status) {
                        if (result) {
                            self.onInputChange(result.address_components);
                        }
                    });
                }
            }
        }
    }

    onInputChange(res) {
        this.setCountryDetails.emit(res);
    }
}
