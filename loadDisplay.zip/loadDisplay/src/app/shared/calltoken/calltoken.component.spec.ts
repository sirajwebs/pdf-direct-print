/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved *copyright* FedEx 2018
 *
 * Typescript code in this page
 */
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CalltokenComponent } from './calltoken.component';

describe('CalltokenComponent', () => {
  let component: CalltokenComponent;
  let fixture: ComponentFixture<CalltokenComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CalltokenComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CalltokenComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
