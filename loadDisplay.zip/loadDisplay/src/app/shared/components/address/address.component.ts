/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved *copyright* FedEx 2018
 *
 * Typescript code in this page
 */
import { CalltokenComponent } from './../../calltoken/calltoken.component';
import { AddressService } from '../../../services/address.service';
import { GoogleplaceDirective } from './../../utils/googleplace.directive';
import {
  Component, OnInit, EventEmitter, Output, Input, OnChanges,
  OnDestroy, ViewChild, ChangeDetectorRef, SimpleChanges
} from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Subscription } from 'rxjs/Subscription';
import { ConstantsJson, KeyboardKey, KEYCODE, AddressBookConst } from './../../../shared/constants/constants-var';
import { ConstantsVAR } from './../../constants/constants-var';
import {
  FedExAddressResponseDTO, AddressCopyData, AddressFormData
} from './../../models/addressbook.models';
import { FedexAddressbookService } from './../../../services/fedex-addressbook.service';
import { FedexAddressBookComponent } from '../fedex-address-book/fedex-address-book.component';
import { SaveAddressBookComponent } from './../save-address-book/save-address-book.component';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/distinctUntilChanged';
import 'rxjs/add/operator/switchMap';
import 'rxjs/add/operator/retryWhen';
import { AllPrivilegesService } from 'app/services/privilege/allprivileges.service';
import { FORMS } from './../../constants/forms.properties';
import { SharedataService } from 'app/services/sharedata.service';
import { PostalApi } from 'app/shared/models/shared.models.';

@Component({
  selector: 'app-address',
  templateUrl: './address.component.html',
  styleUrls: ['./address.component.css']
})

export class AddressComponent implements OnInit, OnChanges, OnDestroy {
  @ViewChild(CalltokenComponent) public _calltoken: CalltokenComponent;
  @ViewChild(GoogleplaceDirective) public googlePlaceDirective: GoogleplaceDirective;
  @ViewChild(FedexAddressBookComponent) public _fedexAddrBkCmpnent: FedexAddressBookComponent;
  @ViewChild(SaveAddressBookComponent) public _sveAddrBkCmpnent: SaveAddressBookComponent;

  readonly FORMS = FORMS;
  subscriptions: Array<Subscription> = [];
  addressDetailForm = new FormGroup({
    cNme: new FormControl('', [Validators.required]),
    cPsn: new FormControl('', [Validators.required, Validators.pattern(FORMS.ADDRESS.CONTACT_PERSON.PATTERN)]),
    cd: new FormControl(''),
    l1: new FormControl('', Validators.required),
    l2: new FormControl(''),
    cntry: new FormControl('', [Validators.required, Validators.pattern(FORMS.ADDRESS.COUNTRY.PATTERN)]),
    pCd: new FormControl('', [Validators.required, Validators.pattern(FORMS.ADDRESS.POSTAL.PATTERN)]),
    cty: new FormControl('', Validators.required),
    tel: new FormControl('', [Validators.required, Validators.pattern(FORMS.ADDRESS.PHONE.PATTERN)]),
    e: new FormControl('', [Validators.required, Validators.email]),
    pIn: new FormControl(''),
    vat: new FormControl('')
  });

  @Input() public addrIdFlag;
  @Input() public isSameAddr;
  @Input() public useAddressData;
  @Output() public emitAddressData = new EventEmitter<{}>();
  @Output() public emitData = new EventEmitter<{}>();
  @Output() public postalAwareFlag = new EventEmitter<boolean>();
  @Input() public getData;
  @Input() public disableAll;

  citySuggestns = JSON.parse(JSON.stringify(ConstantsJson.addressInitObject));
  postalDisable = JSON.parse(JSON.stringify(ConstantsJson.addressInitBoolean));
  countryShrtName = JSON.parse(JSON.stringify(ConstantsJson.addressInitString));
  checkPstlAwr = JSON.parse(JSON.stringify(ConstantsJson.addressInitBoolean));
  fedexAddrID = JSON.parse(JSON.stringify(ConstantsJson.addressInitNumber));

  cityNameGoogle = ConstantsVAR.EMPTY_STRING;
  postalAwareStatus = ConstantsVAR.EMPTY_STRING;
  postalNonAwareCityStatus = ConstantsVAR.EMPTY_STRING;
  postalNonAwareCityList = [];
  country = [];
  postal = [];
  checkOrNot = null;
  checkingPostal = false;
  apiSubscription = [];
  dropdownStart = 0;
  selectCityFocus = false;
  @Input() public bookingFlag;
  @Input() public saveBtnClckd: boolean;
  @Output() public addrValueChange = new EventEmitter<boolean>();

  setPostalId = '';
  showPostalError = false;
  cntryPlceId = '';
  previousFormValue = {}; // check datatype***
  ctyserverErr = false;
  noCityFlg = JSON.parse(JSON.stringify(ConstantsJson.addressInitBoolean));

  hidePstlDrpDwnFlg = false;
  hideCntryDrpDwnFlg = false;
  showCntryError = false;
  minLength = false;
  invalidEmail = false;
  countCall = 0;

  // Fedex Address book related variables
  @Input() public addressBlock;
  @Input() public showGoogleAddress = {
    show: false
  };
  @Input() public viewBlock;
  @Input() public templateChange;
  @Output() public addressValue = new EventEmitter<string>();
  @Input() public fedexContactAddress;
  keyUp = 0;
  searchAddress = JSON.parse(JSON.stringify(ConstantsJson.addressInitObject));
  addressBookPrvlg = {};
  selectedAddrBkType = JSON.parse(JSON.stringify(ConstantsJson.addressInitString));
  hideSaveAddrButtonForSameData = JSON.parse(JSON.stringify(ConstantsJson.addressInitBoolean));
  hideSveBtnOnOverlay = JSON.parse(JSON.stringify(ConstantsJson.addressInitBoolean));

  constructor(private _cd: ChangeDetectorRef, private _addrService: AddressService,
    private _shrd: SharedataService, private _FedExAB: FedexAddressbookService, private _allPrvlg: AllPrivilegesService) { }

  ngOnInit() {
    /**
     * Enable or disable form control based on template or booking page.
     * If booking screen then bookingFlag is true.  If template screen then keep only pattern control.
    */

    this.addressBookPrvlg = this._allPrvlg.bookingPrvlg().addrBk;
    // this.assignNewFieldsForFedex();

    if (this.bookingFlag) {
      this.checkOrNot = true;
      if (this.saveBtnClckd) {
        Object.keys(this.addressDetailForm.controls).forEach(key => {
          this.addressDetailForm.get(key).markAsTouched();
        });
      }
    } else {
      this.checkOrNot = false;
      Object.keys(this.addressDetailForm.controls).forEach(key => {
        this.addressDetailForm.get(key).clearValidators();
        this.addressDetailForm.get(key).updateValueAndValidity();
      });
      this.clearRequiredFieldValidators();
    }
    /**
     * If the address section is not disabled then disable the field based on the condition in country field.
     */
    if (!this.disableAll) {
      this.toggleFieldEnable(this.useAddressData);
      this.emitDataFn(false, true);
      this.changedTemplate();
    }

    this.subscriptions.push(this.addressDetailForm.valueChanges.subscribe((val) => {
      /**
       * emit the changes when any form changes occured, to show cancel popup in booking/template.
       */
      Object.keys(this.addressDetailForm.controls).forEach((key) => {
        if (this.addressDetailForm.get(key).dirty) {
          this.addrValueChange.emit(true);
        }
      });
      /**
       * emit address data if there is new changes in the form, and emit the flagged data if address copy is checked.
       */
      if (!this.isEquivalent(this.previousFormValue, this.createBody())) {
        this.emitAddressData.emit(this.createBody());
        if (this.isSameAddr || this.disableAll) {
          this.emitDataFn(false);
        }
        this.checkFedexAddressChanges();
      }
      this.previousFormValue = this.createBody();
    }));

    this.resetAddressFieldsOnchange();

  }

  clearRequiredFieldValidators() {
    /**
      * clearing all required field validators and adding all pattern validators.
      */
    this.addressDetailForm.get('cPsn').setValidators([Validators.pattern(FORMS.ADDRESS.CONTACT_PERSON.PATTERN)]);
    this.addressDetailForm.get('cPsn').updateValueAndValidity();
    this.addressDetailForm.get('cntry').setValidators([Validators.pattern(FORMS.ADDRESS.COUNTRY.PATTERN)]);
    this.addressDetailForm.get('cntry').updateValueAndValidity();
    this.addressDetailForm.get('pCd').setValidators([Validators.pattern(FORMS.ADDRESS.POSTAL.PATTERN)]);
    this.addressDetailForm.get('pCd').updateValueAndValidity();
    this.addressDetailForm.get('tel').setValidators([Validators.pattern(FORMS.ADDRESS.PHONE.PATTERN)]);
    this.addressDetailForm.get('tel').updateValueAndValidity();
  }

  resetAddressFieldsOnchange() {
    /**
     * Reset and disable city field if postal code is cleared.
     */
    this.subscriptions.push(this.addressDetailForm.get('pCd').valueChanges.subscribe((val) => {
      if (!val || val === '') {
        this.postal = [];
        if (this.postalDisable[this.addrIdFlag] === false) {
          this.addressDetailForm.get('cty').reset();
          this.addressDetailForm.get('cty').disable();
          this.citySuggestns[this.addrIdFlag] = [];
        }
      }
    }));

    /**
     * Reset and disable city and postal field if country is cleared.
     */
    this.subscriptions.push(this.addressDetailForm.get('cntry').valueChanges.subscribe((val) => {
      if (!val || val === '') {
        this.country = [];
        this.addressDetailForm.get('pCd').reset();
        this.addressDetailForm.get('cd').reset();
        this.addressDetailForm.get('cty').reset();
        this.addressDetailForm.get('pCd').disable();
        this.addressDetailForm.get('cty').disable();
      }
    }));

    /**
    * Remove postal aware validation status if city is cleared.
    */
    this.subscriptions.push(this.addressDetailForm.get('cty').valueChanges.subscribe((val) => {
      if (!val || val === '') {
        this.postalNonAwareCityStatus = '';
      }
    }));
  }

  // assignNewFieldsForFedex() {
  //   if (this._shrd.isFedexAccount()) {
  //     this.addressDetailForm.addControl('vat', new FormControl(''));
  //   }
  // }

  checkDot(val) {
    /**
       * check first dot after @ string in email
       */
    if (val) {
      if (!this.checkOrNot) {
        this.addressDetailForm.get('e').setValidators([Validators.email]);
        this.addressDetailForm.get('e').updateValueAndValidity();
      }
      const v = val.split('@');
      if (v[1]) {
        const d = v[1].split('.');
        if (!d[1]) {
          this.invalidEmail = true;
          this.addressDetailForm.get('e').setErrors({});
        } else {
          this.invalidEmail = false;
        }
      }
    } else {
      this.invalidEmail = false;
      if (!this.checkOrNot) {
        this.addressDetailForm.get('e').clearValidators();
        this.addressDetailForm.get('e').updateValueAndValidity();
      }
    }

  }

  emitDataFn(flag, firstChange?) {
    /**
      * Emit the data of flags/validation errors to copy the address under other address section
      */
    this.copyAddrComponentData(flag);
    /**
     * create the json to emit the data
     */
    if (this.isSameAddr || this.disableAll || flag || firstChange) {
      const data = {
        'noCityFlg': this.noCityFlg,
        'countryShrtName': this.countryShrtName,
        'citySuggestns': this.citySuggestns,
        'checkPstlAwr': this.checkPstlAwr,
        'postalDisable': this.postalDisable,
        'fedexAddrID': this.fedexAddrID
      };
      this.emitData.emit(data);
    }
  }

  copyAddrComponentData(flag) {
    if (this.isSameAddr || this.disableAll || flag) {
      /**
       * copy the pickup/collection address flagged data to sender address data if copy flag is checked
       */
      if (this.addrIdFlag === 'p' || this.addrIdFlag === 's') {
        this.noCityFlg['s'] = this.noCityFlg['p'];
        this.countryShrtName['s'] = this.countryShrtName['p'];
        this.citySuggestns['s'] = this.citySuggestns['p'];
        this.checkPstlAwr['s'] = this.checkPstlAwr['p'];
        this.postalDisable['s'] = this.postalDisable['p'];
        this.fedexAddrID['s'] = this.fedexAddrID['p'];
      }
      /**
       * copy the delivery address flagged data to receiver address data if copy flag is checked
       */
      if (this.addrIdFlag === 'd' || this.addrIdFlag === 'r') {
        this.noCityFlg['r'] = this.noCityFlg['d'];
        this.countryShrtName['r'] = this.countryShrtName['d'];
        this.citySuggestns['r'] = this.citySuggestns['d'];
        this.checkPstlAwr['r'] = this.checkPstlAwr['d'];
        this.postalDisable['r'] = this.postalDisable['d'];
        this.fedexAddrID['r'] = this.fedexAddrID['d'];
      }
    }
  }

  ngOnChanges(changes: SimpleChanges) {
    /**
     * this ngOnChanges section determine all the change detection for interaction between the addresses.
     */

    this.toggleFieldsInitiate(changes);
    if (changes.templateChange) {
      this.changedTemplate();
    }
    this.copyAddrBkData();
    this.patchAddrOnChange(changes);
    this.patchAddrFlagOnChange(changes);
  }

  toggleFieldsInitiate(changes) {
    if (changes.disableAll && (this.addrIdFlag === 's' || this.addrIdFlag === 'r')) {
      this.countCall = 0;
      /**
       * disable/enable the fields based on change in copy address checkbox.
       */
      if (changes.disableAll.previousValue !== changes.disableAll.currentValue && changes.disableAll.currentValue !== null) {
        this.disableFieldsForView(this.disableAll);
        /**
         * emit the flag data when toggle in checkbox.
         */
        if ((!this.disableAll && !changes.disableAll.firstChange && changes.disableAll.previousValue) || this.disableAll) {
          this.toggleFieldEnable(this.useAddressData);
          this.resetFieldErrors();
          this.countCall = 1;
          this.emitDataFn(true);
        }
        /**
         * disable all the field if copy address, if not done already.
         */
        setTimeout(() => {
          if (this.disableAll) {
            this.disableFieldsForView(this.disableAll);
          }
        }, ConstantsVAR.MILISEC_3000);
      }
    }
    }

  patchAddrOnChange(changes) {
    /**
     * patch the address form data to copy the address between the sections.
     */
    if (this.useAddressData) {
      if (changes.useAddressData) {
        let isEqual;
        if (changes.useAddressData.previousValue && changes.useAddressData.currentValue) {
          isEqual = this.isEquivalent(changes.useAddressData.previousValue, changes.useAddressData.currentValue);
        }
        if (!isEqual) {
          this.patchAddrData(this.useAddressData, changes.useAddressData.firstChange,
            changes.useAddressData.previousValue ? changes.useAddressData.previousValue['cd'] : '',
            changes.useAddressData.currentValue['cd']);
        }
      }
    }
  }

  patchAddrFlagOnChange(changes) {
    /**
    * patch the address flag data like city suggestions, postal aware country, data to copy the address between the sections.
    */
    if (this.getData) {
      if (changes.getData) {
        if (this.addrIdFlag === 's' || this.addrIdFlag === 'r') {
          this.patchAddrFlaggedData(this.getData);
        }
      }
    }
  }

  resetFieldErrors() {
    this.postalNonAwareCityStatus = '';
  }

  changedTemplate() {
    this._sveAddrBkCmpnent.saveBtnDisable.next(true);
    this._fedexAddrBkCmpnent.checkFedeExAddress(this.addressDetailForm.get('cNme').value);
  }

  patchAddrFlaggedData(data) {
    /**
     * patch flag data/ clear validators based on value copied/emitted from other address section.
     */
    if (data) {
      this.noCityFlg = data['noCityFlg'] || [];
      this.countryShrtName = data['countryShrtName'] || [];
      this.citySuggestns = data['citySuggestns'] || [];
      this.checkPstlAwr = data['checkPstlAwr'] || [];
      this.postalDisable = data['postalDisable'] || [];
      this.fedexAddrID = data['fedexAddrID'] || [];
    }
    this.updateValidatorsForAddrFlag();
  }

  updateValidatorsForAddrFlag() {
    if (this.postalDisable[this.addrIdFlag]) {
      this.addressDetailForm.get('pCd').clearValidators();
      this.addressDetailForm.get('pCd').updateValueAndValidity();
      this.addressDetailForm.get('pCd').disable();
    } else if (!this.disableAll) {
      if (this.bookingFlag) {
        this.addressDetailForm.get('pCd').setValidators([Validators.required]);
        this.addressDetailForm.get('pCd').updateValueAndValidity();
      }
      if (this.addressDetailForm.get('cntry').value) {
        this.addressDetailForm.get('pCd').enable();
      }
    }
  }

  isEquivalent(a, b) {
    /**
     * check if two object are equal or not.
     */
    const aProps = Object.getOwnPropertyNames(a);
    const bProps = Object.getOwnPropertyNames(b);
    if (aProps.length !== bProps.length) {
      return false;
    }
    for (let i = 0; i < aProps.length; i++) {
      const propName = aProps[i];
      if (a[propName] !== b[propName]) {
        return false;
      }
    }
    return true;
  }

  ngOnDestroy() {
    this._cd.detach();
    this.subscriptions.forEach((subscription: Subscription) => { subscription.unsubscribe(); });
    Object.keys(this.apiSubscription).forEach(apiName => { this.apiUnsubscribe(apiName); });
    // remove virtual dom creation
    try {
      const doc = document.getElementsByClassName('pac-container');
      while (doc[0]) {
        doc[0].parentNode.removeChild(doc[0]);
      }
    } catch (err) { }
  }

  patchAddrData(data, firstChange, oldCntryCode, newCntryCode) {
    if (data) {
      /**
       * patch all the data in the form and emit the changes.
       */
      this.countryShrtName[this.addrIdFlag] = data.cd;
      Object.keys(data).forEach(name => {
        if (this.addressDetailForm.get(name)) {
          this.addressDetailForm.get(name).patchValue(data[name], { emitEvent: true });
        }
      });

      this.createCitySuggestions();
      this.revalidateCountryOnChange(firstChange, oldCntryCode, newCntryCode);
    }
  }

  createCitySuggestions() {
      /**
       * create the city suggestions array for dropdown.
       */
      if (this.citySuggestns[this.addrIdFlag] && this.useAddressData) {
        if ((this.citySuggestns[this.addrIdFlag].length === 0) &&
          this.useAddressData.cty && this.useAddressData.cd && this.useAddressData.pCd) {
          this.citySuggestns[this.addrIdFlag] = [{
            name: this.useAddressData.cty
          }];
          if (!this.disableAll) {
            this.addressDetailForm.get('cty').enable();
          }
        }
      }
  }

  revalidateCountryOnChange(firstChange, oldCntryCode, newCntryCode) {
      /**
       * check if country is changed to validate the country for postal aware or not.
       */
      if (((oldCntryCode !== newCntryCode) && newCntryCode) || firstChange || (this.disableAll === false && this.countCall === 0)) {
        if (this.disableAll === false) {
          this.countCall++;
        }
        if (firstChange && !this.disableAll) {
          this.disableAll = false;
        }
        if (!this.disableAll) {
          this.checkCountryPostalAware(this.countryShrtName[this.addrIdFlag], true, 'INIT');
        }
      }
    }

  createBody() {
    /**
     * create the address json body to emit/compare the address data
     */
    const addr: AddressFormData = {
      cNme: this.addressDetailForm.get('cNme').value,
      cPsn: this.addressDetailForm.get('cPsn').value,
      cd: this.addressDetailForm.get('cd').value,
      l1: this.addressDetailForm.get('l1').value,
      l2: this.addressDetailForm.get('l2').value,
      cntry: this.addressDetailForm.get('cntry').value,
      pCd: this.addressDetailForm.getRawValue().pCd || null,
      cty: this.addressDetailForm.getRawValue().cty || null,
      tel: this.addressDetailForm.get('tel').value,
      e: this.addressDetailForm.get('e').value,
      pIn: this.addressDetailForm.get('pIn').value,
      vat: this.addressDetailForm.get('vat').value,
    };
    return addr;
  }

  resetFieldNoCountry() {
    /**
     * when no country avalable then reset and diable the city and postal fields.
     */
    this.citySuggestns[this.addrIdFlag] = [];
    this.addressDetailForm.get('pCd').setValue('');
    this.addressDetailForm.get('cd').setValue('');
    this.addressDetailForm.get('cty').setValue('');
    this.addressDetailForm.get('pCd').clearValidators();
    this.addressDetailForm.get('pCd').updateValueAndValidity();
    this.addressDetailForm.get('pCd').disable();
    this.addressDetailForm.get('cty').disable();
    this.addressDetailForm.get('pCd').markAsTouched();
    this.addressDetailForm.get('cty').markAsTouched();
    this.postalDisable[this.addrIdFlag] = true;
  }

  toggleFieldEnable(data) {
    if (!data.cd) {
      this.resetFieldNoCountry();
    } else {
      if (!data.pCd) {
        /**
         * if there is no postal field then disable the city field.
         */
        if (this.postalDisable[this.addrIdFlag] === false) {
          this.citySuggestns[this.addrIdFlag] = [];
          this.addressDetailForm.get('cty').setValue('');
          this.addressDetailForm.get('cty').disable();
          this.addressDetailForm.get('cty').markAsTouched();
        }
      }
    }
  }

  getCmpnyNm(val, flag) {
    /**
     * when input typed in company field, get the google suggestions here and fill all the address data.
     */
    if (val.hasOwnProperty('ID') === true) {
      try {
        this.populateFedexAddress(val, flag);
      } catch (err) {
        this._shrd.setLoaderSrvc(false);
      }
    } else {
      this.clearPhoneandContactPerson(); // need to clear all
      this._sveAddrBkCmpnent.fromFedexAddressBook[this.addrIdFlag] = false;
      this.fedexAddrID[this.addrIdFlag] = 0;
      this.initiateAddressPopulate(val, flag);
    }
  }

  initiateAddressPopulate(val, flag) {
    try {
      if ((val.types).indexOf('establishment') > -1) {
        if (val.name.length > FORMS.ADDRESS.COMPANY.MAXLENGTH) {
          const estd = val.name.slice(0, FORMS.ADDRESS.COMPANY.MAXLENGTH);
          val.name = estd.slice(0, estd.lastIndexOf(' '));
        }
        if (flag === 'line1') {
          if (val.name) {
            this.addressDetailForm.get('cNme').patchValue(val.name);
          }
        } else {
          this.addressDetailForm.get('cNme').patchValue(val.name);
        }
      } else {
        if (flag === 'cmpNm') {
          this.addressDetailForm.get('cNme').reset();
        }
      }
      this.getAddress(val);
    } catch (err) { }
  }

  clearAddress() {
    this.addressDetailForm.get('cntry').reset();
    this.addressDetailForm.get('pCd').reset();
    this.addressDetailForm.get('cty').reset();
    this.addressDetailForm.get('l1').reset();
    this.addressDetailForm.get('l2').reset();
    this.citySuggestns[this.addrIdFlag] = [];
    this.postalDisable[this.addrIdFlag] = false;
    this.addressDetailForm.get('pCd').clearValidators();
    this.addressDetailForm.get('pCd').updateValueAndValidity();
    this.addressDetailForm.get('pCd').disable();
    this.addressDetailForm.get('cty').disable();
    this.noCityFlg[this.addrIdFlag] = false;
    this.selectCityFocus = false;
  }

  getAddress(val) {
    this.showPostalError = false;
    if (val.address_components) {
      /**
       * first reset all the data.
       */
      this.clearAddress();
      let cmpltAdrLine2 = '', cmpltAdrLine = '', pstlCd = '', gotCity = [];

      this.addressDetailForm.patchValue({ 'l2': cmpltAdrLine2.trim() });

      for (let i = 0; i < val.address_components.length; i++) {
         const fromGoogle = this.fedexAddrID[this.addrIdFlag] ? false : true; // not adherence to sonarcube
       // const fromGoogle = this.fedexAddrID[this.addrIdFlag]; // **wrong logic*** adherence to sonarcube
        if (fromGoogle) {
          cmpltAdrLine = this.patchAddrLine1(val, i, cmpltAdrLine, fromGoogle);
        } else {
          cmpltAdrLine = this.patchFedexAddrLine1(val, i, cmpltAdrLine, fromGoogle);
        }

        cmpltAdrLine2 = this.patchAddrLine2(val, i, cmpltAdrLine2);
        this.patchCountry(val, i);
        gotCity = this.patchCity(val.address_components, i, gotCity);
        pstlCd = this.patchPostalCd(val.address_components, i, pstlCd);

        if (!this._cd['destroyed']) { this._cd.detectChanges(); }

        if (i === (val.address_components.length - 1)) {
          this.validateAddressWithTNT(pstlCd);
        }
      }
      this.emitAddressData.emit(this.createBody());
    }
  }

  patchAddrLine1(val, i, cmpltAdrLine, fromGoogle) {
    /**
     * set address line 1 based on the google response. 30 char limit in address line 1.
     */

    if ((val.address_components[i].types.indexOf('route') > -1) ||
      (val.address_components[i].types.indexOf('street_number') > -1) ||
      (val.address_components[i].types.indexOf('sublocality_level_1') > -1)
    ) {
      if ((val.address_components[i].types.indexOf('sublocality_level_1') === -1)) {
        val = this.addrLine1ValueTrim(val, i, fromGoogle);
        if ((cmpltAdrLine.length + (val.address_components[i].long_name).length) < FORMS.ADDRESS.ADDR_LINE1.MAXLENGTH - 1) {
          if (cmpltAdrLine) {
            cmpltAdrLine = cmpltAdrLine.concat(', ', val.address_components[i].long_name);
          } else {
            cmpltAdrLine = cmpltAdrLine.concat(val.address_components[i].long_name);
          }
        }
      } else {
        val = this.addrLine1ValueTrim(val, i, fromGoogle);
        if ((cmpltAdrLine.length + (val.address_components[i].long_name).length) < FORMS.ADDRESS.ADDR_LINE1.MAXLENGTH - 1) {
          if (cmpltAdrLine === '') {
            cmpltAdrLine = cmpltAdrLine.concat(' ' + val.address_components[i].long_name);
          } else {
            cmpltAdrLine = cmpltAdrLine.concat(', ' + val.address_components[i].long_name);
          }
        }
      }
      this.addressDetailForm.patchValue({ 'l1': cmpltAdrLine.trim() });
    }

    return cmpltAdrLine;
  }

  patchFedexAddrLine1(val, i, cmpltAdrLine, fromGoogle) {
    /**
      * set address line 1 based on the fedex addr book response. 30 char limit in address line 1.
      */
    if (val.address_components[i].types.indexOf('street_number') > -1) {
      val = this.addrLine1ValueTrim(val, i, fromGoogle);
      cmpltAdrLine = val.address_components[i].long_name;
      this.addressDetailForm.patchValue({ 'l1': cmpltAdrLine.trim() });
    }
    return cmpltAdrLine;
  }

  addrLine1ValueTrim(val, i, fromGoogle) {
    if (val.address_components[i].long_name.length > FORMS.ADDRESS.ADDR_LINE1.MAXLENGTH) {
      const adr1 = val.address_components[i].long_name.slice(0, FORMS.ADDRESS.ADDR_LINE1.MAXLENGTH),
        spacePos = adr1.lastIndexOf(' ');
      val.address_components[i].long_name = fromGoogle ? adr1.slice(0, spacePos) : adr1;
    }
    return val;
  }

  patchAddrLine2(val, i, cmpltAdrLine2) {
    /**
      * patch addressline 2 from adddressbook only
      */
    if (val.address_components[i].types.indexOf(AddressBookConst.ADDRBK_GOOGLE_MAPPINGS_LINE2) > -1) {
      cmpltAdrLine2 = val.address_components[i].long_name;
      this.addressDetailForm.patchValue({ 'l2': cmpltAdrLine2.trim() });
    }
    return cmpltAdrLine2;
  }

  patchCountry(val, i) {
    /**
     * patch country details and check for postal aware.
     */
    if (val.address_components[i].types.indexOf('country') > -1) {
      this.countryShrtName[this.addrIdFlag] = val.address_components[i].short_name;
      this.addressDetailForm.patchValue({ 'cntry': val.address_components[i].long_name, 'cd': this.countryShrtName[this.addrIdFlag] });
      this.checkCountryPostalAware(this.countryShrtName[this.addrIdFlag], false);
    }
  }

  patchCity(value, i, gotCity) {
    /**
     * patch the city data if has the following data.
     * preference is ::: locality > sublocality > postal_town > neighborhood > administrative_area_level_1
     */
    if (value[i].types.indexOf('locality') > -1) {
      this.cityNameGoogle = value[i].long_name;
      gotCity['locality'] = true;
    } else if (value[i].types.indexOf('sublocality') > -1 && !gotCity['locality']) {
      this.cityNameGoogle = value[i].long_name;
      gotCity['sublocality'] = true;
    } else if (value[i].types.indexOf('postal_town') > -1 && !gotCity['locality'] && !gotCity['sublocality']) {
      this.cityNameGoogle = value[i].long_name;
      gotCity['postal_town'] = true;
    } else if (value[i].types.indexOf('neighborhood') > -1
      && !gotCity['locality'] && !gotCity['sublocality'] && !gotCity['postal_town']) {
      this.cityNameGoogle = value[i].long_name;
      gotCity['neighborhood'] = true;
    } else if (value[i].types.indexOf('administrative_area_level_1') > -1
      && !gotCity['locality'] && !gotCity['sublocality'] && !gotCity['postal_town'] && !gotCity['neighborhood']) {
      this.cityNameGoogle = value[i].long_name;
    }

    return gotCity;
  }

  patchPostalCd(value, i, pstlCd) {
    /**
     * patch postal data
     */
    if (value[i].types.indexOf('postal_code') > -1) {
      pstlCd = value[i].long_name;
      this.addressDetailForm.patchValue({ 'pCd': value[i].long_name });
    }
    return pstlCd;
  }

  validateAddressWithTNT(pstlCd) {
    const intrvl = setInterval(() => {
      if (this.postalAwareStatus === 'SCS') {
        if (this.countryShrtName[this.addrIdFlag] && this.checkPstlAwr[this.addrIdFlag]) {
          /**
           * if country has postal code/ postal aware then validate that postal code with TNT.
           */
          this.validateAddressApi(this.countryShrtName[this.addrIdFlag], pstlCd, 'YES');
          clearInterval(intrvl);
        } else {
          /**
          * if country does not have postal code/ non postal aware then validate that city only with TNT.
          */
          this.setCityDetailsNoSelectTNT('GGL');
          clearInterval(intrvl);
        }
      }
      /**
       * emit the flagged data after google response already set
       */
      this.emitDataFn(false);
    }, ConstantsVAR.MILISEC_300);
    setTimeout(() => { clearInterval(intrvl); }, ConstantsVAR.MILISEC_60000);
  }

  getCountry(ev) {
    /**
     * get the google response and pass the value for auto suggestions
     */
    this.country = ev || [];
    this.showPostalError = false;
    this.showCntryError = false;
    if (ev.length < 1) {
      this.showCntryError = true;
    } else {
      this.showCntryError = false;
    }
    if (!this._cd['destroyed']) {
      this._cd.detectChanges();
    }
  }

  getCountryCode(cntry) {
    /**
     * get country code place id from google
     */
    this.cntryPlceId = cntry;
    if (!this._cd['destroyed']) {
      this._cd.detectChanges();
    }
    this.hideCntryDrpDwnFlg = true;
  }

  setCountryDetails(value) {
    this.citySuggestns[this.addrIdFlag] = [];
    /**
     * set country details coming from google and check for postal aware
     */
    if (value) {
      for (let i = 0; i < value.length; i++) {
        if (value[i].types.indexOf('country') > -1) {
          if (this.countryShrtName[this.addrIdFlag] !== value[i].short_name) {
            this.noCityFlg[this.addrIdFlag] = false;
            this.addressDetailForm.get('cty').reset();
            this.addressDetailForm.get('pCd').reset();
            this.addressDetailForm.get('cntry').reset();
            this.addressDetailForm.get('cd').reset();
            this.countryShrtName[this.addrIdFlag] = '';
            this.setPostalId = '';
          }
          this.countryShrtName[this.addrIdFlag] = value[i].short_name;
          this.addressDetailForm.patchValue({ 'cntry': value[i].long_name, 'cd': this.countryShrtName[this.addrIdFlag] });
          this.checkCountryPostalAware(this.countryShrtName[this.addrIdFlag], true);
          if (!this._cd['destroyed']) {
            this._cd.detectChanges();
          }
        }
      }
    } else {
      this.addressDetailForm.get('cntry').reset();
      this.addressDetailForm.get('cd').reset();
      if (!this._cd['destroyed']) {
        this._cd.detectChanges();
      }
    }
  }

  postalAwareApiMappings(data) {
    /**
    * map the fedex/TNT api response and return the postal aware flag value.
    */
    let pstlAwr;
    if (this._shrd.isFedexAccount()) {
      pstlAwr = data.output.postalAware;
    } else {
      if (this.addrIdFlag === 's' || this.addrIdFlag === 'p') {
        pstlAwr = data.countryprofile.fields.COLPC.required;
      } else {
        pstlAwr = data.countryprofile.fields.DELPC.required;
      }
    }
    return pstlAwr;
  }

  checkCountryPostalAware(cntryCode, replace, callFlag?) {
    const checkPostal = (this.addrIdFlag === 's' || this.addrIdFlag === 'r') && this.addrIdFlag ? this.disableAll === false : true;
    this.postalAwareStatus = '';
    /**
     * check postal aware of a country and set the enable/disable fields. if a country is postal awre then postal field in mandate.
     */
    if (cntryCode && checkPostal) {
      const apiName = 'checkCountryPostalAware';
      this.apiUnsubscribe(apiName);

      this.subscriptions.push(this.apiSubscription[apiName] =
        this._addrService.postalAware(cntryCode).subscribe((data) => {
        this.postalAwareStatus = 'SCS';

          this.checkPstlAwr[this.addrIdFlag] = this.postalAwareApiMappings(data);

        if (this.checkPstlAwr[this.addrIdFlag]) {
          if (this.bookingFlag) {
            this.addressDetailForm.get('pCd').setValidators([Validators.required]);
            this.addressDetailForm.get('pCd').updateValueAndValidity();
          }
          this.addressDetailForm.get('pCd').enable();
          this.postalDisable[this.addrIdFlag] = false;
          this.postalAwareFlag.emit(true);
          if (callFlag === 'INIT') {
            this.validateAddressApi(this.countryShrtName[this.addrIdFlag], this.addressDetailForm.get('pCd').value, 'NO');
          }
        } else {
          if (replace) {
            this.addressDetailForm.get('pCd').setValue('');
          }
          this.addressDetailForm.get('pCd').clearValidators();
          this.addressDetailForm.get('pCd').updateValueAndValidity();
          this.addressDetailForm.get('pCd').disable();
          this.addressDetailForm.get('cty').enable();
          this.postalDisable[this.addrIdFlag] = true;
          this.postalAwareFlag.emit(false);
        }
      }, error => {
        this.postalAwareStatus = 'ERR';
        this.addressDetailForm.get('pCd').setValue('');
        this.addressDetailForm.get('cty').setValue('');
        this.addressDetailForm.get('pCd').disable();
        this.addressDetailForm.get('cty').disable();
        this.postalDisable[this.addrIdFlag] = false;
          this.retryMechanism(error);
      }));
    }
  }

  cityApiMappings(data) {
    /**
     * map the fedex/TNT api response and return the array with cities list.
     */
    let cities = [];
    if (this._shrd.isFedexAccount()) {
      cities = data.output.matchedAddresses;
    } else {
      cities = data;
    }
    return cities;
  }

  setCityDetailsNoSelectTNT(flag?) {
    /**
     * when no city data is selected from google suggestions dropdown / input
     */
    if (this.countryShrtName[this.addrIdFlag] && (this.addressDetailForm.get('cty').value || this.cityNameGoogle)) {
      const ctyVal = flag === 'GGL' ? this.cityNameGoogle : this.addressDetailForm.get('cty').value;
      const apiName = 'setCityDetailsNoSelectTNT';
      this.apiUnsubscribe(apiName);

      /**
       * if a country like ireland doen not have postal code aware then check the city name from TNT
       */
      this.subscriptions.push(this.apiSubscription[apiName] =
        this._addrService.postalNonAwareCity(this.countryShrtName[this.addrIdFlag], ctyVal).subscribe((data) => {

          this.postalNonAwareCityStatus = 'SCS';
          data = this.cityApiMappings(data);

          const dataFetch = data.filter((dataCity) => {
            if (dataCity.city && ctyVal) {
              return (dataCity.city.toLowerCase() === ctyVal.toLowerCase());
            }
          });
          this.postalNonAwareCityList = dataFetch;
          if (dataFetch.length > 0) {
            this.addressDetailForm.get('cty').setValue(dataFetch[0].city);
            this.citySuggestns[this.addrIdFlag] = [{ name: dataFetch[0].city }];
          } else if (flag === 'GGL') {
            this.addressDetailForm.get('cty').setValue('');
          }
         // this.ctyserverErr = false; // TODO check
        }, error => {
         // this.ctyserverErr = true;  // TODO check
          this.postalNonAwareCityStatus = 'ERR';
          this.retryMechanism(error);
        }));
    }
  }

  getPostal(ev) {
    /**
     * get the google response and pass the value for auto suggestions
     */
    this.noCityFlg[this.addrIdFlag] = false;
    this.postal = ev;
    if (ev.length > 0) {
      this.showPostalError = false;
    } else {
      this.showPostalError = true;
    }
    if (!this._cd['destroyed']) {
      this._cd.detectChanges();
    }
  }

  callDropdownPCD() {
    /**
     * reset the auto suggestions for postal
     */
    this.setPostalId = '';
    this.hidePstlDrpDwnFlg = false;
  }

  callDropdownCNT() {
    /**
     * reset the auto suggestions for country
     */
    this.cntryPlceId = '';
    this.hideCntryDrpDwnFlg = false;
    this.addressDetailForm.get('cntry').markAsUntouched();
  }

  getPostalCode(post) {
    /**
    * get postal code place id from google
    */
    this.showPostalError = false;
    this.setPostalId = post;
    if (!this._cd['destroyed']) {
      this._cd.detectChanges();
    }
    this.hidePstlDrpDwnFlg = true;
  }

  setpostalDetailsNoSelect() {
    /**
     * when no postal data is selected from google suggestions dropdown ,
     * if input value is matched then call validateAddressApi
     * otherwise check with the inputed data
     * TIMEOUT IS USED TO WAIT FOR THE USER TO DISAPPEAR THE SUGGESTIONS
     */
    if (!this.checkingPostal) {
      this.checkingPostal = true;
      setTimeout(() => {
        this.hidePstlDrpDwnFlg = true;
        if (this.addressDetailForm.get('pCd').value) {
          if (this.postal) {
            let count = 0;
            let pstl;
            for (let i = 0; i < this.postal.length; i++) {
              if (this.postal[i]['post_Cd'] && this.addressDetailForm.get('pCd').value) {
                const pcode = this.postal[i]['post_Cd'].split(',');
                if (pcode[0].toLowerCase() === this.addressDetailForm.get('pCd').value.toLowerCase()) {
                  pstl = this.postal[i];
                  count++;
                }
              }
              if (i === this.postal.length - 1) {
                if (count === 1) {
                  this.getPostalCode(pstl);
                } else {
                  this.validateAddressApi(this.countryShrtName[this.addrIdFlag], this.addressDetailForm.get('pCd').value, 'YES');
                }
              }
            }
            if (this.postal.length === 0) {
              this.validateAddressApi(this.countryShrtName[this.addrIdFlag], this.addressDetailForm.get('pCd').value, 'YES');
            }
          } else {
            this.validateAddressApi(this.countryShrtName[this.addrIdFlag], this.addressDetailForm.get('pCd').value, 'YES');
          }
        }
      }, ConstantsVAR.MILISEC_500);
      this.dropdownStart = 0;
      this.checkingPostal = false;
    }
  }

  setCountryDetailsNoSelect() {
    /**
    * when no postal data is selected from google suggestions dropdown
    * TIMEOUT IS USED TO WAIT FOR THE USER TO DISAPPEAR THE SUGGESTIONS
    */
    setTimeout(() => {
      this.hideCntryDrpDwnFlg = true;
      this.addressDetailForm.get('cntry').markAsTouched();
      if (this.addressDetailForm.get('cntry').hasError('pattern')) {
        this.showCntryError = true;
      }

      if (this.country) {
        let count = 0;
        let cntry;
        for (let i = 0; i < this.country.length; i++) {
          if (this.country[i]['cntry_cd'] && this.addressDetailForm.get('cntry').value) {
            if (this.country[i]['cntry_cd'].toLowerCase() === this.addressDetailForm.get('cntry').value.toLowerCase()) {
              cntry = this.country[i];
              count++;
            }
          }
          if (i === this.country.length - 1) {
            if (count === 1) {
              this.getCountryCode(cntry);
              this.showCntryError = false;
            } else {
              this.country = [];
              this.resetFieldNoCountry();
              this.showCntryError = true;
              this.addressDetailForm.get('cntry').setErrors({});
            }
          }
        }
      } else {
        this.resetFieldNoCountry();
        this.showCntryError = true;
        this.addressDetailForm.get('cntry').setErrors({});
      }
    }, ConstantsVAR.MILISEC_500);
    this.dropdownStart = 0;
  }

  setpostalDetails(value) {
    if (!this.checkingPostal) {
      this.checkingPostal = true;
      this.addressDetailForm.get('cty').reset();
      this.addressDetailForm.get('pCd').reset();
      this.citySuggestns[this.addrIdFlag] = [];

      if (value) {
        let pstlCd = '', gotCity = [];
        for (let i = 0; i < value.length; i++) {

          pstlCd = this.patchPostalCd(value, i, pstlCd);
          gotCity = this.patchCity(value, i, gotCity);

          /**
           * validate the address with postal with TNT
           */
          if (i === (value.length - 1)) {
            if (this.countryShrtName[this.addrIdFlag] && pstlCd) {
              this.validateAddressApi(this.countryShrtName[this.addrIdFlag], pstlCd, 'YES');
            }
          }
        }
      }

      this.checkingPostal = false;
    }
  }

  postalApiMappings(data) {
    /**
     * map the fedex/TNT api response and return the array with cities list.
     */
    let cities: PostalApi = {
      towns: []
    };
    if (this._shrd.isFedexAccount()) {
      const newList = data.output.matchedAddresses;
      newList.forEach(el => {
        cities.towns.push({ name: el.city });
      });
    } else {
      cities = data;
    }
    return cities;
  }

  validateAddressApi(cntry, postalCd, replace) {
    /**
     * validate the TNT api for a postal code and get the list of city available.
     * if tnt api dat match with google data then auto select that value
     */
    if (cntry && postalCd) {
      this.citySuggestns[this.addrIdFlag] = [];
      this.addressDetailForm.get('cty').disable();
      const apiName = 'validateAddressApi';
      this.apiUnsubscribe(apiName);

      this.subscriptions.push(this.apiSubscription[apiName] =
        this._addrService.validatePostalApi(cntry, postalCd).subscribe((data) => {

        data = this.postalApiMappings(data);

        this.citySuggestns[this.addrIdFlag] = data.towns;
        if (data.towns.length === 1) {
          if (replace === 'YES') {
            this.addressDetailForm.patchValue({ 'cty': data.towns[0].name });
            if (this.selectCityFocus) { this.citySetFocus(); }
          }
          this.addressDetailForm.get('cty').enable();
        } else {
          const dataFetch = data.towns.filter((dt) => {
            return dt.name.toLowerCase() === this.cityNameGoogle.toLowerCase();
          });
          if (this.selectCityFocus) {
            this.citySetFocus();
            this.addressDetailForm.get('cty').markAsUntouched();
          }
          if (dataFetch.length > 0) {
            this.addressDetailForm.patchValue({ 'cty': dataFetch[0].name });
          } else {
            if (!this.addressDetailForm.get('cty').value) {
              this.addressDetailForm.patchValue({ 'cty': '' });
            }
          }
          this.addressDetailForm.get('cty').enable();
        }
        this.ctyserverErr = false;
        this.noCityFlg[this.addrIdFlag] = false;
        if (!this._cd['destroyed']) { this._cd.detectChanges(); }
      }, (error) => {
          this.handlePostalApiError(error);
          this.retryMechanism(error);
        }));
    }
  }

  handlePostalApiError(error) {
    const assignErrorStatus = this._shrd.isFedexAccount() ?
      [ConstantsVAR.API_STATUS_CODE_400, error] : [ConstantsVAR.API_STATUS_CODE_404];

    if (assignErrorStatus.includes(error)) {
          this.noCityFlg[this.addrIdFlag] = true;
          this.addressDetailForm.get('pCd').setErrors({});
          this.citySuggestns[this.addrIdFlag] = [];
          if (!this._cd['destroyed']) { this._cd.detectChanges(); }
        } else {
          this.ctyserverErr = true;
          if (!this._cd['destroyed']) { this._cd.detectChanges(); }
        }
  }

  citySetFocus() {
    /**
     * Set City dropdown on focus after population city value from TNT service
     */
    setTimeout(() => {
      try {
        document.getElementById(this.addrIdFlag + 'city').focus();
      } catch (err) {
      }
    }, ConstantsVAR.MILISEC_100);
  }

  checkFocus() {
    this.selectCityFocus = !this.selectCityFocus;
  }

  formValidation(data) {
    /**
     * validate for mandatory value.
     */
    if (data) {
      if ((!this.addressDetailForm.get('cPsn').value || !this.addressDetailForm.get('cNme').value || !this.addressDetailForm.get('l1').value
        || (!this.addressDetailForm.get('pCd').value && this.postalDisable[this.addrIdFlag] === false)
        || !this.addressDetailForm.get('cty').value || !this.addressDetailForm.get('cntry').value
        || !this.addressDetailForm.get('tel').value || !this.addressDetailForm.get('e').value)) {
        return false;
      } else {
        return true;
      }
    } else {
      return true;
    }
  }

  navigateList(event, val, flag) {
    /**
     * Method to navigate user using keyboard up/down arrow keys for country and postal code
     * Select country or city using Spacebar key or Enter Key
     */

    if (flag === 'POSTAL') {
      this.callDropdownPCD();
    }
    if (flag === 'COUNTRY') {
      this.callDropdownCNT();
    }

    this.dropDownList(event, val);

    if (event.keyCode === KeyboardKey.KEY_SPACEBAR || event.keyCode === KeyboardKey.KEY_ENTER) {
      if (flag === 'POSTAL') {
        this.getPostalCode(val[this.dropdownStart - 1]);
      }
      if (flag === 'COUNTRY') {
        this.getCountryCode(val[this.dropdownStart - 1]);
      }
      event.stopPropagation();
    }
  }

  dropDownList(event, val) {
    if (event.keyCode === KeyboardKey.KEY_ARROW_DOWN) {
      if (val.length === this.dropdownStart) {
        this.dropdownStart = 1;
      } else {
        this.dropdownStart++;
      }
    } else if (event.keyCode === KeyboardKey.KEY_ARROW_UP) {
      if (this.dropdownStart > 1) {
        this.dropdownStart--;
      } else if (this.dropdownStart === 1) {
        this.dropdownStart = val.length;
      }
    }
  }

  dropDownDefault() {
    this.dropdownStart = 0;
    this.selectCityFocus = false;
  }

  disableFieldsForView(flag) {
    /**
     * disable all field if copy address is checked.
     */
    Object.keys(this.addressDetailForm.controls).forEach(key => {
      if (flag) {
        this.addressDetailForm.get(key).markAsTouched();
        this.addressDetailForm.get(key).disable();
      } else {
        this.addressDetailForm.get(key).markAsUntouched();
        this.addressDetailForm.get(key).enable();
      }
    });
  }

  allowKeyEntry(evt, val) {
    /**
     * allow or disallow key entry in telephone field.
     */

    const theEvent = evt;
    const keyCode = theEvent.keyCode || theEvent.which;
    // const ctrl = theEvent.ctrlKey ? theEvent.ctrlKey : (keyCode === KEYCODE._17 ? true : false);
    const ctrl = theEvent.ctrlKey ? theEvent.ctrlKey : (keyCode === KEYCODE._17); // adherence to sonarQube
    // const shift = theEvent.shiftKey ? true : false; // not adherence to sonarQube
    const shift = theEvent.shiftKey; // adherence to conarQube
    let len: number;
    try {
      len = this.addressDetailForm.get('tel').value.length;
    } catch (err) { }
    if (((!shift && keyCode >= KEYCODE._48) && (!shift && keyCode <= KEYCODE._57)
      || (keyCode >= KEYCODE._96 && keyCode <= KEYCODE._105)
      || (keyCode >= KEYCODE._37 && keyCode <= KEYCODE._40)
      || (keyCode === KEYCODE._8) || (keyCode === KEYCODE._9)
      || (shift && keyCode === KEYCODE._187 && (len === 0))
      || (shift && keyCode === KEYCODE._61 && (len === 0)) // mozilla browser keycode for 'plus' sign
      || (shift && keyCode === KEYCODE._187 && (val.selectionStart === 0))
      || (shift && keyCode === KEYCODE._61 && (val.selectionStart === 0)) // mozilla browser keycode for 'plus' sign
      || (keyCode === KEYCODE._107) && (len === 0)
      || (keyCode === KEYCODE._107) && (val.selectionStart === 0)
      || (keyCode === KEYCODE._13) || (keyCode === KEYCODE._46)
      || (keyCode === KEYCODE._86 && ctrl) || (keyCode === KEYCODE._67 && ctrl) && !theEvent.shiftKey
    )) {
      return true;
    } else {
      return false;
    }
  }

  checkAdrNull() {
    /**
     * check if all the addess form data is null or not
     */
    let isNull = true;
    Object.keys(this.addressDetailForm.controls).forEach((key) => {
      if (this.addressDetailForm.get(key).value) {
        if (this.addressDetailForm.get(key).value.length) {
          isNull = false;
        }
      }
    });
    return isNull;
  }

  onClickCntryDrpdwn(event: Object) {
    /**
     * close the country dropdown on select
     */
    if (event && event['value'] === true) {
      this.hideCntryDrpDwnFlg = true;
    } else {
      this.hideCntryDrpDwnFlg = false;
    }
  }

  onClickPstlDrpdwn(event: Object) {
    /**
     * close the postal dropdown on select
     */
    if (event && event['value'] === true) {
      this.hidePstlDrpDwnFlg = true;
    } else {
      this.hidePstlDrpDwnFlg = false;
    }
  }

  formValidationPattern() {
    /**
    * validate for mandatory/pattern in field value.
    */
    if (this.addressDetailForm.invalid) {
      Object.keys(this.addressDetailForm.controls).forEach(key => {
        if (this.addressDetailForm.get(key).invalid || this.addressDetailForm.get(key).hasError('pattern')) {
          this.addressDetailForm.get(key).markAsTouched();
        }
      });
      return false;
    } else {
      return true;
    }
  }

  resetAllData() {
    /**
     * reset all the address sections data on chnage on template in booking screen.
     */
    this.addressDetailForm.reset();
    this.cityNameGoogle = '';
    this.postalAwareStatus = '';
    this.postalNonAwareCityStatus = '';
    this.postalNonAwareCityList = [];
    this.disableAll = false;
    this.country = [];
    this.postal = [];
    this.setPostalId = '';
    this.showPostalError = false;
    this.cntryPlceId = '';
    this.previousFormValue = {};
    this.ctyserverErr = false;
    this.noCityFlg = JSON.parse(JSON.stringify(ConstantsJson.addressInitBoolean));
    this.hidePstlDrpDwnFlg = false;
    this.hideCntryDrpDwnFlg = false;
    this.showCntryError = false;
    this.citySuggestns = JSON.parse(JSON.stringify(ConstantsJson.addressInitObject));
    this.postalDisable = JSON.parse(JSON.stringify(ConstantsJson.addressInitBoolean));
    this.countryShrtName = JSON.parse(JSON.stringify(ConstantsJson.addressInitString));
    this.checkPstlAwr = JSON.parse(JSON.stringify(ConstantsJson.addressInitBoolean));
    this.fedexAddrID = JSON.parse(JSON.stringify(ConstantsJson.addressInitNumber));

    this.emitAddressData.emit([]);
    this.useAddressData = [];
    this.toggleFieldEnable(this.useAddressData);
    this._fedexAddrBkCmpnent.resetAllData();
    this._sveAddrBkCmpnent.resetAllData();
  }

  apiUnsubscribe(apiName) {
    if (this.apiSubscription[apiName]) { this.apiSubscription[apiName].unsubscribe(); }
  }

  retryMechanism(error, noBaseAPI?) {
    if (this._calltoken) {
      if (!noBaseAPI) { this._calltoken.callBaseService(error); }
  }
  }


  /*******************FEDEX ADDRESS BOOK***************/

  /**
   * FedEx Address Book Code STARTS
   */

  changeOnInput(block, viewBlock) {
    this.searchFedExAddress(block, viewBlock, this.addressDetailForm.get('cNme').value);
  }

  searchFedExAddress(block, viewBlock, value) {
    /**
     * Search address related to data entered in company name field
     * Check user previlige on searching address
     * search API call will trigger only when user has entered minimum of two character in company name
     * on successfull response, populate response as google like suggestion
     */
    const apiName = 'checkFedExAddress';
    this.apiUnsubscribe(apiName);
    this.showGoogleAddress.show = false;
    const addrBkTyp = this._FedExAB.fetchAddrBkTypeFrmPrvlg(this.addressBookPrvlg);
    if (value) {
      value = value.trim();
      if (value.length > 1 && addrBkTyp.length) {
        this._fedexAddrBkCmpnent.removeChildElements(block);
        this.addressValue.emit(value);

        this.subscriptions.push(this.apiSubscription[apiName] = this._FedExAB.searchAddressBook(value, addrBkTyp).subscribe(result => {
          this.searchAddress[this.addrIdFlag] = result['output'].contact;
          this.showGoogleAddress.show = true;
          this._fedexAddrBkCmpnent.setGoogleLikefedexAddress(
            value, block, viewBlock, this.searchAddress[this.addrIdFlag]);
        }, error => {
          this._fedexAddrBkCmpnent.removeChildElements(block);
          this.showGoogleAddress.show = true;
        }));
      } else {
        this._fedexAddrBkCmpnent.removeChildElements(block);
        this.showGoogleAddress.show = true;
      }
    } else {
      this.showGoogleAddress.show = true;
    }
  }

  populateFedexAddress(val, flag) {
    /**
     * populate phone number and contact person name from fedex search API response
     */
    this.setFedexAddress(this.searchAddress[this.addrIdFlag][val.ID], flag, this.addrIdFlag);
  }

  clearFormValue(formControlName) {
    /**
     * reset concerned formcontrol
     */
    this.addressDetailForm.get(formControlName).reset();
  }

  clearPhoneandContactPerson() {
    /**
     * reset phone number, email, contact person and collection / delivery instruction when google address suggestion are selected
     */
    this.clearFormValue('tel');
    this.clearFormValue('cPsn');
    this.clearFormValue('e');
    this.clearFormValue('pIn');
  }

  checkFedexAddressChanges() {
    if (!this.disableAll && this.addressDetailForm.get('cNme').value && this._sveAddrBkCmpnent.fromFedexAddressBook[this.addrIdFlag]) {
      // **** temporary fix
      const intrvl = setInterval(() => {
        if (this.addressDetailForm.get('cty').enabled) {
          const data = this.returnOriginalAddrBkDetails();
          this._fedexAddrBkCmpnent.fedexAddressChange(this.createBody(), data);
          clearInterval(intrvl);
        }
      }, ConstantsVAR.MILISEC_200);

      setTimeout(() => {
        clearInterval(intrvl);
      }, ConstantsVAR.MILISEC_1000 * ConstantsVAR.MINUTES_30);
    }
  }

  setEmailFromFedex(data) {
    this.addressDetailForm.get('e').patchValue(data);
  }

  setFedexAddress(data: FedExAddressResponseDTO, flag, id) {
    /**
     * Get complete country name using google geocode API by passing two letter country code which comes as response from FedEx Search API
     * populate all related detail from FedEx Search API to address form.
     */
    if (data.SEARCHING_TYPE !== AddressBookConst.SEARCHING_TYPE_INIT) { this.clearAddress(); }
    this._sveAddrBkCmpnent.saveBtnDisable.next(true);
    const apiName = 'getAddress_' + id;
    this.apiUnsubscribe(apiName);

    this.selectedAddrBkType[this.addrIdFlag] = data.addressBookType;
    this.copyAddrBkData();

    this.subscriptions.push(this.apiSubscription[apiName] =
      this._FedExAB.getAddressFromContactID(data.contactID).subscribe(response => {
        if (response.output.hasOwnProperty('partyInfoVO')) {
          this._fedexAddrBkCmpnent.getEmailId(data.contactID, id);
          this.getCountryFromGoogle(response.output.partyInfoVO.party, flag, id);
          this._sveAddrBkCmpnent.addressResponse[this.addrIdFlag] = data;
        }
        this._shrd.setLoaderSrvc(false);
      }, error => {
        this._shrd.setLoaderSrvc(false);
      }));
  }

  copyAddrBkData() {
    let data: AddressCopyData;
    this._shrd.getAddrBkCopyData.subscribe(val => { data = val; });
    switch (this.addrIdFlag) {
      case 'p':
        data['selectedAddrBkType']['p'] = this.selectedAddrBkType['p'];
        data['fedexAddressFormData']['p'] = this._fedexAddrBkCmpnent.fedexAddressFormData;
        break;
      case 'd':
        data['selectedAddrBkType']['d'] = this.selectedAddrBkType['d'];
        data['fedexAddressFormData']['d'] = this._fedexAddrBkCmpnent.fedexAddressFormData;
        break;
      default: break;
    }
    this._shrd.setAddrBkCopyData(data);
  }

  getCountryFromGoogle(data, flag, id) {
    const apiName = 'getCountryFromGoogle_' + id;
    this.apiUnsubscribe(apiName);
    this._shrd.setLoaderSrvc(true);

    this.subscriptions.push(this.apiSubscription[apiName] =
      this._FedExAB.getCountryFromGoogle(data.address.countryCode).subscribe(fullCountryName => {
        if (fullCountryName.hasOwnProperty('results')) {
          this._sveAddrBkCmpnent.fromFedexAddressBook[this.addrIdFlag] = true;
          this.fedexAddrID[this.addrIdFlag] = data.contact.contactId;
          const googleAlikeResponseObj = this._fedexAddrBkCmpnent.addCountryDataToFedexAddress(data,
            fullCountryName.results[0].address_components[0].long_name);
          this.initiateAddressPopulate(googleAlikeResponseObj, flag);
          this.addressDetailForm.get('tel').patchValue(this._fedexAddrBkCmpnent.getPhoneNumber(data.contact.phoneNumberDetails));
          this.addressDetailForm.get('cPsn').patchValue(data.contact.personName.fullName);
          this.addressDetailForm.get('pIn').patchValue(data.deliveryInstructions);
          this._fedexAddrBkCmpnent.setfedexAddressBody(data, fullCountryName.results[0].address_components[0].long_name);

          this.copyAddrBkData();
          this.trimFormsValue();

        } else {
          this._sveAddrBkCmpnent.showError('ERROR');
        }
        this._shrd.setLoaderSrvc(false);
      }, error => {
        this._shrd.setLoaderSrvc(false);
        this._sveAddrBkCmpnent.showError('ERROR');
      }));
  }

  addressFormValidation() {
    try {
      if (this.addressDetailForm.invalid) {
        Object.keys(this.addressDetailForm.controls).forEach(key => {
          if (this.addressDetailForm.get(key).hasError('pattern')) {
            this.addressDetailForm.get(key).markAsTouched();
          }
        });
        return false;
      } else {
        return true;
      }
    } catch (err) { }
  }

  hideSaveAddrBtnForSameData(data) {
    this.hideSaveAddrButtonForSameData[this.addrIdFlag] = data;
  }

  setUpdateFormValue(data) {
    this._fedexAddrBkCmpnent.fedexAddressFormData = data;
  }

  setFromAddressBook(data) {
    this._sveAddrBkCmpnent.fromFedexAddressBook[this.addrIdFlag] = data;
  }

  hideOnOverlay(data) {
    this.hideSveBtnOnOverlay[this.addrIdFlag] = data;
  }

  trimFormsValue() {
    const fieldLimitMappings = {
      cNme: FORMS.ADDRESS.COMPANY.MAXLENGTH,
      cPsn: FORMS.ADDRESS.CONTACT_PERSON.MAXLENGTH,
      cd: FORMS.ADDRESS.COUNTRY_CODE.MAXLENGTH,
      l1: FORMS.ADDRESS.ADDR_LINE1.MAXLENGTH,
      l2: FORMS.ADDRESS.ADDR_LINE2.MAXLENGTH,
      cntry: FORMS.ADDRESS.COUNTRY.MAXLENGTH,
      pCd: FORMS.ADDRESS.POSTAL.MAXLENGTH,
      cty: FORMS.ADDRESS.CITY.MAXLENGTH,
      tel: FORMS.ADDRESS.PHONE.MAXLENGTH,
      e: FORMS.ADDRESS.EMAIL.MAXLENGTH,
      pIn: FORMS.ADDRESS.INSTRUCTION.MAXLENGTH
    };

    Object.keys(this.addressDetailForm.controls).forEach((key) => {
      let val = this.addressDetailForm.get(key).value;
      if (val) {
        const limit = fieldLimitMappings[key];
        if (val.length > limit) {
          val = val.slice(0, limit);
          this.addressDetailForm.get(key).patchValue(val);
        }
      }
    });
  }

  returnOriginalAddrBkDetails() {
    let data: AddressCopyData, originalData: AddressFormData;
    this._shrd.getAddrBkCopyData.subscribe(val => { data = val; });

    originalData = this._fedexAddrBkCmpnent.fedexAddressFormData;

    switch (this.addrIdFlag) {
      case 's':
        if (this.fedexAddrID[this.addrIdFlag]) {
          if (this.fedexAddrID[this.addrIdFlag] === this.fedexAddrID['p']) {
            originalData = data.fedexAddressFormData['p'];
          }
        }
        break;
      case 'r':
        if (this.fedexAddrID[this.addrIdFlag]) {
          if (this.fedexAddrID[this.addrIdFlag] === this.fedexAddrID['d']) {
            originalData = data.fedexAddressFormData['d'];
          }
        }
        break;
      default: break;
    }
    return originalData;
  }
  /**
   * FedEx Address Book code Ends :-)
   */
}
