/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved *copyright* FedEx 2018
 *
 * Typescript code in this page
 */
import { Component, EventEmitter, Input, OnChanges, OnDestroy, OnInit, Output, SimpleChanges, ViewChild } from '@angular/core';
import { FormArray, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { TemplateService } from 'app/services/template.service';
import { MinMaxValue } from 'app/services/validators.service';
import { Subscription } from 'rxjs/Subscription';
import { ConstantsVAR, UNITS } from '../../constants/constants-var';
import { CalltokenComponent } from './../../calltoken/calltoken.component';
import { FORMS } from 'app/shared/constants/forms.properties';
import { SharedataService } from 'app/services/sharedata.service';
import { SharedFunctionsService } from 'app/services/shared-functions.service';
import { Packages } from 'app/shared/models/template.models';

@Component({
  selector: 'app-package-weights',
  templateUrl: './package-weights.component.html',
  styleUrls: ['./package-weights.component.css']
})
export class PackageWeightsComponent implements OnInit, OnChanges, OnDestroy {

  @ViewChild(CalltokenComponent) public _calltoken: CalltokenComponent;
  @Output() public packageData = new EventEmitter<any>();
  @Output() public packageDimensionsData = new EventEmitter<any>();
  @Output() packgValueChange = new EventEmitter<any>();
  @Output() packgValueChangeEmit = new EventEmitter<any>();
  @Input() public setPckgDataFlag;
  @Input() public setPckgDetails: Array<Packages>;
  @Input() public bookingFlag;
  @Input() public readonlyField;

  readonly FORMS = JSON.parse(JSON.stringify(FORMS));

  previousFormValue = {}; // check datatype ***
  checkOrNot = null;
  apiSubscription = [];
  pckgDetailsBody: Array<Packages>;

  packageForm = new FormGroup({
    itemRows: this._fb.array([this.initItemRows(this.initPckgValues())]),
    unitsType: new FormControl(FORMS.PACKAGE.DEFAULT_UNITS)
  });

  showEnvelope = false;
  subscriptions: Array<Subscription> = [];
  packageList = [];
  totalQuantity: number;
  totalVolume: number;
  totalWeight = 0;
  serverError = null;
  quantityNumbers = [];
  addPackageFlag = false;
  valuechange = false;
  prType: string;

  constructor(
    private _template: TemplateService,
    private _fb: FormBuilder,
    private _shrdFn: SharedFunctionsService,
    private _shrd: SharedataService) {
    this.quantityNumbers = new Array(FORMS.PACKAGE.QUANTITY.MAX).fill('', 0, FORMS.PACKAGE.QUANTITY.MAX).map((x, i) => i + 1);
    this.measurementsUnitsChanged();
  }

  ngOnInit() {
    Object.freeze(this.FORMS);

    this.fetchPackageList();
    this.setProductType();
    this.onBookingTemplateChange(this.setPckgDetails, this.setPckgDataFlag);

    this.subscriptions.push(this.packageForm.valueChanges.subscribe(val => {
      this.emitFormsValue();
    }));

    this.formOnChanges();
    this.getValues();
  }

  ngOnDestroy() {
    this.subscriptions.forEach((subscription: Subscription) => { subscription.unsubscribe(); });
    Object.keys(this.apiSubscription).forEach(apiName => { this.apiUnsubscribe(apiName); });
  }

  setProductType() {
    /**
     * package types logic a/c to business need (mapped with packages id)
     */
    if (this.setPckgDetails) {
      for (let i = 0; i < this.setPckgDetails.length; i++) {
        // TODO : write in shared function
        if ((this.setPckgDetails[i].id === FORMS.PACKAGE.TYPE.PALLET.ID) ||
          (this.setPckgDetails[i].id === FORMS.PACKAGE.TYPE.BOX.ID) ||
          (this.setPckgDetails[i].id === FORMS.PACKAGE.TYPE.ENVELOPE.ID && (this.setPckgDetails[i].enc === FORMS.PACKAGE.ENVELOPE.GOODS))) {
          this.prType = FORMS.PACKAGE.PRODUCT_TYPE.NON_DOC;
        } else if (this.setPckgDetails[i].id === FORMS.PACKAGE.TYPE.ENVELOPE.ID &&
          (this.setPckgDetails[i].enc === FORMS.PACKAGE.ENVELOPE.DOCS)) {
          this.prType = FORMS.PACKAGE.PRODUCT_TYPE.DOC;
        } else {
          this.prType = null;
        }
      }
    }
  }

  emitFormsValue() {
      /**
       * emit this when there is any changes in the packages sections
       */
      this.packgValueChangeEmit.emit(true);
      if (!this.addPackageFlag) {
        this.getValues();
        for (let i = 0; i < (<FormArray>this.packageForm.controls['itemRows']).value.length; i++) {
          let keepGoing = true;
          Object.keys((<FormGroup>(<FormArray>this.packageForm.controls['itemRows']).controls[i]).controls).forEach(key => {
            if (keepGoing) {
              if ((<FormGroup>(<FormArray>this.packageForm.controls['itemRows']).controls[i]).get(key).dirty) {
                this.packgValueChange.emit(true);
                keepGoing = false;
              }
            }
          });
        }
      }
  }

  fetchPackageList() {
    /**
     * get the default packages types stored into the DB
     */
    const apiName = 'fetchPackageList';
    this.apiUnsubscribe(apiName);

    this.subscriptions.push(this.apiSubscription[apiName] =
      this._template.getPackageListDrpdwn().subscribe(data => {
      this.packageList = data;
      this.serverError = false;
    }, error => {
      this.serverError = true;
        this.retryMechanism(error);
    }));
  }

  ngOnChanges(changes: SimpleChanges) {
    /**
     * trigger this whenever there is any change in the packages data input values
     */
    if (changes.setPckgDetails) {
      if ((changes.setPckgDetails.previousValue !== changes.setPckgDetails.currentValue) && changes.setPckgDetails.currentValue) {
        this.onBookingTemplateChange(this.setPckgDetails, this.setPckgDataFlag);
        this.getValues();
      }
    }
  }

  emitChanges() {
    this.formOnChanges();
    this.packgValueChangeEmit.emit(true);
  }

  onBookingTemplateChange(setPckgDetails: Array<Packages>, setPckgDataFlag: boolean, skip?: boolean) {
    /**
     * create the form array for the package component along with the validators
     */
    if (setPckgDataFlag) {

      this.deleteAllPack();

      if (this.packageForm) {
        const control = <FormArray>this.packageForm.controls['itemRows'];
        if (setPckgDetails) {
          if (setPckgDetails[0].scale && !skip) {
            this.packageForm.get('unitsType').setValue(setPckgDetails[0].scale);
          }
          for (let i = 0; i < setPckgDetails.length; i++) {
            control.push(this.initItemRows(setPckgDetails[i]));
          }
        }
      }
    }
  }

  formOnChanges() {
    /**
     * Calls on form value changes
     * to emit default values to parent component
     */
    this.packageBodyCreator(this.packageForm.get('itemRows').value);
    this.subscriptions.push(this.packageForm.get('itemRows').valueChanges.subscribe((formData) => {
      if (!this.addPackageFlag) {
        this.checkDocType(formData);
        this.onChangeValidation();
        this.packageBodyCreator(formData);
        formData.forEach((formEle, index) => {
          if (formEle.packagetype) {
            if (+(formEle.packagetype) === FORMS.PACKAGE.TYPE.ENVELOPE.ID) {
              this.showEnvelope = true;
            } else {
              this.showEnvelope = false;
            }
          }
        });
      }
    }));
  }



  /**
   * Logic to check every field if it is valid or not.
   * First remove unwanted controls for envelope.
   *  If FormArray is invalid iterate over array and den iterate over controls.
   * Check if formcontrol is valid  and touched, if satisifes push true to tempArray else push false.
   *   then check for true in temp arra if availble show error message else hide
   */

  onChangeValidation() {
    this.getValues();
    this.packageBodyCreator(this.packageForm.get('itemRows').value);
  }

  checkDocType(formData) {
    /**
    * package types logic a/c to business need (mapped with packages id)
    */
    const pcktypArray = [];
    for (let i = 0; i < formData.length; i++) {
      pcktypArray.push(+(formData[i].packagetype));
      if (i === (formData.length - 1)) {
        for (let j = 0; j < pcktypArray.length; j++) {
          // TODO : write in shared function
          if ((pcktypArray[j] === FORMS.PACKAGE.TYPE.BOX.ID) || (pcktypArray[j] === FORMS.PACKAGE.TYPE.PALLET.ID) ||
            (pcktypArray[j] === FORMS.PACKAGE.TYPE.ENVELOPE.ID && (formData[j].envelope === FORMS.PACKAGE.ENVELOPE.GOODS))) {
            this.prType = FORMS.PACKAGE.PRODUCT_TYPE.NON_DOC;
          } else if (pcktypArray[j] === FORMS.PACKAGE.TYPE.ENVELOPE.ID && (formData[j].envelope === FORMS.PACKAGE.ENVELOPE.DOCS)) {
            this.prType = FORMS.PACKAGE.PRODUCT_TYPE.DOC;
          } else {
            this.prType = null;
          }
        }
      }
    }
  }

  getEnvelope(val) {
    if (+(val.get('packagetype').value) === FORMS.PACKAGE.TYPE.ENVELOPE.ID) {
      return true;
    } else {
      return false;
    }
  }

  getValues() {
    this.totalWeight = 0;
    let volumeTemp = 0;
    this.totalQuantity = 0;
    const factor = this._shrdFn.unitConversion(this.packageForm.get('unitsType').value, UNITS.VOLUME);

    /**
     * to check whether a row is touched or not & if touched whether values are entered or not
     *  If not entered-  showReqError -is made to true
     */
    (<FormArray>this.packageForm.get('itemRows')).controls.forEach((element, index) => {
      let packWeight;
      let packHeight;
      let packLength;
      let packWidth;
      const packagetype = element.get('packagetype').value;
      const quan = element.get('quantity').value;

      if (element.get('packageWeight')) {
        packWeight = element.get('packageWeight').value * quan;
      }
      if (element.get('packageHeight')) {
        packHeight = element.get('packageHeight').value;
      }
      if (element.get('packageLength')) {
        packLength = element.get('packageLength').value;
      }
      if (element.get('packageWidth')) {
        packWidth = element.get('packageWidth').value;
      }

      if (packWeight) {
        this.totalWeight += parseFloat(packWeight);
        this.totalWeight = this._shrdFn.roundUp3digit(this.totalWeight);
      }
      if (!this.totalWeight) {
        this.totalWeight = 0;
      }

      if (+packagetype === FORMS.PACKAGE.TYPE.ENVELOPE.ID) {
        packHeight = 1; packLength = 1; packWidth = 1;
      }

      if ((!isNaN(parseFloat(packLength))) && (!isNaN(parseFloat(packHeight))) && (!isNaN(parseFloat(packWidth)))) {
        volumeTemp += +((parseFloat(packLength) * parseFloat(packHeight) * parseFloat(packWidth)) * quan)
          / (Math.pow(UNITS.M2CM - factor, UNITS.ROUNDOFF_POW));
      }

      if (isNaN(volumeTemp)) {
        if (isNaN(this.totalVolume)) {
          this.totalVolume = 0;
        }
      } else {
        this.totalVolume = +volumeTemp;
        this.totalVolume = this._shrdFn.roundUp3digit(this.totalVolume);
      }

      this.totalQuantity += +parseInt(quan, ConstantsVAR.DIGIT_10);
      if (this.totalQuantity > FORMS.PACKAGE.QUANTITY.MAX) {
        this.packageForm.controls.itemRows.setErrors({});
      }
      const dimensionData = {
        'vol': +volumeTemp,
        'quant': this.totalQuantity,
        'wt': this.totalWeight,
        'prType': this.prType
      };

      if (this.packageForm.get('itemRows').value.length - 1 === index) {
        this.packageDimensionsData.emit(dimensionData);
      }
    });

  }

  setDefaultPackageType() {
    const def = FORMS.PACKAGE.TYPE.DEFAULT;
    return this._shrd.isFedexAccount() ? def.FEDEX : def.TNT;
  }

  initItemRows(val: Packages) {
    /**
     * Initialize an Empty Row
     */

    this.valuechange = false;
    let formBuilder = this._fb.group({
      packagetype: new FormControl(val.id, Validators.required),
      quantity: new FormControl(val.q, Validators.required),
      packageHeight: new FormControl(val.h, [Validators.required,
      MinMaxValue(this.FORMS.PACKAGE.HEIGHT.MIN, this.FORMS.PACKAGE.HEIGHT.MAX)]),
      packageWidth: new FormControl(val.wd, [Validators.required,
      MinMaxValue(this.FORMS.PACKAGE.WIDTH.MIN, this.FORMS.PACKAGE.WIDTH.MAX)]),
      packageLength: new FormControl(val.l, [Validators.required,
      MinMaxValue(this.FORMS.PACKAGE.LENGTH.MIN, this.FORMS.PACKAGE.LENGTH.MAX)]),
      packageWeight: new FormControl(val.wg, [Validators.required,
      Validators.min(this.FORMS.PACKAGE.WEIGHT.MIN), Validators.max(this.FORMS.PACKAGE.WEIGHT.MAX)]),
      envelope: new FormControl(val.enc)
    });

    if (this.bookingFlag) {
      this.checkOrNot = true;
    } else {
      this.checkOrNot = false;

      formBuilder = this.updateValidators(formBuilder, 'packageHeight', 'HEIGHT');
      formBuilder = this.updateValidators(formBuilder, 'packageWidth', 'WIDTH');
      formBuilder = this.updateValidators(formBuilder, 'packageLength', 'LENGTH');

      formBuilder.get('packageWeight').clearValidators();
      formBuilder.get('packageWeight').setValidators(
        [Validators.min(this.FORMS.PACKAGE.WEIGHT.MIN), Validators.max(this.FORMS.PACKAGE.WEIGHT.MAX)]);
      formBuilder.get('packageWeight').updateValueAndValidity();
    }

    return formBuilder;
  }

  updateValidators(formBuilder, formControl, attributes) {

    formBuilder.get(formControl).clearValidators();
    formBuilder.get(formControl).setValidators(
      MinMaxValue(this.FORMS.PACKAGE[attributes].MIN, this.FORMS.PACKAGE[attributes].MAX));
    formBuilder.get(formControl).updateValueAndValidity();

    return formBuilder;
    }

  initPckgValues() {
    let pckgVal: Packages;
    pckgVal = {
      id: this.setDefaultPackageType(),
      l: '',
      wd: '',
      h: '',
      wg: '',
      q: FORMS.PACKAGE.QUANTITY.DEFAULT,
      enc: FORMS.PACKAGE.ENVELOPE.GOODS
    };
    return pckgVal;
  }

  addPackageRow() {
    /**
     * Adds a Row and call the validations change method
     */
    this.valuechange = false;
    this.addPackageFlag = true;
    const control = <FormArray>this.packageForm.controls['itemRows'];
    control.push(this.initItemRows(this.initPckgValues()));
    this.addPackageFlag = false;
    this.onChangeValidation();
  }


  packageBodyCreator(formData) {
    /**
     *  Create body and pass data to create template component 
     */
    const packageBody = [];
    const scale = this.packageForm.get('unitsType').value;
    try {
      if (formData) {
        for (let i = 0; i < formData.length; i++) {
          if (+formData[i].packagetype === FORMS.PACKAGE.TYPE.ENVELOPE.ID) {
            packageBody.push(
              {
                'id': formData[i].packagetype,
                'q': formData[i].quantity,
                'enc': formData[i].envelope,
                'wg': formData[i].packageWeight,
              });

          } else {
            packageBody.push(
              {
                'id': formData[i].packagetype,
                'q': formData[i].quantity,
                'l': formData[i].packageLength,
                'wd': formData[i].packageWidth,
                'h': formData[i].packageHeight,
                'wg': formData[i].packageWeight,
              });
          }
          if (this._shrd.isFedexAccount()) {
            packageBody[packageBody.length - 1]['scale'] = scale;
          }
          if (formData.length - 1 === i) {
            this.packageData.emit(packageBody);
            this.pckgDetailsBody = packageBody;
          }
        }
      }
    } catch (error) { }
  }


  deletePackageConfirm(index: number) {
    /**
     * delete a package row data along with the formcontrols
     */
    if (this.packageForm) {
      try {
        const control = <FormArray>this.packageForm.controls['itemRows'];
        control.removeAt(index);
        this.onChangeValidation();
        this.valuechange = true;
        this.packgValueChangeEmit.emit(true);
      } catch (error) { }
    }
  }

  deleteAllPack() {
    /**
     * delete the complete forms control array
     */
    if (this.packageForm) {
      const control = <FormArray>this.packageForm.controls['itemRows'];
      while (control.controls.length) {
        control.removeAt(0);
      }
    }
  }

  formValidation() {
    /**
     *  Validate Form on click of save in create template page
     */
    this.removeControls();
    if (this.packageForm.get('itemRows').invalid) {
      if ((<FormArray>this.packageForm.controls['itemRows']).value) {
        for (let i = 0; i < (<FormArray>this.packageForm.controls['itemRows']).value.length; i++) {
          const controlNameArr = Object.keys((<FormGroup>(<FormArray>this.packageForm.controls['itemRows']).controls[i]).controls);
          for (let ind = 0; ind < controlNameArr.length; ind++) {
            (<FormGroup>(<FormArray>this.packageForm.controls['itemRows']).controls[i]).controls[controlNameArr[ind]]
              .markAsTouched({ onlySelf: true });
          }
        }
      }
      return false;
    } else {
      return true;
    }
  }

  formValidationRequiredField() {
    this.removeControls();
    if (this.packageForm.get('itemRows').invalid) {
      return false;
    } else {
      return true;
    }
  }

  removeControls() {
    /**
     * remove the length , width and height formcontrol when packgae type pallete is selected
     */
    for (let i = 0; i < (<FormArray>this.packageForm.controls['itemRows']).value.length; i++) {
      if (+((<FormGroup>(<FormArray>this.packageForm.controls['itemRows']).controls[i]).get('packagetype').value)
        === FORMS.PACKAGE.TYPE.ENVELOPE.ID) {
        (<FormGroup>(<FormArray>this.packageForm.controls['itemRows']).controls[i]).removeControl('packageLength');
        (<FormGroup>(<FormArray>this.packageForm.controls['itemRows']).controls[i]).removeControl('packageHeight');
        (<FormGroup>(<FormArray>this.packageForm.controls['itemRows']).controls[i]).removeControl('packageWidth');
      }
    }
  }

  onpackageTypeChange(lt) {
    /**
     * reset the selected row fomcontrol when package type changes 
     */
    lt.patchValue({
      'quantity': 1
    });
    lt.get('packageLength').reset();
    lt.get('packageWidth').reset();
    lt.get('packageHeight').reset();
    lt.get('packageWidth').reset();
    lt.get('packageWeight').reset();
    lt.get('envelope').reset();
    lt.get('envelope').setValue(FORMS.PACKAGE.ENVELOPE.GOODS);

    this.onChangeValidation();
  }

  getMeasurementUnits() {
    /** to get the type of measureent units details like length, weight units */
    const units = FORMS.PACKAGE.MEASUREMENT_UNITS.find(el => el.TYPE === this.packageForm.get('unitsType').value);
    return units;
  }

  measurementsUnitsChanged() {
    this.subscriptions.push(this.packageForm.get('unitsType').valueChanges.subscribe(val => {
      // all forms properties changes/mappings code here
      const FIELDS = ['LENGTH', 'WIDTH', 'HEIGHT', 'WEIGHT']; // these constants refers to FORM properties files
      for (const fld of FIELDS) {
        const LimitType = ['MIN', 'MAX'];
        for (const mm of LimitType) {
          const factor = this._shrdFn.unitConversion(val, UNITS[fld]);
          this.FORMS.PACKAGE[fld][mm] = Math.ceil(
            FORMS.PACKAGE[fld][mm] / factor);
        }
      }
      // reinitiate the form validations
      this.onBookingTemplateChange(this.pckgDetailsBody, true, true); //siraj

    }));
  }

  apiUnsubscribe(apiName) {
    if (this.apiSubscription[apiName]) { this.apiSubscription[apiName].unsubscribe(); }
  }

  retryMechanism(error, noBaseAPI?) {
    if (this._calltoken) {
      if (!noBaseAPI) { this._calltoken.callBaseService(error); }
      }
    }

}
