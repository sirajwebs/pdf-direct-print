/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved *copyright* FedEx 2018
 *
 * Typescript code in this page
 */

import { Component, Input, OnChanges, SimpleChanges } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-booking-address',
  templateUrl: './booking-address.component.html',
  styleUrls: ['./booking-address.component.css']
})
export class BookingAddressComponent implements OnChanges {

  bookingAddrForm = new FormGroup({
    adrCmpnyName: new FormControl(''),
    addCntctName: new FormControl(''),
    addLineOne: new FormControl(''),
    addLineTwo: new FormControl(''),
    addLineThree: new FormControl(''),
    addpCd: new FormControl(''),
    addCty: new FormControl(''),
    addCntry: new FormControl(''),
    serviceType: new FormControl(''),
    addE: new FormControl(''),
    addpckInst: new FormControl(''),
    addTel: new FormControl(''),
    addExt: new FormControl(''),
    addrId: new FormControl('')
  });

  showEditAddress = false;
  saveAddData: boolean;
  @Input() public addrIdFlag;
  @Input() public editAddressDetails;
  noAddress = false;
  constructor() { }

  ngOnChanges(changes: SimpleChanges) {
    if (this.editAddressDetails) {
      if (changes.editAddressDetails) {
        if (changes.editAddressDetails.previousValue !== changes.editAddressDetails.currentValue) {
          this.patchFormValue(this.editAddressDetails);
        }
      }
    }
  }

  patchFormValue(data) {
    /**
     * patch all the value of address components
     */
    if (data) {
      this.bookingAddrForm.patchValue({
        addCntctName: data.cPsn,
        adrCmpnyName: data.cNme,
        addName: data.cd,
        addLineOne: data.l1,
        addLineTwo: data.l2,
        addLineThree: data.l3,
        addpCd: data.pCd,
        addCty: data.cty,
        addCntry: data.cntry,
        addTel: data.tel,
        addExt: data.ext,
        addE: data.e,
        addpckInst: data.pIn,
      }, { emitEvent: false });
    }
  }
}

