/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved *copyright* FedEx 2018
 *
 * Typescript code in this page
 */

export interface LoginRequestV2 {
    userName: string;
    password: string;
    }

export interface LoginResponseV2 {
    output: {
    userProfile: UserProfile,
    loginCookieOutputVO: {
        fclCookie: string,
        nameCookie: string,
        contactNameCookie: string,
        uuidCookie: string
    }
    };
    }

export interface UserProfile {
        registeredContactAndAddress: {
            contact: {
                personName: {
                    firstName: string | null,
                    middleName: string | null,
                    lastName: string | null
                },
                companyName: string | null,
                phoneNumber: number | null,
                emailAddress: string | null
            },
            address: {
                streetLines: Array<string>
                city: string | null,
                stateOrProvinceCode: string | null,
                postalCode: string | null,
                countryCode: string | null,
                residential: boolean
            }
    };
    isManaged: boolean;
        defaultAccount: {
            value: string | null,
            key: string
    };
        customer: {
            cashOnly: boolean,
            creditCardUpdateBlocked: boolean,
            ukdomesticAllowed: boolean
    };
    expandedAccounts: Array<FedexAccounts>;
        siteWideProfile: {
            companyAdmin: boolean,
            departmentAdmin: boolean
    };
        }

export interface AssociatedAccRequest {
    accountNumber: AcckeyValue;
}

export interface AcckeyValue {
    key: string;
    value: string | null;
}

export interface AssociatedAccounts {
    accountNumber: string;
    companyIdentifier: string;
    displayName: string;
}

export interface FedexAccounts {
    account: {
        accountNumber: AcckeyValue,
        accountNickname: string,
        accountDisplayName: string
    };
}

export interface AssociatedAccResponse {
    output: {
    associatedAccounts: Array<AssociatedAccounts>
    };
  }

export interface UserAccounts {
    accounts: {
        defaultAccount: AssociatedAccRequest,
        expandedAccounts: Array<AssociatedAccRequest>
    };
    }

export interface UserAccDetails {
    cusAccNm: string;
    cusAccId: string;
    accTyp: string;
    ctryCd: string;
    defAcc: boolean;
}
