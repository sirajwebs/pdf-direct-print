/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved *copyright* FedEx 2018
 *
 * Typescript code in this page
 */
import { Packages } from './template.models';

export interface BookingDTO {
    prDesc: string;
    prId: string;
    pyr: string;
    sCnf: string;
    tNm: string;
    tId: number;
    bId: number;
    cAccNo: number;
    bSidNo: string;
    cnRNm: Array<string>;
    cRNm: string;
    dDt: string;
    gDsc: string;
    insC: string;
    insV?: number;
    invcC: string;
    invcV: number;
    pDt: string;
    pkgs: Array<Packages>;
    adr: Array<BookingAddressDTO>;
    prType: string;
    docs?: Array<Document>;
    pref: BookingPreferenceDTO;
    estPs: number;
    wDys: number;
    sSidRef: boolean;
    cRFg: boolean;
    cnRFg: boolean;
    tmZnId: string;
}

export interface BookingAddressDTO {
    id: number;
    tId: number;
    cNme: string;
    cd: string;
    l1: string;
    l2?: string;
    cty: string;
    pCd: string;
    cntry: string;
    tel: string;
    e: string;
    cPsn?: string;
    pIn?: string;
    typ: string;
}

export interface AddressDTO {
    cNme: string;
    cPsn: string;
    cd: string;
    cntry: string;
    cty: string;
    e: string;
    l1: string;
    l2: string;
    pCd: string;
    pIn: string;
    tel: string;
}
export interface Document {
    fn: string;
}

export interface BookingPreferenceDTO {
    pfClStTm?: string;
    pfClEnTm?: string;
    alClStTm?: string;
    alClEnTm?: string;
}

export interface PickupDTO {
    uDt: string;
    lat: number;
    lng: number;
    svcId: string;
    pTyp: string;
    sAdr: ADR;
    dAdr: ADR;
    cutOffTm: string;
    dptOpenTm: string;
    dptCloseTm: string;
}

export interface DueDateDTO {
    uDt: string;
    cTm: string;
    lat: number;
    lng: number;
    svcId: string;
    pTyp: string;
    sAdr: ADR;
    dAdr: ADR;
}

export interface ADR {
    cnr: string;
    twn: string;
    po: number;
}

export interface ColnTimeInitDTO {
    cutOffTm: string;
    dptOpenTm: string;
    dptCloseTm: string;
}

export interface DateTime {
    DATE: string;
    TIME: string;
}

export interface ColnTime {
    MRNG: Array<string>;
    AFTRN: Array<string>;
}

export interface ColnTimeInputsDTO {
    MRNG: {
        FROM: Array<string>;
        TO: Array<string>;
    };
    AFTRN: {
        FROM: Array<string>;
        TO: Array<string>;
    }
}

export interface EdiUserDtlsDTO {
    userName: string;
    email: string;
    country: string;
}
