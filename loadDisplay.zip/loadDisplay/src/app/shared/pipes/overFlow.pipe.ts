/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved *copyright* FedEx 2018
 *
 * Typescript code in this page
 */
import { PipeTransform, Pipe } from '@angular/core';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';

@Pipe({ name: 'overFlow' })
export class OverFlowPipe implements PipeTransform {
    constructor(public sanitizer: DomSanitizer) {
    }
    transform(text: string, txtLength: number): SafeHtml {
        if (text.length > txtLength) {
            const modifiedText = text.substring(0, txtLength) + '...';
            return modifiedText;
        } else {
            return text;
        }
    }
}
