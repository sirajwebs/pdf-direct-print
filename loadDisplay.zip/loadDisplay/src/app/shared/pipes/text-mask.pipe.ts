/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved *copyright* FedEx 2018
 *
 * Typescript code in this page
 */
import { Pipe, PipeTransform } from '@angular/core';
import { FedexTNT } from './../constants/constants-var'; // required when fedex and TNT accounts integration is completed
import { NUMBERS, ConstantsVAR } from 'app/shared/constants/constants-var'; // required when fedex and TNT accounts integration is completed
import { UserAccDetails } from './../models/login.models'; // required when fedex and TNT accounts integration is completed
@Pipe({
  name: 'textMask'
})
export class TextMaskPipe implements PipeTransform {
  transform(value: string, visibleDigits: number = 4): string {
    if (value) {
      const maskedSection = value.toString().slice(0, -visibleDigits);
      const visibleSection = value.toString().slice(-visibleDigits);
      return maskedSection.replace(/./g, '*') + visibleSection;
    }
  }

  /* required when fedex and TNT accounts integration is completed */
  /*transform(userAcc: UserAccDetails): string { //TODO: work in progress
    if (userAcc) {
     return (userAcc.accTyp === FedexTNT.FDX) ? this.maskFedexAcc(userAcc.usrAccNm) : this.maskTNTAcc(userAcc.usrAccId, userAcc.usrAccNm);
    }
  }

  maskTNTAcc(accountID: string, accountName: string ): string { //TODO: work in progress
    /**
     *
     *
    const accID = accountID.slice(0, -NUMBERS.FOUR).replace(/./g, '*');
    const masked = accID + accountID.slice(-NUMBERS.FOUR, accountID.length);
    return accountName + ConstantsVAR.SNGLE_SPC_STR + masked
  }

  maskFedexAcc(value: string ): string { //TODO: work in progress
    /**
     *
     *
    const fedxMask = value.toString().split('-');
    return fedxMask[0] + FedexTNT.FDX_MASK + fedxMask[1];
  }*/
}
