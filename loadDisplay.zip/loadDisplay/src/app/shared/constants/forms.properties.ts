/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved (c) Fedex 2018
 *
 * Typescript code in this page
 */

export const FORMS = {
    PLACEHOLDER: ' ',
    SENDER_OPTIONS: {
        ADDR_ADJUST: {
            DEFAULT: 'true',
        },
        PCKS_ADJUST: {
            DEFAULT: 'true'
        },
        SHOW_SRVC: {
            DEFAULT: 'false'
        },
        COLLECTION: {
            MAX: 5,
            DEFAULT: 5
        }
    },
    ADDRESS: {
        COMPANY: {
            MAXLENGTH: 40,
            PATTERN: ''
        },
        ADDR_LINE1: {
            MAXLENGTH: 30,
            PATTERN: ''
        },
        ADDR_LINE2: {
            MAXLENGTH: 30,
            PATTERN: ''
        },
        COUNTRY: {
            MAXLENGTH: 70,
            PATTERN: '[a-zA-Z ]+'
        },
        COUNTRY_CODE: {
            MAXLENGTH: 3,
            PATTERN: ''
        },
        POSTAL: {
            MAXLENGTH: 9,
            PATTERN: '[a-zA-Z0-9 -]*'
        },
        CITY: {
            MAXLENGTH: 30,
            PATTERN: ''
        },
        PHONE: {
            MAXLENGTH: 16,
            PATTERN: '^([+]{1})*([0-9]){5,16}$',
            PATTERN_HTML: '[0-9 +]*'
        },
        EMAIL: {
            MAXLENGTH: 50,
            PATTERN: ''
        },
        CONTACT_PERSON: {
            MAXLENGTH: 30,
            PATTERN: '[a-zA-Z ]+'
        },
        INSTRUCTION: {
            MAXLENGTH: 50,
            PATTERN: ''
        },
        VAT: {
            MAXLENGTH: 18,
            PATTERN: '^[a-zA-Z0-9\/-]+$'
        },
        TYPE: {
            COLLECTION: {
                ACTIVE: true,
                ID: 'P'
            },
            SENDER: {
                ACTIVE: true,
                ID: 'S'
            },
            DELIVERY: {
                ACTIVE: true,
                ID: 'D'
            },
            RECEIVER: {
                ACTIVE: true,
                ID: 'R'
            },
        }
    },
    SAVEADDRESS: {
        NICK_NAME_MAXLENGTH: 35
    },
    TEMPLATE: {
        CUST_ACC: {
            DEFAULT: '',
            REQUIRED: true,
            PATTERN: '', // to be defined
        },
        TEMPLT_NAME: {
            DEFAULT: '',
            REQUIRED: true,
            PATTERN: '[a-zA-Z0-9_ ]+',
            MAXLENGTH: 50
        },
        PAYSBY: {
            RECEIVER: 'R',
            SENDER: 'S',
            THIRDPARTY: 'T',
            DEFAULT: 'R',
        },
        SHOW_BKNG_REF: {
            DEFAULT: true,
        },
        SHOW_CUST_REF: {
            DEFAULT: true,
        },
        SHOW_PRICING: {
            DEFAULT: true,
        },
        GENERATE_BKNG_REF: {
            DEFAULT: true,
        },
        COPY_BKNG2CUST_REF: {
            DEFAULT: true,
        },
        SHIP_CONFIRM_BY: {
            RECEIVER: 'R',
            SENDER: 'S',
            DEFAULT: 'S'
        },
        DUPL_TEM: {
            DEFAULT: '',
            REQUIRED: true,
            PATTERN: '[a-zA-Z0-9_ ]+',
            MAXLENGTH: 50
        }
    },
    PACKAGE: {
        MAX: 20,
        DEFAULT_UNITS: 'M',
        MEASUREMENT_UNITS: [{
            TYPE: 'M',
            NAME: 'kg/cm',
            LENGTH: 'cm',
            SUP_LENGTH: 'm',
            WEIGHT: 'kg'
        },
        {
            TYPE: 'I',
            NAME: 'lb/in',
            LENGTH: 'in',
            SUP_LENGTH: 'ft',
            WEIGHT: 'lb'
        }],
        WEIGHT: {
            MIN: 0.10,
            MAX: 1000,
            MAXLENGTH: 4,
            PATTERN: '^(\\d*\\.)?\\d+$'
        },
        LENGTH: {
            MIN: 1,
            MAX: 999,
            MAXLENGTH: 3,
            PATTERN: '[1-9]\\d*'
        },
        WIDTH: {
            MIN: 1,
            MAX: 999,
            MAXLENGTH: 3,
            PATTERN: '[1-9]\\d*'
        },
        HEIGHT: {
            MIN: 1,
            MAX: 999,
            MAXLENGTH: 3,
            PATTERN: '[1-9]\\d*'
        },
        QUANTITY: {
            MIN: 1,
            MAX: 99,
            DEFAULT: 1
        },
        TYPE: {
            PALLET: {
                ID: 1  // DO NOT CHANGE
            },
            BOX: {
                ID: 2 // DO NOT CHANGE
            },
            ENVELOPE: {
                ID: 3 // DO NOT CHANGE
            },
            CUSTOM: {
                ID: 4 // DO NOT CHANGE
            },
            DEFAULT: {
                TNT: 2,
                FEDEX: 4
            }
        },
        ENVELOPE: {
            GOODS: 'Goods (non documents)',
            DOCS: 'Documents (paper only)'
        },
        PRODUCT_TYPE: {
            DOC: 'D',
            NON_DOC: 'N'
        }
    },

    INSURANCE: {
        GOOD_DESC: {
            DEFAULT: '',
            REQUIRED: true,
            MAXLENGTH: '30'
        },
        INVC_VAL: {
            DEFAULT: '',
            REQUIRED: true,
            MAXLENGTH: 7,
            MIN: 0.10,
            MAX: 9999999
        },
        INVC_CURR: {
            DEFAULT: 'EUR',
            ALL: ['EUR']
        },
        INSRNC_VAL: {
            DEFAULT: '',
            MAXLENGTH: 5,
            MIN: 0.10,
            MAX: 25000,
            MAX_PERCENTAGE: 110 / 100, // 100 is the divident to calculate percentage in decimal
            PERCENT: 110
        },
        INSRNC_CURR: {
            DEFAULT: 'EUR',
            ALL: ['EUR']
        },
        UPLOAD_INVC_TEXT: {
            DEFAULT: ''
        },
        BROWSE_FILE: {
            DEFAULT: ''
        }
    }

};
