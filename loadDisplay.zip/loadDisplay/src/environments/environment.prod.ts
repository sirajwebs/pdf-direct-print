// The file contents for the current environment will overwrite these during build.
// The build system defaults to the dev environment which uses `environment.ts`, but if you do
// `ng build --env=prod` then `environment.prod.ts` will be used instead.
// The list of which env maps to which file can be found in `.angular-cli.json`.

/**
 * PROD ENVIRONMENT : L6
 */
export const environment = {
  production: true,
  URL: 'https://api.emea.fedex.com/',
  TNT_URL: 'https://api.emea.fedex.com/digital/',
  SPIRIT_TOKEN_URL: 'https://api.emea.fedex.com/',
  FDX_TOKEN_URL: 'https://api.fedex.com/',
  CONST_LOGIN: 'https://api.fedex.com',
  CONST_AUTH_TOKEN_CLIENT_ID: '28b0b32c-9a6c-464d-8531-4fd7b3d8d3e1',
  CONST_AUTH_TOKEN_CLIENT_SECRET: 'e61fd16e-8468-4268-bded-1f66521bbbc2',
  CONST_FDX_AUTH_TOKEN_CLIENT_ID: 'L7xxd303f7141cbf47e2a01b6eb46691be15',
  CONST_FDX_AUTH_TOKEN_CLIENT_SECRET: '72f965dda9874c67a9ee2ac9b550c3df',
  GOOGLE_CHANNEL_ID: 'spirit',
};
