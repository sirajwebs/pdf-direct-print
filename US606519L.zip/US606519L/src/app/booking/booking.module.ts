/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved *copyright* FedEx 2018
 *
 * Typescript code in this page
 */

import { CommonSharedModule } from './../shared/shared.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BookingComponent } from './booking.component';
import { BookingDashBoardComponent } from './booking-dashboard/booking-dashboard.component';
import { DashboardDataComponent } from './booking-dashboard/dashboard-data/dashboard-data.component';
import { BookingRouting } from './booking.route';
import { TemplateDashboardComponent } from './template-dashboard/template-dashboard.component';
import { WizardComponent } from './wizard/wizard.component';
import { SenderOptionsComponent } from './create-template/sender-options/sender-option.component';
import { EnableServiceComponent } from './create-template/enable-service/enable-service.component';
import { CreateTemplateComponent } from './create-template/create-template.component';
import { NewbookingComponent } from './newbooking/newbooking.component';
import { AngularMaterialModule } from '../angular-material.module';
import { MultipleBookingsComponent } from './multiple-bookings/multiple-bookings.component';
import { ProductsOfferedComponent } from './newbooking/products-offered/products-offered.component';
import { CollectionTimeComponent } from './newbooking/products-offered/collection-time/collection-time.component';
import { BookingOptionsComponent } from './create-template/booking-options/booking-options.component';
import { BookingExpirationComponent } from './newbooking/booking-expiration/booking-expiration.component';
import { ReminderEmailComponent } from './newbooking/reminder-email/reminder-email.component';
import { MessageToSenderComponent } from './newbooking/message-to-sender/message-to-sender.component';
import { GeneralSectionComponent } from './create-template/general-section/general-section.component';


@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    CommonSharedModule,
    BookingRouting,
    AngularMaterialModule
  ],
  declarations: [
    BookingComponent,
    TemplateDashboardComponent,
    BookingDashBoardComponent,
    DashboardDataComponent,
    WizardComponent,
    SenderOptionsComponent,
    EnableServiceComponent,
    CreateTemplateComponent,
    NewbookingComponent,
    MultipleBookingsComponent,
    ProductsOfferedComponent,
    CollectionTimeComponent,
    BookingOptionsComponent,
    BookingExpirationComponent,
    ReminderEmailComponent,
    MessageToSenderComponent,
    BookingExpirationComponent,
    GeneralSectionComponent
  ]
})
export class BookingModule { }
