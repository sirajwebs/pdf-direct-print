/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved *copyright* FedEx 2018
 *
 * Typescript code in this page
 */

import { MultipleBookingsComponent } from './multiple-bookings/multiple-bookings.component';
import { RouterGuardService } from './../services/router-guard.service';
import { CreateTemplateComponent } from './create-template/create-template.component';
import { WizardComponent } from './wizard/wizard.component';
import { BookingDashBoardComponent } from './booking-dashboard/booking-dashboard.component';
import { RouterModule, Routes } from '@angular/router';
import { BookingComponent } from './booking.component';
import { TemplateDashboardComponent } from './template-dashboard/template-dashboard.component';
import { NewbookingComponent } from './newbooking/newbooking.component';

export const bookingRoutes: Routes = [
    {
        path: 'booking',
        component: BookingComponent,
        children: [
            {
                path: '', redirectTo: 'dashboard', pathMatch: 'full'
            },
            {
                path: 'templatelist', component: TemplateDashboardComponent, canActivate: [RouterGuardService]
            },
            {
                path: 'dashboard', component: BookingDashBoardComponent, canActivate: [RouterGuardService]
            },
            {
                path: 'wizard', component: WizardComponent, canActivate: [RouterGuardService]
            },
            {
                path: 'multiple-bookings', component: MultipleBookingsComponent, canActivate: [RouterGuardService]
            },
            {
                path: 'create-template', component: CreateTemplateComponent, canActivate: [RouterGuardService]
            },
            {
                path: 'complete-booking', component: NewbookingComponent, canActivate: [RouterGuardService]
            }
        ]
    }
];

export const BookingRouting = RouterModule.forChild(bookingRoutes);

export class RouteView { }
