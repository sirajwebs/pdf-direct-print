/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved *copyright* FedEx 2018
 *
 * Typescript code in this page
 */
import { SharedataService } from '../../services/sharedata.service';
import { CalltokenComponent } from '../../shared/calltoken/calltoken.component';
import { BookingService } from '../../services/booking.service';
import { ConstantsVAR } from '../../shared/constants/constants-var';
import { Component, OnInit, ViewChild, OnDestroy, HostListener, AfterViewInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Subscription } from 'rxjs/Subscription';
import { EdiUserDtlsDTO } from './../../shared/models/bookings.models';

@Component({
  selector: 'app-multiple-bookings',
  templateUrl: './multiple-bookings.component.html',
  styleUrls: ['./multiple-bookings.component.css']
})
export class MultipleBookingsComponent implements OnInit, OnDestroy, AfterViewInit {

  paramVal_FILE_ID = '';
  CANCEL_DWLD_MODAL = 'cancelDwnldModal';
  paramVal_FILE_NM = '';
  paramVal_USR_NM = '';
  dataHdrIsFixed = false;
  goToTop = false;
  showDetails = false;
  clicked = false;
  idx = 0;
  fileUploadStatus = '';
  fileUploadError = '';
  CLOSE_UPLOAD = 'CLOSE_UPLOAD';
  CloseEdiDwnld = ConstantsVAR.CLOSE_EDI_DWNLD;
  fileError = '';
  upldedBkngsListStatus = '';
  COMPLETED_BKNG_UPLOAD_STS = ConstantsVAR.COMPLETED_BKNG_UPLOAD_STS;
  ERROR_BKNG_UPLOAD_STS = ConstantsVAR.ERROR_BKNG_UPLOAD_STS;
  file = [];
  apiSubscription = [];
  apiCallCount = [];
  fileSizeLimit = ConstantsVAR.BOOKING_UPLOAD_FILESIZE;  // in MB
  fileNameLimit = ConstantsVAR.BOOKING_UPLOAD_FILENAME;  // in characters
  upldedBkngsList = [];
  fileErrorListCount = 0;

  userDetails: EdiUserDtlsDTO; 
  downloadFileStatus = '';
  errorDwnldSts = '';
  subscriptions: Array<Subscription> = [];

  @ViewChild(CalltokenComponent) public _calltoken: CalltokenComponent;
  constructor(private _booking: BookingService,
    private _activatedRouter: ActivatedRoute,
    private _shrdt: SharedataService) { }

  @HostListener('window:scroll', [])
  onWindowScroll() {
    /**
     * fixed dashboard table header when user scrolls after few records
     */
    const number = window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop || 0;
    if (number > ConstantsVAR.MLTPL_BKNGS_PAGE_SCRLL_HGHT) {
      this.dataHdrIsFixed = true;
      this.goToTop = true;
    } else if (this.dataHdrIsFixed && number < ConstantsVAR.MLTPL_BKNGS_PAGE_SCRLL_HGHT) {
      this.dataHdrIsFixed = false;
      this.goToTop = false;
    }
  }

  ngOnInit() {
    document.getElementById('REMOVE_MODAL_BACKDROP').click();
    this.getUsrDetails(); // need to change this function name
  }

  ngAfterViewInit() { }

  ngOnDestroy() {
    try {
      document.getElementById('REMOVE_MODAL_BACKDROP').click();
      document.getElementById(this.CloseEdiDwnld).click();
    } catch (err) { }
    this.subscriptions.forEach((subscription: Subscription) => { subscription.unsubscribe(); });
    Object.keys(this.apiSubscription).forEach(apiName => { this.apiUnsubscribe(apiName); });
  }

  downloadOutputFileFromURL() {
    this.paramVal_FILE_ID = this.urlParam('flId');
    this.paramVal_FILE_NM = this.urlParam('flNm');
    this.paramVal_USR_NM = this.urlParam('usNm');
    if (this.paramVal_FILE_ID) {
      try {
        if (this.paramVal_USR_NM.trim().toLowerCase() === this.userDetails['userName'].trim().toLowerCase()) {
      document.getElementById('dwnld_ediFile_Link').click();
      } else {
        document.getElementById('unauthorized_usr_Link').click();
        this.clearReturnURL();
      }
      } catch (error) { }
    }
  }

  urlParam(paramNm) {
    /**
     * activated route to get param value
     */
    let value = '';
    this.subscriptions.push(this._activatedRouter.queryParams.subscribe(params => {
      const paramValEncoded = params[paramNm] || params[paramNm.toLowerCase()];
      if (paramValEncoded) {
        try { value = atob(paramValEncoded); } catch (error) { }
      }
    }));
    return value;
  }

  goToTopClicked() {
    /**
     * scroll page to top / default view on landing
     */
    window.scrollTo(0, 0);
  }

  getUsrDetails() {
    /**
     * to get the user details from login response
     */
    this.subscriptions.push(this._shrdt.loginDetailsMsg.subscribe((loginDetails) => {
         if (loginDetails['userProfile']) {
          try {
            const uDts = loginDetails['userProfile'].registeredContactAndAddress;
            this.userDetails = {
              userName : uDts.contact.personName.firstName + ' ' + uDts.contact.personName.lastName,
              email    : uDts.contact.emailAddress,
              country  : uDts.address.countryCode
            };
          } catch (err) { }
        }
    }));

    this.downloadOutputFileFromURL();
    this.getUploadedBookings();
  }

  getUploadedBookings() {
    /**
     * get list of uploaded bookings for dashboard
     */

    const apiName = 'getUploadedBookings';
    this.apiUnsubscribe(apiName);

    this.subscriptions.push(this.apiSubscription[apiName] =
      this._booking.getUploadedBookingList(this.userDetails['userName']).subscribe(val => {
        this.upldedBkngsList = val;
        this.apiCallCount[apiName] = 0;
        this.upldedBkngsListStatus = 'SUCCESS';
      }, error => {
        this.upldedBkngsListStatus = 'ERROR';
        this.retryMechanism(error, apiName, '');
      }));
  }

  showActionMenuBtn(i) {
    /**
     * highlight the selected row
     */
    if (this.clicked && this.idx === i) {
      this.clicked = false;
    } 
    this.idx = i;
  }

  checkIsMenu(list) {
    if (list.ediSts.toUpperCase() === this.COMPLETED_BKNG_UPLOAD_STS ||
      list.ediSts.toUpperCase() === this.ERROR_BKNG_UPLOAD_STS) {
      return true;
    } else {
      return false;
    }
  }

  closeActionMenu() {
    this.clicked = false;
  }

  uploadFileEvent(ev) {
    /**
     * upload the selected based on file extensions/name size limit/file size
     */
    this.clearFile('fileUploadAPI');
    const name = ev.target.files[0]['name'], fileReader = new FileReader();
    fileReader.onload = (e) => {
      /**
       * to replace the '&' characters
       */
        let xmlBlob, temp = '', fileAsText = '';
        if (fileReader.result.toString().includes('&amp;')) {
          temp = fileReader.result.toString().split('&amp;').join('&');
          fileAsText = temp.split('&').join('&amp;');
        } else {
          fileAsText = fileReader.result.toString().split('&').join('&amp;');
        }
        xmlBlob = new Blob([fileAsText], { type: 'text/xml' });
        this.file = xmlBlob;
        this.file['name'] = name;
  
        if (this.file['name'].split('.').pop().toLowerCase() === 'xml') {
          this.fileError = '';
          if (((this.file['size']) / (ConstantsVAR.SIZE_CONVERSION_1024 * ConstantsVAR.SIZE_CONVERSION_1024)) <= this.fileSizeLimit) {
            if (this.file['name'].length <= this.fileNameLimit) {
              this.fileUploadAPI(this.userDetails, this.file);
            } else { this.fileError = 'NAME'; }
          } else { this.fileError = 'SIZE'; }
        } else { this.fileError = 'EXTN'; }
        ev.target.value = null;
    };
    fileReader.readAsText(ev.target.files[0]);
  }

  fileUploadAPI(body, file) {
    /**
     * api call to upload the edi file as ip.file
     */
    const fileName = file['name'];
    this.fileUploadStatus = 'CALLING';
    const apiName = 'fileUploadAPI';
    this.apiUnsubscribe(apiName);

    this.subscriptions.push(this.apiSubscription[apiName] = this._booking.uploadBookingFile(body, file, fileName).subscribe(val => {
      this.fileUploadSuccess();
      this.apiCallCount[apiName] = 0;
    }, error => {
      this.fileUploadStatus = 'ERROR';
      if (error.status === ConstantsVAR.API_STATUS_CODE_403) {
        if (error._body) {
          this.fileUploadError = JSON.parse(error._body).message;
        } else if (error.message) {
          this.fileUploadError = error.message;
        }
      } else {
        this.fileUploadError = '';
      }
      if (this.fileUploadError) {
        this.fileErrorListCount = this.fileUploadError.split(';').length - 1;
      } else {
        this.fileErrorListCount = 0;
      }
      const dta = { 'body': body, 'file': file };
      this.retryMechanism(error, apiName, dta);
    }));
  }

  downloadErrorList() {
    if (this.fileErrorListCount) {
      const element = <HTMLAnchorElement>document.getElementById('A_DOWNLOAD');
      let fileText = this.fileUploadError.split(';').join('\r\n');
      fileText = '\r\n' + ' ' + fileText;  // this space and new line is needed
      const blob = new Blob([fileText], { type: 'text/plain' });
      const nm = this.file['name'];
      const name = nm.substring(0, nm.lastIndexOf('.'));
      element.download = '[ERRORS] ' + name + '.txt';
      element.style.display = 'none';
      element.href = window.URL.createObjectURL(blob);
      element.click();
    }
  }

  fileUploadSuccess() {
    /**
     * close modal and show success msg
     */
    this.fileUploadStatus = '';
    setTimeout(() => {
      document.getElementById(this.CLOSE_UPLOAD).click();
      setTimeout(() => {
        this.fileUploadStatus = 'SUCCESS';
        setTimeout(() => {
          this.fileUploadStatus = '';
          this.getUploadedBookings();
        }, ConstantsVAR.MILISEC_4000);
      }, ConstantsVAR.MILISEC_200);
    }, ConstantsVAR.MILISEC_100);
  }

  clearFile(API) {
    /**
     * clear the errors and file event and cancel ongoing API call
     */
    document.getElementById('INSTR').classList.remove('in');
    document.getElementById('instructions-div').classList.add('collapsed');
    this.file = [];
    this.fileError = '';
    this.fileUploadError = '';
    this.fileUploadStatus = '';
    if (this.apiSubscription[API]) { this.apiSubscription[API].unsubscribe(); }
  }

  downloadOutputFile(fileID, menuTYPE, msgFlag) {
    let flNm, fileTYPE = ConstantsVAR.EDI_DOWNLOAD_DEFAULT_FILE_TYPE;

    switch (menuTYPE) {
      case 'UPLD': {
        fileTYPE = ConstantsVAR.EDI_DOWNLOAD_UPLOADED_FILE_TYPE, flNm = '[UPLOADED_FILE] ';
        break;
      }
      case 'RSLT': {
        fileTYPE = ConstantsVAR.EDI_DOWNLOAD_RESULT_FILE_TYPE, flNm = '[RESULT_FILE] ';
        break;
      }
      case 'ERR': {
        fileTYPE = ConstantsVAR.EDI_DOWNLOAD_RESULT_FILE_TYPE, flNm = '[ERROR_FILE] ';
        break;
      }
      default: fileTYPE = ConstantsVAR.EDI_DOWNLOAD_DEFAULT_FILE_TYPE;
    }

    const apiName = 'downloadOutputFile';
    this.apiUnsubscribe(apiName);

    this.subscriptions.push(this.apiSubscription[apiName] = this._booking.getEdiDownloadFile(fileID, fileTYPE).subscribe(val => {
      if (val) {
        this.downloadFile(val, flNm, msgFlag);
      } else {
        this.errorDwldCheck(msgFlag);
      }
      this.apiCallCount[apiName] = 0;
    }, error => {
      this.errorDwldCheck(msgFlag);
      const dta = { 'fileID': fileID, 'fileTYPE': fileTYPE, 'msgFlag': msgFlag };
      this.retryMechanism(error, apiName, dta);
    }));
  }

  errorDwldCheck(msgFlag) {
    if (msgFlag === 'MENU') {
      this.downloadFileStatus = 'ERROR';
      setTimeout(() => {
        this.downloadFileStatus = '';
      }, ConstantsVAR.MILISEC_2500);
    } else if (msgFlag === 'EMAIL') {
      this.errorDwnldSts = 'ERROR';
    }
  }

  downloadFile(file, flNm, msgFlag) {
    try {
      const url = this.base64ToBLOB(file.fileData, 'text/plain');
      const a = <HTMLAnchorElement>document.getElementById('A_DOWNLOAD');
      a.style.display = 'none';
      a.href = url;
      a.download = flNm + file.fileName;
      a.click();

      if (msgFlag === 'MENU') {
        this.downloadFileStatus = 'SUCCESS';
      } else if (msgFlag === 'EMAIL') {
        this.errorDwnldSts = 'SUCCESS';
        document.getElementById(this.CANCEL_DWLD_MODAL).click();
      }
    } catch (error) {
      this.errorDwldCheck(msgFlag);
    }
  }

  clearReturnURL() {
    try {
      sessionStorage.removeItem('returnEdiURL');
      const url2 = window.location.href.split('?')[0];
      window.location.href = url2;
    } catch (err) { }
  }

  base64ToBLOB(b64Data, contentType1) {
    /**
     * this fuctions convert the base54 encode to the blob url
     */

    const b64toBlob = (b64Data1, contentType = contentType1, sliceSize = 512) => {
      let byteCharacters = atob(b64Data1);
      if (byteCharacters.toString().includes('&amp;')) {
        byteCharacters = byteCharacters.toString().split('&amp;').join('&');
      }
      const byteArrays = [];
      for (let offset = 0; offset < byteCharacters.length; offset += sliceSize) {
        const slice = byteCharacters.slice(offset, offset + sliceSize);
        const byteNumbers = new Array(slice.length);
        for (let i = 0; i < slice.length; i++) {
          byteNumbers[i] = slice.charCodeAt(i);
        }
        const byteArray = new Uint8Array(byteNumbers);
        byteArrays.push(byteArray);
      }
      const blob = new Blob(byteArrays, { type: contentType });
      return blob;
    };
    /**
     * call the function to convert the base64 and create the blob url
     */
    const blob1 = b64toBlob(b64Data, contentType1);
    const blobUrl = URL.createObjectURL(blob1);
    return blobUrl;
  }

  apiUnsubscribe(apiName) {
    if (this.apiSubscription[apiName]) { this.apiSubscription[apiName].unsubscribe(); }
  }

  retryMechanism(error, apiName, params, noBaseAPI?) {
    this.apiCallCount[apiName] = this.apiCallCount[apiName] || 1;
    this.apiCallCount[apiName]++;
    if (this._calltoken) {
      if (!noBaseAPI) { this._calltoken.callBaseService(error); }
      if (this.apiCallCount[apiName] <= ConstantsVAR.API_MAX_TRY) {
        this._calltoken.retryServiceCall(error, apiName, params);
      } else {
        this.apiCallCount[apiName] = 0;
      }
    }
  }

  retryCall(data) {
    /**
     * retry service call when idle or service glitches
     */
    switch (data.apiName) {
      case 'fileUploadAPI': this.fileUploadAPI(data.data.body, data.data.file); break;
      case 'getUploadedBookings': this.getUploadedBookings(); break;
      case 'downloadOutputFile': this.downloadOutputFile(data.data.fileID, data.data.fileTYPE, data.data.msgFlag);
        break;
      default:
    }
  }

}
