/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved *copyright* FedEx 2018
 *
 * Typescript code in this page
 */
import { CalltokenComponent } from './../../../shared/calltoken/calltoken.component';
import { TemplateService } from 'app/services/template.service';
import { Subscription } from 'rxjs/Subscription';
import { Component, OnInit, ViewChild, EventEmitter, Output, OnDestroy, Input, OnChanges, SimpleChanges } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ConstantsVAR } from './../../../shared/constants/constants-var';
import { SharedataService } from 'app/services/sharedata.service';

@Component({
  selector: 'app-enable-service',
  templateUrl: './enable-service.component.html',
  styleUrls: ['./enable-service.component.css'],
  providers: [TemplateService]
})
export class EnableServiceComponent implements OnInit, OnDestroy, OnChanges {
  @ViewChild(CalltokenComponent) public _calltoken: CalltokenComponent;

  @Output() public enableServiceData = new EventEmitter<object>();
  @Output() public serviceValueChange = new EventEmitter<boolean>();
  subscriptions: Array<Subscription> = [];

  @Input() public setSrvcDataFlag;
  @Input() public setSrvcDetails;

  servicesList = [];
  defaultServiceFilterList = [];
  serverError = null;
  selectServiceError = false;
  serviceForm = new FormGroup({});
  apiCallCount = [];
  apiSubscription = [];
  constructor(private _template: TemplateService, private _shrdt: SharedataService) { }

  ngOnInit() {
    this.serviceListFetch();
  }

  serviceListFetch() {
    /**
     * Fetch list of services from API
     */

    this.serviceForm.addControl('temp', new FormControl('', Validators.required));
    this.serviceForm.addControl('defaultService', new FormControl('1', Validators.required));

    const apiName = 'serviceListFetch';
    this.apiUnsubscribe(apiName);

    this.subscriptions.push(this.apiSubscription[apiName] = this._template.getServiceListDrpdwn().subscribe(data => {
      this.servicesList = this.sortServices(data);
      this.formCreator();
      this.enableDefaultService('INIT');
      this.servicesBody();
      this.serverError = false;
      this.apiCallCount[apiName] = 0;
    }, error => {
      this.serverError = true;
      this.retryMechanism(error, apiName, '');
    }));
  }



  ngOnChanges(changes: SimpleChanges) {
    this.serviceDataChange();
  }

  serviceDataChange() {
    if (this.setSrvcDetails && this.setSrvcDataFlag) {
      if (this.setSrvcDetails && this.servicesList) {
        this.defaultServiceFilterList = [];
        for (let i = 0; i < this.setSrvcDetails.length; i++) {
          this.filterDefaultService(i);
          if (i === this.setSrvcDetails.length - 1) {
            this.defaultServiceFilterList = this.sortServices(this.defaultServiceFilterList);
          }
        }
      }
    }
    this.servicesBody();
  }

  filterDefaultService(i) {
          for (let k = 0; k < this.servicesList.length; k++) {
            if (this.setSrvcDetails[i].id === this.servicesList[k].serviceId) {
              if (this.setSrvcDetails[i].e === true && (this.setSrvcDetails[i].id === this.servicesList[k].serviceId)) {
                this.serviceForm.get('service' + this.servicesList[k].serviceId).setValue('Y');
                this.defaultServiceFilterList.push(this.servicesList[k]);
              } else if (this.setSrvcDetails[i].e === false && (this.setSrvcDetails[i].id === this.servicesList[k].serviceId)) {
                this.serviceForm.get('service' + this.servicesList[k].serviceId).setValue('N');
              }
              if (this.setSrvcDetails[i].d) {
                this.serviceForm.get('defaultService').setValue(this.setSrvcDetails[i].id);
              }
            }
          }
  }


  sortServices(data) {
    let srvcs = [];
    srvcs = data.sort(function (a, b) {
      return (a.serviceName > b.serviceName) ? 1 : ((b.serviceName > a.serviceName) ? -1 : 0);
    });
    return srvcs;
  }

  formCreator() {
    /**
     * remove and create new form based on service and implement service list in dropdown.
     */
    this.serviceForm.removeControl('temp');
    this.serviceForm.removeControl('defaultService');
    const serviceFormTemp: FormGroup = new FormGroup({});

    if (this.servicesList) {
      for (let i = 0; i < this.servicesList.length; i++) {
        const control: FormControl = new FormControl('Y');
        serviceFormTemp.addControl('service' + this.servicesList[i].serviceId, control);
      }
    }
    serviceFormTemp.addControl('defaultService', new FormControl('1', Validators.required));
    this.serviceForm = serviceFormTemp;

    this.subscriptions.push(this.serviceForm.valueChanges.subscribe(formData => {
      const cntrlKeys = Object.keys(this.serviceForm.controls)
      cntrlKeys.forEach(key => {
        if (this.serviceForm.get(key).dirty) {
          this.serviceValueChange.emit(true);
        }
      });

      const cntrlValArr = [];
      for (let ind = 0; ind < this.servicesList.length; ind++) {
        if (cntrlKeys[ind] !== 'defaultService') {
          cntrlValArr.push(this.serviceForm.get(cntrlKeys[ind]).value);
        }
        if (ind === (this.servicesList.length - 1)) {
          if (cntrlValArr.indexOf('Y') > -1) {
            this.selectServiceError = false;
          } else {
            this.selectServiceError = true;
          }
        }
      }
      this.servicesBody();
    }));
    this.serviceDataChange();
  }

  ngOnDestroy() {
    this.subscriptions.forEach((subscription: Subscription) => { subscription.unsubscribe(); });
    Object.keys(this.apiSubscription).forEach(apiName => { this.apiUnsubscribe(apiName); });
  }

  enableDefaultService(flag?) {
    if (this.servicesList) {
      const defaultServiceFilter = this.defaultService();
      this.defaultServiceFilterList = defaultServiceFilter;
      this.setDefaultService(defaultServiceFilter, flag);

      if (this.defaultServiceFilterList) {
        if (this.defaultServiceFilterList.length < 1) {
          this.serviceForm.get('defaultService').setValue(null);
        }
      } else {
        this.serviceForm.get('defaultService').setValue(null);
      }
    }
  }

  defaultService() {
    let defaultServiceFilter = [];
      for (let i = 0; i < this.servicesList.length; i++) {
        const serviceName = 'service' + this.servicesList[i].serviceId;
        if (this.serviceForm.get(serviceName).value === 'Y') {
          defaultServiceFilter.push(this.servicesList[i]);
        } else if (!defaultServiceFilter) {
          this.serviceForm.get('defaultService').setValue(null);
        }
        if (i === this.servicesList.length - 1) {
          defaultServiceFilter = this.sortServices(defaultServiceFilter);
        }
      }
    return defaultServiceFilter;
  }

  setDefaultService(defaultServiceFilter, flag) {
      if (defaultServiceFilter) {
        if (defaultServiceFilter.length > 0) {
          if (flag === 'INIT') {
            this.setExpressOnDefault(defaultServiceFilter);
          } else {
            const selctd = +this.serviceForm.get('defaultService').value;
            const slctdTmp = defaultServiceFilter.filter((el) => {
              return (el.serviceId === selctd);
            });
            if (slctdTmp.length) {
              this.serviceForm.get('defaultService').setValue(selctd);
            } else {
              this.serviceForm.get('defaultService').setValue(defaultServiceFilter[0].serviceId);
        }
      }
      }
    }
  }

  setExpressOnDefault(data) {
    /**
     * Conditional - Set Express Service as default one
     */
    const ExpressID = data.filter((el) => {
      return (el.serviceName === 'Express')
    });
    try {
      this.serviceForm.get('defaultService').setValue(ExpressID[0].serviceId);
    } catch (err) { }
  }

  servicesBody() {
    /**
     * get list of available services and set service body
     */
    const serviceBody = [];
    let isDefault = false;
    if (this.servicesList) {
      for (let i = 0; i < this.servicesList.length; i++) {
        const serviceName = 'service' + this.servicesList[i].serviceId;
        if (this.serviceForm.get(serviceName).value === 'Y') {
          if (+(this.serviceForm.get('defaultService').value) === this.servicesList[i].serviceId) {
            isDefault = true;
          } else {
            isDefault = false;
          }
          serviceBody.push(
            {
              'id': this.servicesList[i].serviceId,
              'e': true,
              'd': isDefault
            });
        } else {
          serviceBody.push(
            {
              'id': this.servicesList[i].serviceId,
              'e': false,
              'd': false
            });
        }
      }
    }
    this.enableServiceData.emit(serviceBody);
  }


  formValidation() {
    /**
     * Form Validation for service section
     */
    if (this.serviceForm.invalid) {
      Object.keys(this.serviceForm.controls).forEach(key => {
        if (this.serviceForm.get(key).invalid) {
          this.serviceForm.get(key).markAsTouched();
        }
      });
      return false;
    } else {
      return true;
    }
  }


  isFieldRequired(field) {
    return (this.serviceForm.get(field).touched && this.serviceForm.get(field).invalid);
  }

  apiUnsubscribe(apiName) {
    if (this.apiSubscription[apiName]) { this.apiSubscription[apiName].unsubscribe(); }
  }

  retryMechanism(error, apiName, params, noBaseAPI?) {
    this.apiCallCount[apiName] = this.apiCallCount[apiName] || 1;
    this.apiCallCount[apiName]++;
    if (this._calltoken) {
      if (!noBaseAPI) { this._calltoken.callBaseService(error); }
      if (this.apiCallCount[apiName] <= ConstantsVAR.API_MAX_TRY) {
        this._calltoken.retryServiceCall(error, apiName, params);
      } else {
        this.apiCallCount[apiName] = 0;
      }
    }
  }

  retryCall(data) {
    if (data.apiName === 'serviceListFetch') {
      this.serviceListFetch();
    }
  }
}
