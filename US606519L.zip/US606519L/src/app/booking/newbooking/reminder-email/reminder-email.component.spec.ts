import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReminderEmailComponent } from './reminder-email.component';

describe('ReminderEmailComponent', () => {
  let component: ReminderEmailComponent;
  let fixture: ComponentFixture<ReminderEmailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReminderEmailComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReminderEmailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
