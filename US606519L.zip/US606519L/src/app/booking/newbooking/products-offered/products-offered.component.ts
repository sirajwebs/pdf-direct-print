/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved *copyright* FedEx 2018
 *
 * Typescript code in this page
 */

import { Component, OnInit, Output, EventEmitter, Input, ViewChild } from '@angular/core';
import { ColnTimeInitDTO, BookingPreferenceDTO } from 'app/shared/models/bookings.models';
import { CollectionTimeComponent } from './collection-time/collection-time.component';

@Component({
  selector: 'app-products-offered',
  templateUrl: './products-offered.component.html',
  styleUrls: ['../newbooking.component.css']
})
export class ProductsOfferedComponent implements OnInit {

  @Output() public collectionTimeChange = new EventEmitter<BookingPreferenceDTO>();
  @Output() public setColnDtlsSts = new EventEmitter<boolean>();

  @Input() actualCollectionDateTime: string;
  @Input() confirmPickupDate: string;
  @Input() savedPickupDate: string;
  @Input() colnTimeFrmApiInit: ColnTimeInitDTO;
  @Input() bookingType: string;
  @Input() colnTimeBodyInit: BookingPreferenceDTO;
  @Input() getColnDtlsSts: BookingPreferenceDTO;

  @ViewChild(CollectionTimeComponent) public _colnTime: CollectionTimeComponent;

  constructor() { }

  ngOnInit() {  }

  collectionTimeChangeFrwrd(ev) {
    this.collectionTimeChange.emit(ev);
  }

  setColnDtlsStsFrwrd(ev) {
    this.setColnDtlsSts.emit(ev);
  }
}
