/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved *copyright* FedEx 2018
 *
 * Typescript code in this page
 */

import { ColnTimeConstants, ConstantsVAR } from './../../../../shared/constants/constants-var';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Component, OnInit, Output, EventEmitter, OnDestroy, Input, OnChanges, SimpleChanges } from '@angular/core';
import { ColnTimeInitDTO, BookingPreferenceDTO, DateTime, ColnTime, ColnTimeInputsDTO } from 'app/shared/models/bookings.models';
import { Subscription } from 'rxjs/Subscription';
import { SharedFunctionsService } from './../../../../services/shared-functions.service';

@Component({
  selector: 'app-collection-time',
  templateUrl: './collection-time.component.html',
  styleUrls: ['./collection-time.component.css'],
  providers: [SharedFunctionsService]
})
export class CollectionTimeComponent implements OnInit, OnChanges, OnDestroy {

  subscriptions: Array<Subscription> = [];
  @Output() public collectionTimeChange = new EventEmitter<BookingPreferenceDTO>();
  @Output() public setColnDtlsSts = new EventEmitter<boolean>();

  @Input() confirmPickupDate: string;
  @Input() savedPickupDate: string;
  @Input() actualCollectionDateTime: DateTime;
  @Input() colnTimeFrmApiInit: ColnTimeInitDTO;
  @Input() bookingType: string;
  @Input() colnTimeBodyInit: BookingPreferenceDTO;
  @Input() getColnDtlsSts: boolean;

  actualCollectionDateTimeModified: DateTime = {
    DATE: '',
    TIME: ''
  };

  colnTime: ColnTime = {
    MRNG: ColnTimeConstants.COLN_TIME_MRNG,
    AFTRN: ColnTimeConstants.COLN_TIME_AFTRN
  };

  colnTimeInputs: ColnTimeInputsDTO = {
    MRNG: {
      FROM: ColnTimeConstants.COLN_TIME_MRNG,
      TO: ColnTimeConstants.COLN_TIME_MRNG
    },
    AFTRN: {
      FROM: ColnTimeConstants.COLN_TIME_AFTRN,
      TO: ColnTimeConstants.COLN_TIME_AFTRN
    }
  };

  colnTimeInputs_Copy: ColnTimeInputsDTO = JSON.parse(JSON.stringify(this.colnTimeInputs));
  colnTimeFrmApiInit_Copy: ColnTimeInitDTO;

  LocalConstantsVAR = {
    MRNG: 'MRNG',
    AFTRN: 'AFTRN',
    FROM: 'FROM',
    TO: 'TO'
  };
  notAvlble = {
    MRNG: false, // do not change object name
    AFTRN: false, // do not change object name
  };
  savedColnTimesUp = {
    MRNG_OR_AFTRN: false, // do not change object name
    WHOLE_DAY: false, // do not change object name
  };
  colnTimeBody: BookingPreferenceDTO;
  colnTimeInterval = {
    FROM: '',
    TO: ''
  };

  collectionTimeForm = new FormGroup({
    morningFrom: new FormControl(ColnTimeConstants.COLN_TIME_MRNG_FROM_INIT),
    morningTo: new FormControl(ColnTimeConstants.COLN_TIME_MRNG_TO_INIT),
    morningDontCollect: new FormControl(false),
    afternoonFrom: new FormControl(ColnTimeConstants.COLN_TIME_AFTRN_FROM_INIT),
    afternoonTo: new FormControl(ColnTimeConstants.COLN_TIME_AFTRN_TO_INIT),
    afternoonDontCollect: new FormControl(false),
  });

  constructor(private _shrdFn: SharedFunctionsService) {
    Object.freeze(this.LocalConstantsVAR);
    Object.freeze(this.colnTime);
    Object.freeze(this.colnTimeInputs);
    this.subscriptions.push(this.collectionTimeForm.valueChanges.subscribe(formData => {
      this.setBookingPreferenceBody(formData);
    }));
    this.setColnTimeDrpdwnOptns();
  }

  ngOnInit() {
    switch (this.bookingType) {
      case 'VIEW': this.setStaticBookingDetails(this.colnTimeBodyInit); break;
      case 'EDIT': this.setEditBookingDetails(); break;
      default: break;
    }
  }

  ngOnChanges(changes: SimpleChanges) {
    const colnTimeInit: ColnTimeInitDTO = {
      cutOffTm: '',
      dptCloseTm: '',
      dptOpenTm: ''
    };

    if (changes ? changes.colnTimeFrmApiInit : false) {
      this.colnTimeFrmApiInit_Copy = JSON.parse(JSON.stringify(this.colnTimeFrmApiInit ?
        this.colnTimeFrmApiInit : colnTimeInit));
    }

    switch (this.bookingType) {
      case 'VIEW': break;
      default: this.updateCollnValues(changes); break;
    }
  }

  ngOnDestroy() {
    this.subscriptions.forEach((subscription: Subscription) => { subscription.unsubscribe(); });
  }

  updateCollnValues(changes) {
    if (changes.confirmPickupDate || changes.colnTimeFrmApiInit) {
      this.savedColnTimesUp = { MRNG_OR_AFTRN: false, WHOLE_DAY: false };
      this.refreshColnTime();
    }
  }

  setStaticBookingDetails(colnTimeBodyInit) {
    /**
     * to patch value of collection time initial data from booking fetch
     */

    // create the object from the saved data being fetched
    this.colnTimeInputs_Copy = {
      MRNG: {
        FROM: [colnTimeBodyInit.pfClStTm],
        TO: [colnTimeBodyInit.pfClEnTm],
      },
      AFTRN: {
        FROM: [colnTimeBodyInit.alClStTm],
        TO: [colnTimeBodyInit.alClEnTm],
      }
    }
    this.patchInitialValue(colnTimeBodyInit);
    this.enableMorningTime(false);
    this.enableAfternoonTime(false);
  }

  setEditBookingDetails() {
    /**
   * to patch value of collection time initial data from booking fetch
   */

    if (!this.getColnDtlsSts && !this.isDepotTimeNotAvlbl() && !this.isDepotTimeNotInRange()) {
      if (this.savedPickupDate === this.confirmPickupDate) {
        this.patchInitialValue(this.colnTimeBodyInit);
        if (this.isSameDay()) {
          if (this.isColnTimeValidFor('MRNG')) {
            this.isSavedColnTimesUp('morningFrom');
          } else if (this.isColnTimeValidFor('AFTRN')) {
            this.isSavedColnTimesUp('afternoonFrom');
          } else {
            this.refreshColnTime();
            this.savedColnTimesUp.MRNG_OR_AFTRN = true;
          }
        } else {
          this.setSavedColnTimeData();
        }
      } else {
        this.refreshColnTime();
        this.savedColnTimesUp.WHOLE_DAY = true;
      }
      this.setColnDtlsSts.emit(true);
    }
  }

  setSavedColnTimeData() {
    if (!this.morningSavedValuePresent(this.colnTimeBodyInit)) {
      this.patchMorningValueToDefault();
      this.collectionTimeForm.get('morningDontCollect').setValue(true);
      this.enableOrDisableTimeSelction(this.LocalConstantsVAR.MRNG, false);
    }
    if (!this.afternoonSavedValuePresent(this.colnTimeBodyInit)) {
      this.patchAfternoonValueToDefault();
      this.collectionTimeForm.get('afternoonDontCollect').setValue(true);
      this.enableOrDisableTimeSelction(this.LocalConstantsVAR.AFTRN, false);
    }
  }

  patchMorningValueToDefault() {
    /**
     * patch morning value to initial options present
     */
    const from = this.colnTimeInputs_Copy['MRNG']['FROM'],
      to = this.colnTimeInputs_Copy['MRNG']['TO'];

    this.collectionTimeForm.patchValue({
      morningFrom: from[0],
      morningTo: to[to.length - 1]
    });
  }

  patchAfternoonValueToDefault() {
    /**
     * patch afternoon value to initial options present
     */
    const from = this.colnTimeInputs_Copy['AFTRN']['FROM'],
      to = this.colnTimeInputs_Copy['AFTRN']['TO'];

    this.collectionTimeForm.patchValue({
      afternoonFrom: from[0],
      afternoonTo: to[to.length - 1]
    });
  }

  isSavedColnTimesUp(control) {
    /**
     * check for updated time with saved time
     * if the time is over update the collection time
     */
    this.savedColnTimesUp.MRNG_OR_AFTRN = this.hideTimeSlot(this.actualCollectionDateTimeModified['TIME'],
      this.collectionTimeForm.get(control).value, ColnTimeConstants.DEPOT_CLOSE);

    if (this.savedColnTimesUp.MRNG_OR_AFTRN) {
      this.refreshColnTime();
    } else {
      this.setSavedColnTimeData();
    }
  }


  isColnTimeValidFor(mrngOrAftrnFlag) {
    /**
     * check if the morning or afternoon collection time data
     * is present in the object. data are only present 
     * if the time are coming from 
     */
    let isValid;
    switch (mrngOrAftrnFlag) {
      case 'MRNG': isValid = this.collectionTimeForm.get('morningFrom').enabled &&
        this.collectionTimeForm.get('morningFrom').value; break;
      case 'AFTRN': isValid = this.collectionTimeForm.get('afternoonFrom').enabled &&
        this.collectionTimeForm.get('afternoonFrom').value; break;
      default: isValid = false; break;
    }
    return isValid;
  }

  patchInitialValue(data) {
    /**
    * to patch value of collection time initial data from booking fetch
    */
    if (data) {
      this.collectionTimeForm.patchValue({
        morningFrom: this.filterPatchValue(data.pfClStTm, 'MRNG', 'FROM'),
        morningTo: this.filterPatchValue(data.pfClEnTm, 'MRNG', 'TO'),
        afternoonFrom: this.filterPatchValue(data.alClStTm, 'AFTRN', 'FROM'),
        afternoonTo: this.filterPatchValue(data.alClEnTm, 'AFTRN', 'TO'),
      });
    } else {
      this.patchMorningValueToNull();
      this.patchAfternoonValueToNull();
    }
  }

  setColnTimeDrpdwnOptns() {
    /**
     * check for value changes and update the respective object value 
     * to reflect in selectable field options
     */
    this.subscriptions.push(this.collectionTimeForm.get('morningFrom').valueChanges.subscribe(formData => {
      this.updateColnTimeDrpdwnOptns('morningFrom', this.LocalConstantsVAR.MRNG, this.LocalConstantsVAR.TO);
    }));

    this.subscriptions.push(this.collectionTimeForm.get('morningTo').valueChanges.subscribe(formData => {
      this.updateColnTimeDrpdwnOptns('morningTo', this.LocalConstantsVAR.MRNG, this.LocalConstantsVAR.FROM);
    }));

    this.subscriptions.push(this.collectionTimeForm.get('afternoonFrom').valueChanges.subscribe(formData => {
      this.updateColnTimeDrpdwnOptns('afternoonFrom', this.LocalConstantsVAR.AFTRN, this.LocalConstantsVAR.TO);
    }));

    this.subscriptions.push(this.collectionTimeForm.get('afternoonTo').valueChanges.subscribe(formData => {
      this.updateColnTimeDrpdwnOptns('afternoonTo', this.LocalConstantsVAR.AFTRN, this.LocalConstantsVAR.FROM);
    }));
  }

  updateColnTimeDrpdwnOptns(formControl, mrngOrAftrnFlag, toOrFromFlag) {
    /**
     * update the object for options in selectable fields
     */
    if (!this.nonEditableInputsFields()) {
      this.colnTimeInputs_Copy[mrngOrAftrnFlag][toOrFromFlag] = [];
      if (this.collectionTimeForm.get(formControl).enabled) {
        this.colnTimeInputs_Copy[mrngOrAftrnFlag][toOrFromFlag] =
          this.colnTimeInputs[mrngOrAftrnFlag][toOrFromFlag].filter((el) => {
            return this.checkAndShowVisibility(mrngOrAftrnFlag, toOrFromFlag, el);
          });
      }
    }
  }

  refreshColnTime() {
    /**
     * refresh and set collection time based on today or other days
     */

    const colnTimeFrmApiInit_Copy = this.setDataIfDepotTimesNotAvailable();
    let dptOpenTmData, dptCloseTmData;

    if (this.isDepotTimeNotAvlbl() ? true : this.isDepotTimeNotInRange()) {
      this.setDataIfDepotTimeNotInRange(colnTimeFrmApiInit_Copy);
    } else {
      if (this.isSameDay()) {
        const sameDayCurrTm = this.sameDayInitialTmCalculation(
          this.actualCollectionDateTime['TIME'], ColnTimeConstants.MIN_TIME_COLLECT_MINUTES_30);
        dptOpenTmData = this.actualCollectionDateTimeModified['TIME'] =
          this.getTimeInDigit(sameDayCurrTm) > this.getTimeInDigit(this.colnTimeFrmApiInit.dptOpenTm) ?
            sameDayCurrTm : this.colnTimeFrmApiInit.dptOpenTm;
        dptCloseTmData = this.colnTimeFrmApiInit.dptCloseTm;
      } else {
        dptOpenTmData = this.colnTimeFrmApiInit.dptOpenTm;
        dptCloseTmData = this.colnTimeFrmApiInit.dptCloseTm;
      }
      this.convertToWorkingTimings(dptOpenTmData, dptCloseTmData);
    }

  }

  setDataIfDepotTimesNotAvailable() {
    /**
     * no depot timing available
     * this below code required to handle depot "timing with 'OSC error'
     */

    if (this.isDepotTimeNotAvlbl()) {
      const colnTimeInit: ColnTimeInitDTO = {
        cutOffTm: ColnTimeConstants.COLN_TIME_MRNG_FROM_INIT,
        dptOpenTm: ColnTimeConstants.COLN_TIME_MRNG_FROM_INIT,
        dptCloseTm: ColnTimeConstants.COLN_TIME_AFTRN_TO_INIT
      };
      return colnTimeInit;
    } else {
      return this.colnTimeFrmApiInit_Copy;
    }
  }

  isDepotTimeNotAvlbl() {
    const opn = this.getTimeInDigit(this.colnTimeFrmApiInit_Copy.dptOpenTm),
      cls = this.getTimeInDigit(this.colnTimeFrmApiInit_Copy.dptCloseTm),
      ctOf = this.getTimeInDigit(this.colnTimeFrmApiInit_Copy.cutOffTm);

    if (opn === 0 || cls === 0) {
      return true;
    } else if (this.isSameDay ? ctOf === 0 : false) {
      return true;
    } else if (opn >= cls) {
      return true;
    } else {
      return false;
    }
  }

  isSameDay() {
    /**
     * to calculate if the date is the same or not
     */
    if (this.confirmPickupDate && this.actualCollectionDateTime['DATE']) {
      return (this.confirmPickupDate === this.actualCollectionDateTime['DATE']);
    }
  }

  convertToWorkingTimings(dptOpenTmData, dptCloseTmData) {
    /**
     * to set the pickuptime slot avalability and disable the time slot if not available 
     */
    const dptOpenTm_inHrs = this.getHourInDigit(dptOpenTmData),
      mrngEnd = this.getHourInDigit(this.colnTime['MRNG'][this.colnTime['MRNG'].length - 1]),
      dptCloseTm_inHrs = this.getHourInDigit(dptCloseTmData),
      aftrnBegin = this.getHourInDigit(this.colnTime['AFTRN'][0]);

    this.morningDepotTime(dptOpenTmData, dptCloseTmData, dptOpenTm_inHrs, dptCloseTm_inHrs, mrngEnd);
    this.afternoonDepotTime(dptOpenTmData, dptCloseTmData, dptOpenTm_inHrs, dptCloseTm_inHrs, aftrnBegin);
  }

  disableAllFields() {
    this.collectionTimeForm.get('morningDontCollect').setValue(true);
    this.collectionTimeForm.get('afternoonDontCollect').setValue(true);
    this.enableMorningTime(false);
    this.enableAfternoonTime(false);
  }

  morningDepotTime(dptOpenTmData, dptCloseTmData, dptOpenTm_inHrs, dptCloseTm_inHrs, mrngEnd) {
    /**
     * depot time alignment with spirit aplication timings for morning slot
     */
    if (dptOpenTm_inHrs < mrngEnd) {

      const dptOpenTm = this.filterDepotTime(this.LocalConstantsVAR.MRNG, dptOpenTmData, ColnTimeConstants.DEPOT_OPEN);
      const dptCloseTm = this.filterDepotTime(this.LocalConstantsVAR.MRNG, dptCloseTmData, ColnTimeConstants.DEPOT_CLOSE);

      this.collectionTimeForm.patchValue({
        morningFrom: dptOpenTm || ColnTimeConstants.TIME_00,
        morningTo: dptCloseTm_inHrs < mrngEnd ? (dptCloseTm || ColnTimeConstants.TIME_00)
          : ColnTimeConstants.COLN_TIME_MRNG_TO_INIT
      });

      if (this.getHourInDigit(this.collectionTimeForm.get('morningFrom').value) >=
        this.getHourInDigit(this.collectionTimeForm.get('morningTo').value)) {
        this.pickupNotAvlble(this.LocalConstantsVAR.MRNG);
      } else {
        this.collectionTimeForm.get('morningDontCollect').setValue(false);
        this.checkAndUpdateColnTm(this.LocalConstantsVAR.MRNG);
        this.notAvlble[this.LocalConstantsVAR.MRNG] = false;
      }
    } else {
      this.pickupNotAvlble(this.LocalConstantsVAR.MRNG);
    }
  }

  afternoonDepotTime(dptOpenTmData, dptCloseTmData, dptOpenTm_inHrs, dptCloseTm_inHrs, aftrnBegin) {
    /**
     * depot time alignment with spirit aplication timings for afternoon slot
     */

    if (dptCloseTm_inHrs > aftrnBegin) {

      const dptOpenTm = this.filterDepotTime(this.LocalConstantsVAR.AFTRN, dptOpenTmData, ColnTimeConstants.DEPOT_OPEN);
      const dptCloseTm = this.filterDepotTime(this.LocalConstantsVAR.AFTRN, dptCloseTmData, ColnTimeConstants.DEPOT_CLOSE);

      this.collectionTimeForm.patchValue({
        afternoonFrom: dptOpenTm_inHrs >= aftrnBegin ? (dptOpenTm || ColnTimeConstants.TIME_00)
          : ColnTimeConstants.COLN_TIME_AFTRN_FROM_INIT,
        afternoonTo: dptCloseTm || ColnTimeConstants.TIME_00,
      });

      if (this.getHourInDigit(this.collectionTimeForm.get('afternoonFrom').value) >=
        this.getHourInDigit(this.collectionTimeForm.get('afternoonTo').value)) {
        this.pickupNotAvlble(this.LocalConstantsVAR.AFTRN);
      } else {
        this.collectionTimeForm.get('afternoonDontCollect').setValue(false);
        this.checkAndUpdateColnTm(this.LocalConstantsVAR.AFTRN);
        this.notAvlble[this.LocalConstantsVAR.AFTRN] = false;
      }
    } else {
      this.pickupNotAvlble(this.LocalConstantsVAR.AFTRN);
    }
  }

  filterDepotTime(mrngOrAftrnFlag, dptTmData, depotOpnOrCls) {
    /**
     * filter the array to show the timings values in array
     */
    const dptTmArray = this.colnTime[mrngOrAftrnFlag].filter((el) => {
      const hideSlot = this.hideTimeSlot(el, dptTmData, depotOpnOrCls);
      return !hideSlot;
    });
    let time;
    switch (depotOpnOrCls) {
      case ColnTimeConstants.DEPOT_OPEN: { time = dptTmArray[0]; break; }
      case ColnTimeConstants.DEPOT_CLOSE: { time = dptTmArray[dptTmArray.length - 1]; break; }
      default: break;
    }
    return time;
  }

  checkAndUpdateColnTm(mrngOrAftrnFlag) {
    const toggle = (this.collectionTimeForm.get('afternoonDontCollect').value
      && this.collectionTimeForm.get('morningDontCollect').value) ? false : true;
    this.enableOrDisableTimeSelction(mrngOrAftrnFlag, toggle);
  }

  checkAndShowVisibility(mrngOrAftrnFlag, toOrFromFlag, time) {
    /**
     * visibility of the selectable field in collection time options
     * return 'true' to hide the option
     */
    const timeTemp = this.getHourInDigit(time),
      isMrng = (mrngOrAftrnFlag === this.LocalConstantsVAR.MRNG);
    switch (toOrFromFlag) {
      case this.LocalConstantsVAR.FROM: {
        const dptOpenTm = this.isSameDay() ? this.actualCollectionDateTimeModified['TIME'] : this.colnTimeFrmApiInit.dptOpenTm,
          formControl = isMrng ? 'morningTo' : 'afternoonTo',
          timeSlot = timeTemp >= this.getHourInDigit(this.collectionTimeForm.get(formControl).value),
          hideSlot = this.hideTimeSlot(time, dptOpenTm, ColnTimeConstants.DEPOT_OPEN);
        return !(timeSlot || hideSlot);
      }
      case this.LocalConstantsVAR.TO: {
        const dptCloseTm = this.colnTimeFrmApiInit.dptCloseTm,
          formControl = isMrng ? 'morningFrom' : 'afternoonFrom',
          timeSlot = (timeTemp <= this.getHourInDigit(this.collectionTimeForm.get(formControl).value)),
          hideSlot = this.hideTimeSlot(time, dptCloseTm, ColnTimeConstants.DEPOT_CLOSE);
        return !(timeSlot || hideSlot);
      }
    }
  }

  sameDayInitialTmCalculation(time, minTimeToCollect) {
    /**
     * check for minimun of 30 minutes of time gap for same day
     * if time already passed 30 min then take the next hours 
     * increament the hour in that case.
     */
    let hh: number = this.getHourInDigit(time), mm: number = this.getMinutesInDigit(time);
    const addedHrs = Math.floor((mm + minTimeToCollect) / ConstantsVAR.ONE_HOUR_IN_MINUTES);
    if (addedHrs) { hh += addedHrs; }
    mm = (mm + minTimeToCollect) % ConstantsVAR.ONE_HOUR_IN_MINUTES;
    return this._shrdFn.appendZeroToVal(hh) + ':' + this._shrdFn.appendZeroToVal(mm);
  }

  hideTimeSlot(timeVal, timeInit, flag) {
    /**
     * hide the slot if:
     * if depot is open then compare current time with base time else limit time
     */
    switch (flag) {
      case ColnTimeConstants.DEPOT_OPEN: {
        return this.getTimeInDigit(timeVal) < this.getTimeInDigit(timeInit);
      };
      case ColnTimeConstants.DEPOT_CLOSE: {
        return this.getTimeInDigit(timeVal) > this.getTimeInDigit(timeInit);
      };
    }
  }

  pickupNotAvlble(mrngOrAftrnFlag) {
    /**
       * switch between enable or disbale for the collection time selction when
       * collection time is not available for morning /afternoon
    */

    switch (mrngOrAftrnFlag) {
      case this.LocalConstantsVAR.MRNG: {
        this.patchMorningValueToNull();
        this.collectionTimeForm.get('morningDontCollect').setValue(true); break;
      }
      case this.LocalConstantsVAR.AFTRN: {
        this.patchAfternoonValueToNull();
        this.collectionTimeForm.get('afternoonDontCollect').setValue(true); break;
      }
    }
    this.checkAndUpdateColnTm(mrngOrAftrnFlag);
    this.notAvlble[mrngOrAftrnFlag] = true;
  }

  patchMorningValueToNull() {
    /**
     * patch morning value to null/empty
     */
    this.collectionTimeForm.patchValue({
      morningFrom: '',
      morningTo: ''
    });
  }

  patchAfternoonValueToNull() {
    /**
     * patch afternoon value to null/empty
     */
    this.collectionTimeForm.patchValue({
      afternoonFrom: '',
      afternoonTo: ''
    });
  }

  enableCollctChkbx(flag) {
    /**
     * enable or diable "do not collect" checkbox
     */
    const ntAvbl = (this.notAvlble['MRNG'] || this.notAvlble['AFTRN']);
    return flag ? !ntAvbl : ntAvbl;
  }

  enableOrDisableTimeSelction(mrngOrAftrnFlag, toggleBtn) {
    /**
     * switch between enable or disbale for the collection time selction
     */
    switch (mrngOrAftrnFlag) {
      case this.LocalConstantsVAR.MRNG: {
        if (this.collectionTimeForm.get('morningDontCollect').value) {
          this.enableMorningTime(false);
          if (toggleBtn) {
            this.collectionTimeForm.get('afternoonDontCollect').setValue(false);
            this.enableAfternoonTime(true);
          }
        } else {
          this.enableMorningTime(true);
        }
        break;
      }
      case this.LocalConstantsVAR.AFTRN: {
        if (this.collectionTimeForm.get('afternoonDontCollect').value) {
          this.enableAfternoonTime(false);
          if (toggleBtn) {
            this.collectionTimeForm.get('morningDontCollect').setValue(false);
            this.enableMorningTime(true);
          }
        } else {
          this.enableAfternoonTime(true);
        }
        break;
      }
    }
  }

  enableAfternoonTime(flag) {
    /**
     * time selction enabler/disabler
     */
    if (flag) {
      this.collectionTimeForm.get('afternoonFrom').enable();
      this.collectionTimeForm.get('afternoonTo').enable();
    } else {
      this.collectionTimeForm.get('afternoonFrom').disable();
      this.collectionTimeForm.get('afternoonTo').disable();
    }
  }

  enableMorningTime(flag) {
    /**
     * time selction enabler/disabler
     */
    if (flag) {
      this.collectionTimeForm.get('morningFrom').enable();
      this.collectionTimeForm.get('morningTo').enable();
    } else {
      this.collectionTimeForm.get('morningFrom').disable();
      this.collectionTimeForm.get('morningTo').disable();
    }
  }

  getHourInDigit(val) {
    /**
     * to convert the hour in digit for comparison
     */
    if (val) {
      val = this.convertToTimeFormat(val);
      return this.getHoursOrMinutes(val, ColnTimeConstants.hh);
    }
  }

  getMinutesInDigit(val) {
    /**
     * to convert the minutes in digit for comparison
     */
    if (val) {
      val = this.convertToTimeFormat(val);
      return this.getHoursOrMinutes(val, ColnTimeConstants.mm);
    }
  }

  getTimeInDigit(val) {
    if (val) {
      return (this.getHoursOrMinutes(val, ColnTimeConstants.hh) * ConstantsVAR.ONE_HOUR_IN_MINUTES) +
        this.getHoursOrMinutes(val, ColnTimeConstants.mm);
    }
  }

  getHoursOrMinutes(val, hhOrMm) {
    /**
     *  format -- "HH:MM" e.g. "08:30", "17:00"
     * convert and get the string to hours in digit value
     */
    if (val) {
      let pos: number;
      switch (hhOrMm) {
        case ColnTimeConstants.hh: {
          pos = ConstantsVAR.COLN_TIME_POS_0; break;
        };
        case ColnTimeConstants.mm: {
          pos = ConstantsVAR.COLN_TIME_POS_1; break;
        }
      }

      try {
        return Number(val.split(':')[pos]);
      } catch (error) { }
    }
  }

  convertToTimeFormat(val) {
    /**
     * time format --  HH:MM
     * convert to HH:MM with preceeding '0' for single digit
     */
    if (val) {
      try {
        return ((Number(val.split(':')[0]) < ConstantsVAR.DIGIT_10) && (val.charAt(0) !== '0')) ?
          ('0' + val) : val;
      } catch (error) { }
    }
  }

  setBookingPreferenceBody(formData) {
    /**
     * getter and setter for Booking Preference collection time body
     */
    if (this.isDepotTimeNotAvlbl()) {
      this.colnTimeBody = {
        pfClStTm: ColnTimeConstants.TIME_00,
        pfClEnTm: ColnTimeConstants.TIME_00,
        alClStTm: ColnTimeConstants.TIME_00,
        alClEnTm: ColnTimeConstants.TIME_00
      }
    } else if (this.isDepotTimeNotInRange()) {
      this.colnTimeBody = {
        pfClStTm: this.collectionTimeForm.getRawValue().morningFrom,
        pfClEnTm: this.collectionTimeForm.getRawValue().morningTo,
        alClStTm: this.collectionTimeForm.getRawValue().afternoonFrom,
        alClEnTm: this.collectionTimeForm.getRawValue().afternoonTo
      }
    } else {
      this.colnTimeBody = {
        pfClStTm: this.convertToTimeFormat(this.ifEnabled('morningFrom', formData)),
        pfClEnTm: this.convertToTimeFormat(this.ifEnabled('morningTo', formData)),
        alClStTm: this.convertToTimeFormat(this.ifEnabled('afternoonFrom', formData)),
        alClEnTm: this.convertToTimeFormat(this.ifEnabled('afternoonTo', formData))
      }
    }
    this.collectionTimeChange.emit(this.colnTimeBody);
  }

  ifEnabled(control, formData) {
    /**
     * only send values if the field is enabled 
     */
    if (this.collectionTimeForm.get(control).enabled) {
      return formData[control];
    } else {
      return '';
    }
  }

  isCollectionTimeFormValid() {
    /**
     * only send form validity to true if the field is enabled and have values
     */
    Object.keys(this.collectionTimeForm.controls).forEach(key => {
      if (key !== 'morningDontCollect' && key !== 'afternoonDontCollect') {
        this.collectionTimeForm.get(key).enabled ?
          this.collectionTimeForm.get(key).setValidators([Validators.required]) :
          this.collectionTimeForm.get(key).clearValidators();
        this.collectionTimeForm.get(key).updateValueAndValidity({ emitEvent: false });
      }
    });
    return this.collectionTimeForm.valid && !this._shrdFn.checkObjectProprtsForNull(this.colnTimeBody);
  }

  showCollectionTime(mrngOrAftrnFlag) {
    /**
     * show or hide collection time
     * if : View booking then check for collection time initial loaded data
     */

    let flag = true;
    if (this.bookingType === 'VIEW') {
      switch (mrngOrAftrnFlag) {
        case this.LocalConstantsVAR.MRNG: {
          flag = this.colnTimeBodyInit ?
            (this.morningSavedValuePresent(this.colnTimeBodyInit) ? true : false)
            : false; break;
        }
        case this.LocalConstantsVAR.AFTRN: {
          flag = this.colnTimeBodyInit ?
            (this.afternoonSavedValuePresent(this.colnTimeBodyInit) ? true : false)
            : false; break;
        }
      }
    }
    return flag;
  }

  afternoonSavedValuePresent(data) {
    return (data['alClStTm'] && data['alClEnTm']);
  }

  morningSavedValuePresent(data) {
    return (data['pfClStTm'] && data['pfClEnTm']);
  }

  nonEditableInputsFields() {
    return this.bookingType === 'VIEW' || this.isDepotTimeNotAvlbl() || this.isDepotTimeNotInRange();
  }

  /**
   * DEPOT TIME ISSUES FIX
   */

  filterPatchValue(val, mrngOrAftrn, toOrFrom) {
    const drpdwn = this.colnTimeInputs_Copy[mrngOrAftrn][toOrFrom]
    const isExist = drpdwn.indexOf(val) > -1;
    if (isExist) {
      return val;
    } else {
      let def = '';
      switch (toOrFrom) {
        case 'FROM': def = drpdwn[0]
          break;
        case 'TO': def = drpdwn[drpdwn.length - 1]
          break;
        default: break;
      }
      return def;
    }
  }

  isDepotTimeNotInRange() {
    if (!this.isDepotTimeNotAvlbl()) {
      const timeSlab = ColnTimeConstants.TIME_SLAB_IN_MINUTES;
      let opn = this.getHourInDigit(this.colnTimeFrmApiInit_Copy.dptOpenTm);
      const cls = this.getHourInDigit(this.colnTimeFrmApiInit_Copy.dptCloseTm);
      opn = this.getMinutesInDigit(this.colnTimeFrmApiInit_Copy.dptOpenTm) > 0 ? opn + timeSlab : opn;
      return opn >= cls;
    }
  }


  setDataIfDepotTimeNotInRange(apiInit) {
    const clTmInit: BookingPreferenceDTO = {
      pfClStTm: undefined,
      pfClEnTm: undefined,
      alClStTm: undefined,
      alClEnTm: undefined
    };

    const opn = this.getTimeInDigit(apiInit.dptOpenTm),
      mrngLmt = this.getTimeInDigit(ColnTimeConstants.COLN_TIME_MRNG_TO_INIT),
      aftrnLmt = this.getTimeInDigit(ColnTimeConstants.COLN_TIME_AFTRN_FROM_INIT);
    let cls = this.getTimeInDigit(apiInit.dptCloseTm);

    /**
     * API limit is minimum of 1 hour time slot gap,
     * if depot is less than 1 hour time slot, then increase it to 1 hour
     */
    if (cls - opn < ColnTimeConstants.API_MIN_TIME_SLOT_IN_MINUTES) {
      apiInit.dptCloseTm = this.getTimeFromDigit(opn + ColnTimeConstants.API_MIN_TIME_SLOT_IN_MINUTES);
      cls = this.getTimeInDigit(apiInit.dptCloseTm);
    }

    /**
     * check if the time fit in morning or afternoon or both slots
     */
    if (cls <= mrngLmt) {
      clTmInit.pfClStTm = apiInit.dptOpenTm;
      clTmInit.pfClEnTm = apiInit.dptCloseTm;
      this.setColnTimeInterval(clTmInit.pfClStTm, clTmInit.pfClEnTm);
    } else if (opn >= aftrnLmt) {
      clTmInit.alClStTm = apiInit.dptOpenTm;
      clTmInit.alClEnTm = apiInit.dptCloseTm;
      this.setColnTimeInterval(clTmInit.alClStTm, clTmInit.alClEnTm);
    } else {
      clTmInit.pfClStTm = apiInit.dptOpenTm;
      clTmInit.pfClEnTm = ColnTimeConstants.COLN_TIME_MRNG_TO_INIT;
      clTmInit.alClStTm = ColnTimeConstants.COLN_TIME_AFTRN_FROM_INIT;
      clTmInit.alClEnTm = apiInit.dptCloseTm;
      this.setColnTimeInterval(clTmInit.pfClStTm, clTmInit.alClEnTm);
    }
    this.setStaticBookingDetails(clTmInit);
    this.disableAllFields();
    this.notAvlble = {
      MRNG: false,
      AFTRN: false,
    }
  }

  getTimeFromDigit(val) {
    /**
     * convert a time (in digit value) to HH:MM format
     */
    let data = '00:00';
    if (val) {
      const hh = this._shrdFn.appendZeroToVal(Math.floor(val / ConstantsVAR.ONE_HOUR_IN_MINUTES)),
        mm = this._shrdFn.appendZeroToVal(val % ConstantsVAR.ONE_HOUR_IN_MINUTES);
      data = hh + ':' + mm;
    }
    return data;
  }

  setColnTimeInterval(start, end) {
    /**
     * set the total interval time of collection
     */
    this.colnTimeInterval = {
      FROM: start,
      TO: end
    }
  }

}
