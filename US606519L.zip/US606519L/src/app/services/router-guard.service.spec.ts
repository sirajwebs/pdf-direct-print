/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved *copyright* FedEx 2018
 *
 * Typescript code in this page
 */
import { TestBed, inject } from '@angular/core/testing';

import { RouterGuardService } from './router-guard.service';

describe('RouterGuardService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [RouterGuardService]
    });
  });

  it('should be created', inject([RouterGuardService], (service: RouterGuardService) => {
    expect(service).toBeTruthy();
  }));
});
