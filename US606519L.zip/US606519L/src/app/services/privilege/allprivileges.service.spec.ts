/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved *copyright* FedEx 2018
 *
 * Typescript code in this page
 */
import { TestBed, inject } from '@angular/core/testing';
import { AllPrivilegesService } from './allprivileges.service';

describe('AllPrivilegesService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [AllPrivilegesService]
    });
  });

  it('should be created', inject([AllPrivilegesService], (service: AllPrivilegesService) => {
    expect(service).toBeTruthy();
  }));
});
