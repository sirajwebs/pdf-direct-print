/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved *copyright* FedEx 2018
 *
 * Typescript code in this page
 */
import { TestBed, inject } from '@angular/core/testing';
import { AddressbookPrivilegeService } from './addressbook-privilege.service';

describe('AddressbookPrivilegeService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [AddressbookPrivilegeService]
    });
  });

  it('should be created', inject([AddressbookPrivilegeService], (service: AddressbookPrivilegeService) => {
    expect(service).toBeTruthy();
  }));
});
