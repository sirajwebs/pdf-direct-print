/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved (c) Fedex 2018
 *
 * Typescript code in this page
 */
export interface AddressBookDTO {
    name: string;
    types: Array<string>;
    address_components: Array<AddressComponentDTO>;
};

export interface AddressComponentDTO {
    long_name: string;
    short_name: string;
    types: Array<string>;
};

export interface AddressSearchDTO {
    searchValue: string;
    searchType: string;
    companyId?: string;
    addressBookType: Array<string>;
    addressType: Array<string>;
};

export interface FedExAddressResponseDTO {
    contactName: string;
    nickName: string;
    companyName: string;
    address: FedExAddressDTO;
    phoneNumber: string;
    addressType: string;
    addressBookType: string;
    contactID: number;
    SEARCHING_TYPE?: string;
}

export interface SearchAddressResponse {
    output: {
        contact: Array<FedExAddressResponseDTO>;
    };
    }

export interface FedExAddressDTO {
    streetLines: Array<string>;
    city: string;
    stateOrProvinceCode?: string;
    postalCode: string;
    countryCode: string;
    residential?: boolean;
}

export interface AddressAncillary {
    einCd: string;
    validFlg: string;
    verifiedFlg: string;
    sharedFlg: string;
}

export interface FedExContactDTO {
    nickName: string;
        personName: {
        firstName: string;
        lastName: string;
    };
        phoneNumberDetails: [
            {
            type: string;
                number: {
                localNumber: string;
                }
            }
    ];
        companyName: {
        name: string;
    };
}

export interface FedExPartyObject {
    contact: FedExContactDTO;
    address: FedExAddressDTO;
}

export interface AddressRequestObject {
    contact: FedExContactDTO;
    address: FedExAddressDTO;
    deliveryInstructions?: string;
}

export interface AddressRequestPayLoad {
    partyInfoVO: {
        addressAncillaryDetail: AddressAncillary
        party: AddressRequestObject;
        partyType: string;
        addressBookType?: Array<string>;
    };
}

export interface SaveAddressBookResponse {
    contactID: number;
}

export interface AddressCopyData {
    noCityFlg: object;
    countryShrtName: object;
    citySuggestns: object;
    checkPstlAwr: object;
    postalDisable: object;
    fedexAddrID: object;
    selectedAddrBkType: object;
    fromFedexAddressBook: object;
    hideSaveAddrButtonForSameData: object;
    fedexAddressFormData: object;
}

export interface AddressFormData {
    cNme: string;
    cPsn: string;
    cd: string;
    l1: string;
    l2?: string;
    cntry: string;
    pCd: string;
    cty: string;
    tel: string;
    e: string;
    pIn?: string;
    typ?: string; 
    vat?: string;
}

export interface UpdateAddressPut {
    party: {
     contact: {
            personName: string;
            phoneNumber: string;
        };
        address: FedExAddressDTO;
    };
    contactID: string;
    nickName: string;
}

export interface GetEmailResponse {
    output: {
        shipPartyPreference: {
            contactId: number;
            notifications: [
                {
                    receivers: [
                        {
                            notificationReceiverType: string;
                            medias: [
                                {
                                    emailAddresses: [
                                        {
                                            address: string
                                        }
                                    ]
                                }
                            ]
                        }
                    ]
                }
            ]
        }
    }

}

export interface UpdateEmailRequest {
    shipPartyPreference: {
        contactId: number;
        notifications: [
            {
                receivers: [
                    {
                        notificationReceiverType: string;
                        medias: [
                            {
                                emailAddresses: [
                                    {
                                        address: string;
                                    }
                                ]
                            }
                        ]
                    }
                ]
            }
        ]
    }
}

export interface UpdateAddressBookRequest {
   partyInfoVO: {
        party: AddressRequestObject;
        partyType: string;
    }
}

export interface AddressBookResponse {
    output: {
        contactID: number;
    }
}

export interface GetAddressByContactID {
    contact: {
        contactId: number;
        nickName: string;
        personName: {
            firstName: string;
            lastName: string;
            fullName: string;
        };
        phoneNumberDetails: [
            {
                number: {
                    localNumber: number;
                }
            }
        ];
        companyName: {
            name: string;
        }
    };
    address: FedExAddressDTO;
    deliveryInstructions?: string;
}

export interface GetAddressBookDTO {
    output: {
        partyInfoVO: {
            party: GetAddressByContactID;
            partyType: string;
        }
    }
}


