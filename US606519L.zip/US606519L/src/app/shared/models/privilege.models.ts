/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved (c) Fedex 2018
 *
 * Typescript code in this page
 */
export interface PrivilegeDTO {
    privilegeID: string;
    opCo: string;
    authorization: string;
    properties: Array<string>;
    carrierCode: string;
    companyAdminSet: boolean;
    operatingOrgCodes: string;
    businessFunctionType: string;
    privilegeType: string;
    opCos: Array<string>;
};

interface FedexServiceName {
    type: string;
    subType: string;
    encoding: string;
    value: string;
}


