/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved *copyright* FedEx 2018
 *
 * Typescript code in this page
 */

export interface SupportListDTO {
    cNme: string;
    lddn: string;
    nfa: string;
    extrnl: string;
    Checked: string;
};

