/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved *copyright* FedEx 2018
 *
 * Typescript code in this page
 */
/**
 * testing required imports
 */
import { TestBed, async, ComponentFixture, fakeAsync, tick } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';

/**
 * components required imports
 */
import { ContentRefComponent } from './content-ref.component';
import { Router, Routes } from '@angular/router';
import { Component, OnInit, ViewChild, HostListener, OnDestroy, ChangeDetectorRef } from '@angular/core';
import { Subscription } from 'rxjs/Subscription';
import { BookingService } from 'app/services/booking.service';
import { SharedataService } from './../../../services/sharedata.service';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { HttpModule, Http, RequestOptions } from '@angular/http';
import { HttpClient, HttpHeaders, HttpParams, HttpResponse, HttpRequest } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';



describe('ContentRefComponent', () => {
  let component: ContentRefComponent;
  let fixture: ComponentFixture<ContentRefComponent>;
  let debugElement: DebugElement;
  let htmlElement: HTMLElement;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ContentRefComponent],
      imports: [
        HttpModule,
        FormsModule,
        ReactiveFormsModule
      ],
      providers: []
    })
    .compileComponents();
    fixture = TestBed.createComponent(ContentRefComponent);
    debugElement = fixture.debugElement;
    fixture.autoDetectChanges();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ContentRefComponent);
    component = fixture.componentInstance;
    debugElement = fixture.debugElement;
    fixture.detectChanges();
  });


  it('should create the app', async(() => {
    expect(fixture.debugElement.componentInstance).toBeTruthy();
  }));

  it('add content reference data', () => {
    const value = 123;
    component.addContentRef();
    component.contentRefBody.push(value);
    expect(component.contentRefForm.valid).toBeTruthy();
    expect(component.contentRefBody).toBeTruthy();
    expect(component.contentRefBody.length).toEqual(1);
  });

  it('remove content refrence data', () => {
    const index = 0;
    component.deleteContentRefNo(index);
    expect(component.deleteContentRefNo(index)).not.toBeNull();
    component.contentRefBody.splice(index, 1);
    expect(component.contentRefBody.length).toEqual(0);
  });

  it('emit value and reset form', () => {
    const value = [123];
    component.contentRefNumbers.emit(value);
    expect(component.contentRefNumbers).not.toBeNull();
    expect(component.contentRefForm.get('contentRefNo').value).toBe('');
  });

  it('show error when user add content refrence more than 10', () => {
    component.contentRefBody.length = 10
    component.totalContentRefFlag = true;
    fixture.detectChanges();
    expect(component.contentRefBody.length).toBeGreaterThan(9);
    expect(component.totalContentRefFlag).toBe(true);
  });

  it('return false for required', () => {
    const field = 'contentRefNo';
    component.contentRefForm.patchValue({ contentRefNo: 123 });
    const value = component.isFieldRequired(field);
    fixture.detectChanges();
    expect(value).toBeFalsy();
  });

  it('show error for special character', () => {
    const field = 'contentRefNo';
    component.contentRefForm.patchValue({ contentRefNo: '@#$$@!!' })
    fixture.detectChanges();
    expect(component.contentRefForm.get('contentRefNo').hasError('pattern')).toBeTruthy();
  });

  // it('return true for required', () => {
  //   const field = 'contentRefNo';
  //   component.contentRefForm.setValue({ contentRefNo: '' })
  //   const value = component.isFieldRequired(field);
  //   fixture.detectChanges();
  //   expect(value).toBeTruthy();
  // });

});
