/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved *copyright* FedEx 2018
 *
 * Typescript code in this page
 */

import { Component, OnInit, Input, Output, EventEmitter, OnChanges, SimpleChanges } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { FedexAddressbookService } from './../../../services/fedex-addressbook.service';
import { ConstantsVAR, AddressBookConst, ConstantsJson, NUMBERS } from 'app/shared/constants/constants-var';
import {
  AddressFormData, AddressBookResponse, AddressRequestObject, AddressCopyData
} from './../../models/addressbook.models';
import { SharedataService } from 'app/services/sharedata.service';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { FORMS } from './../../constants/forms.properties';

@Component({
  selector: 'app-save-address-book',
  templateUrl: './save-address-book.component.html',
  styleUrls: ['../address/address.component.css','./save-address-book.component.css']
})
export class SaveAddressBookComponent implements OnInit, OnChanges {

@Input()  disableAll: boolean = null;
@Input() addrIdFlag: string;
@Input() isSameAddr: boolean = null;
  @Input() selectedAddrBkType = JSON.parse(JSON.stringify(ConstantsJson.addressInitString));
  @Input() addressBookPrvlg: string;
  @Input() formIsValidated: boolean = null;
  @Output() updatedForm = new EventEmitter<Object>();
  @Input() formValue: AddressFormData;
  @Input() fedexAddrID: number;
  @Input() hideSaveAddrButtonForSameData = JSON.parse(JSON.stringify(ConstantsJson.addressInitBoolean));
  @Input() hideSveBtnOnOverlay = JSON.parse(JSON.stringify(ConstantsJson.addressInitBoolean));

  readonly FORMS = FORMS;
  addressResponse = JSON.parse(JSON.stringify(ConstantsJson.addressInitObject)); // FedExAddressResponseDTO
  fromFedexAddressBook = JSON.parse(JSON.stringify(ConstantsJson.addressInitBoolean));
  disableSaveButton = JSON.parse(JSON.stringify(ConstantsJson.addressInitBoolean));
  hideAddressSaved = JSON.parse(JSON.stringify(ConstantsJson.addressInitBooleanTrue));
  apiErrorMessage = AddressBookConst.APIERROR.MESSAGE;
  apiError = false;
contactIdExists: boolean = null;
  addressFormBody = {}; // model to be created;
  saveAddrssFlag = AddressBookConst.SAVE;
    fedexAddressSaveForm = new FormGroup({
    fedExAddress: new FormControl(AddressBookConst.UPDATE),
    nickName: new FormControl('', [Validators.required, Validators.maxLength(FORMS.SAVEADDRESS.NICK_NAME_MAXLENGTH)])
  });
  saveBtnDisable: BehaviorSubject<boolean> = new BehaviorSubject(true);

  constructor(private _fedexAdrSer: FedexAddressbookService,
    private _shrd: SharedataService) {
    this.saveBtnBehavior();
  }

  ngOnInit() { }
  
  ngOnChanges(changes: SimpleChanges) {
    this.initializeSameAsBtn(changes);
  }

  saveBtnBehavior() {
    this.saveBtnDisable.subscribe(val => {
      if (val) {
        setTimeout(() => {
          this.saveBtnDisable.next(false);
        }, ConstantsVAR.MILISEC_5000);
      }
    });
  }

  initializeSameAsBtn(changes) {
    if (changes ? (changes.isSameAddr ? changes.isSameAddr.previousValue : false) : false) {
      let data: AddressCopyData;
      this._shrd.getAddrBkCopyData.subscribe(val => { data = val; });
      switch (this.addrIdFlag) {
        case 's':
          this.selectedAddrBkType['s'] = data.selectedAddrBkType['p'];
          break;
        case 'r':
          this.selectedAddrBkType['r'] = data.selectedAddrBkType['d'];
          break;
        default: break;
      }
      this.checkNCopyAddrBkProprts('BTN');
    }
  }

  fedexAddrIDzCopied() {
    this.checkNCopyAddrBkProprts('POPUP');
      this.fedexAddressValue();
  }

  checkNCopyAddrBkProprts(saveBtnPopup) {

    switch (this.addrIdFlag) {
      case 'p':
      case 'd':
        if (!this.fedexAddrID[this.addrIdFlag]) {
          this.copyAddrProp('POPUP');
        }
        break;
      case 's':
        this.initiateCopy('s', 'p', saveBtnPopup);
        break;
      case 'r':
        this.initiateCopy('r', 'd', saveBtnPopup);
        break;
      default: break;
    }
  }

  initiateCopy(cpTo, cpFrm, saveBtnPopup) {
    this.fromFedexAddressBook[cpTo] = false;
    if (this.fedexAddrID[cpTo]) {
      this.fromFedexAddressBook[cpTo] = true;
      if (this.fedexAddrID[cpTo] === this.fedexAddrID[cpFrm]) {
        this.copyAddrProp(saveBtnPopup);
      }
    }
  }

  copyAddrProp(saveBtnPopup) {
    switch (saveBtnPopup) {
      case 'POPUP':
        this.fromFedexAddressBook[this.addrIdFlag] = false;
        this.fedexAddressSaveForm.get('fedExAddress').patchValue(AddressBookConst.SAVE);
        break;
      case 'BTN':
        this.hideSaveAddrButtonForSameData[this.addrIdFlag] = true;
        break;
      default: break;
    }
  }

  showSaveModal(){
    document.getElementById(`saveAddressBookModalLink-${this.addrIdFlag}`).click();
      setTimeout(() => {
      this.fedexAddressSaveForm.get('fedExAddress').patchValue(AddressBookConst.UPDATE);
      this.fedexAddrIDzCopied();
    }, ConstantsVAR.MILISEC_50);
    this.fedexAddressSaveForm.reset('');
    return false;
  }

  fedexAddressValue() {
    const selectedValue = this.fedexAddressSaveForm.get('fedExAddress').value;
    this.saveAddrssFlag = selectedValue;
    if (!this.fromFedexAddressBook[this.addrIdFlag]) {
      this.saveAddrssFlag = AddressBookConst.SAVE;
    }
  }

  saveToAddressBook() {
    Object.keys(this.formValue).forEach(key => {
      this.addressFormBody[key] = this.formValue[key]['_value']
    });
    this.fedexAddressValue();
    switch (this.saveAddrssFlag) {
      case AddressBookConst.SAVE:
        this.saveAddress();
        break;
      case AddressBookConst.UPDATE:
        this.updateAddress();
        break;
    }
}

  saveAddress(){
    /**
     * save address in fedex address book
     * create fedexaddress request body from address form which will sent as API request payload
     * show toaster on API error and success response related message
     * Note: if contactID returns 0 on successfull response, there are two reason, 1 -> nickname already exist and 2 -> cookie has expired
     */
    this.apiError = false;
      this.fedexAddressSaveForm.get('nickName').markAsTouched();
     if (!this.getNickNameError()) { return; }
      const saveAddrObject = this.fedExRequestObject(this.addressFormBody, this.fedexAddressSaveForm.get('nickName').value.trim());
      this._shrd.setLoaderSrvc(true);
      const defaultAddrBkType = AddressBookConst.bookType.PERSONAL;
    this._fedexAdrSer.saveAddressBook(saveAddrObject,
        [defaultAddrBkType]).subscribe((response) => {
          this._shrd.setLoaderSrvc(false);
        this.contactIdExists  = this.responseData(response);
        if (!this.contactIdExists) {
            this.fromFedexAddressBook[this.addrIdFlag] = true;
            this.fedexAddrID[this.addrIdFlag] = this.addressResponse[this.addrIdFlag]['contactID'] = response.output.contactID;
            this.addressResponse[this.addrIdFlag]['nickName'] = this.fedexAddressSaveForm.get('nickName').value;
            this.selectedAddrBkType[this.addrIdFlag] = defaultAddrBkType;
      }
    }, error => {
          this._shrd.setLoaderSrvc(false);
          this.apiError = true;
          this.showError(error);
    });
  }

  getNickNameError() {
    /**
     * return false for error like empty value, null value, space and minimum of 4 values in nickname field
     */
    const nickName = this.fedexAddressSaveForm.get('nickName').value;
    return (nickName) ? (nickName.trim().length > NUMBERS.THREE) : true ? false : false;
  }

  updateAddress() {
    /**
     * update address in fedex address book
     * create fedexaddress request body from address form which will sent as API request payload
     * show toaster on API error and success response related message
     */
     this.apiError = false;
    const updateAddrObject = this.fedExRequestObject(this.addressFormBody, this.addressResponse[this.addrIdFlag].nickName);
    this._shrd.setLoaderSrvc(true);
    this._fedexAdrSer.updateAddressBook(updateAddrObject, this.addressResponse[this.addrIdFlag].contactID,
      AddressBookConst.partyType.RECIPIENT).subscribe((response) => {
        this._shrd.setLoaderSrvc(false);
        if (this.responseData(response)) {
          this.showError('Error');
      }
    }, error => {
        this.apiError = true;
        this._shrd.setLoaderSrvc(false);
        this.showError(error);
      });
  }

  showError(errmessage: string) {
    this.closeModal();
    this.apiErrorMessage = this._fedexAdrSer.apiError(errmessage)
  }

  closeModal() {
    /**
     * close save address modal which is related to current addressId form
     * set update address radio button as selected on close of modal
     */
    this.fedexAddressSaveForm.get('fedExAddress').patchValue(AddressBookConst.UPDATE);
    document.getElementById(`addrSaveCancel-${this.addrIdFlag}`).click();
  }

  responseData(response: AddressBookResponse) {
    /**
     * get response data from Address Book API
     * on successfull response (i,e) contact ID is not 0, update address form by emitting value of save / update address object
     * which has been passed as request object
     * call update email API when there is email value in address form
     * on successfull response, show success message "Address Saved" and close modal
     */

    if (response.output.contactID === AddressBookConst.CONTACT_ID_EXIST) {
      return true;
    }else {
      this.updatedForm.emit(this.addressFormBody);
      this.hideSaveAddrButtonForSameData[this.addrIdFlag] = true;
      if (this.addressFormBody['e'] !== null || this.addressFormBody['e'] !== '') {
        this.updateEmail(response.output.contactID, this.addressFormBody['e']);
      }
      this.flashAddressSavedMsg();
      return false;
    }
    }

  updateEmail(id: number, email: string) {
    /**
     * update the email related to contact ID of searched or update address
     * on successfull response show save address message and close modal
     */
    this._shrd.setLoaderSrvc(true);
    this._fedexAdrSer.updateContactEmail(id, email).subscribe(response => {
      this._shrd.setLoaderSrvc(false);
      if (response.output.contactID !== AddressBookConst.CONTACT_ID_EXIST) {
        this.flashAddressSavedMsg();
      } else {
        this.showError('Error');
      }
    }, error => {
      this._shrd.setLoaderSrvc(false);
      this.showError('Error');
    });
  }

  flashAddressSavedMsg() {
    /**
     * show Address Save on successfull event
     */
    this.closeModal();
    this.fromFedexAddressBook[this.addrIdFlag] = true;
    this.hideAddressSaved[this.addrIdFlag] = false;
    setTimeout(() => {
      this.hideAddressSaved[this.addrIdFlag] = true;
    }, ConstantsVAR.MILISEC_5000);
  } 

  fedexPersonName(name: string) {
    /**
     * to convert the person name into first name and last name
     */
    const result = name ? name.trim().split(' ') : [ConstantsVAR.EMPTY_STRING],
    pName = {firstName: ConstantsVAR.EMPTY_STRING, lastName: ConstantsVAR.EMPTY_STRING}
    pName.firstName = result[0];
    result.shift();
    pName.lastName = result.join(' ');
    return pName;
  }

  fedExRequestObject(formValue, nickname: string) {
    /**
     * create fedex address object based on API request body for save and update address
     */
    const frmVl: AddressFormData = formValue;
    const requestObject: AddressRequestObject = {
      address: {
        streetLines: [frmVl.l1, frmVl.l2],
        city: frmVl.cty,
        postalCode: frmVl.pCd,
        countryCode: frmVl.cd,
        residential: (formValue.cd === AddressBookConst.RESIDENTIAL_COUNTRY) ? true : false
      },
      contact: {
        nickName: nickname,
        personName: this.fedexPersonName(frmVl.cPsn),
        phoneNumberDetails: [
          {
            type: AddressBookConst.CONTACT.MOBILE,
            number: {
              localNumber: frmVl.tel
            }
          }
        ],
        companyName: {
          name: frmVl.cNme
        }
      },
      deliveryInstructions: frmVl.pIn
    }
    return requestObject;
  }

  showSaveAddrBkBtn() {
    /**
    * shows save address button on condition, namely
    * will NOT show on address saved message
    * will NOT show when address search overlay is displayed
    * will NOT show if respective privilege is not there
    */
     return !this.hideSveBtnOnOverlay[this.addrIdFlag]
       && this.privilegeCheck()
      && this.hideAddressSaved[this.addrIdFlag];
   }
 
   enableSaveAddrBkBtn() {
    /**
   * shows save address button on condition, namely
   * will NOT enable on address is from fedex address book
   * will NOT enable address is same as fedex address (not changed)
   * will NOT enable when address form fields are in compliance with fedex portal UI
   */
    return (!this.fromFedexAddressBook[this.addrIdFlag] || !this.hideSaveAddrButtonForSameData[this.addrIdFlag])
      && this.addrBkRqrdFields()
      && !this.saveBtnDisable.getValue();
  }

  showAddrBkTypeRadioBtn() {
    /**
     * shows radio button based on condition, namely
     * when suggestion is selected from address book and not from google
     */
    return this.fromFedexAddressBook[this.addrIdFlag] && this.privilegeCheck('OPTIONS');
  }

  addrBkRqrdFields() {
    /**
     * fedex portal has company name as optional field, rest all the fields are mandatory
     */
    const addrBkRqrdFields = ['cNme', 'l1', 'cd', 'cty', 'tel', 'e', 'cPsn'];
    let show = true;
    addrBkRqrdFields.forEach(key => {
      if (!this.formValue[key]['_value']) {
        show = false;
      }
      if (key === 'cty' && this.formValue['cty']['_status'] !== 'VALID') {
        show = false;
      }
    });
    return this.formIsValidated && show;
  }

  privilegeCheck(flag?) {
    let show = false;
    if (!this.fromFedexAddressBook[this.addrIdFlag]) {
      show = this.addressBookPrvlg['personalCtrl'];
    } else {
      switch (this.selectedAddrBkType[this.addrIdFlag]) {
        case AddressBookConst.bookType.PERSONAL:
          show = this.addressBookPrvlg['personalCtrl'];
          break;
        case AddressBookConst.bookType.CENTRAL:
          show = this.setOptions4CentralAddr(flag, this.addressBookPrvlg['centralMod']);
          break;
        default: break;
      }
    }
    return show;
  }

  setOptions4CentralAddr(flag, show) {
    /**
     * to set radio buttons based on privilege inside the modal
     */
    if (flag === 'OPTIONS') {
      if (!show) {
        this.fedexAddressSaveForm.get('fedExAddress').patchValue(AddressBookConst.SAVE);
      } else {
        if (!this.addressBookPrvlg['personalCtrl']) {
          this.fedexAddressSaveForm.get('fedExAddress').disable();
        }
      }
    } else {
      if (!show) {
        show = this.addressBookPrvlg['personalCtrl'];
      }
    }
    return show;
  }

  disabledRdioBtn(rdioVal) {
    if (this.fedexAddressSaveForm.get('fedExAddress').disabled) {
      return this.fedexAddressSaveForm.get('fedExAddress').value === rdioVal ?
        'checkmark-radio-deact-selected' : 'checkmark-radio-deact';
    }
  }

  resetAllData() {
    /**
     * reset all form data
     */
    this.addressResponse = JSON.parse(JSON.stringify(ConstantsJson.addressInitObject));
    this.fromFedexAddressBook = JSON.parse(JSON.stringify(ConstantsJson.addressInitBoolean));
    this.hideAddressSaved = JSON.parse(JSON.stringify(ConstantsJson.addressInitBooleanTrue));

    this.contactIdExists = null;
    this.addressFormBody = {};
    this.saveAddrssFlag = AddressBookConst.SAVE;
    this.fedexAddressSaveForm.reset();
  }

}
