/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved *copyright* Fedex 2018
 *
 * Typescript code in this page
 */
import { FedexAddressbookService } from './../../../services/fedex-addressbook.service';
import { ConstantsVAR, AddressBookConst, AddressBookConst_Others, CSSPROP } from './../../constants/constants-var';
import { Component, OnInit, EventEmitter, Output, Input, OnDestroy, ChangeDetectorRef } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { Subscription } from 'rxjs/Subscription';
import {
  FedExAddressResponseDTO, GetAddressByContactID, AddressFormData
} from './../../models/addressbook.models';
import { SharedFunctionsService } from 'app/services/shared-functions.service';
import { SharedataService } from 'app/services/sharedata.service';

@Component({
  selector: 'app-fedex-address-book',
  templateUrl: './fedex-address-book.component.html',
  styleUrls: ['../address/address.component.css', './fedex-address-book.component.css'],
  providers: [SharedFunctionsService]
})
export class FedexAddressBookComponent implements OnInit, OnDestroy {

  apiSubscription = [];
  subscriptions: Array<Subscription> = [];
  FedExAddressSearchType = AddressBookConst.SearchType;
  results: number;
  fedexAddress = [];
  searchTitle: string;
  apiErrorMessage: string;
  fedexAddressFormData: AddressFormData;
  fedexAddressSearchForm = new FormGroup({
    searchValue: new FormControl(''),
    searchType: new FormControl(AddressBookConst.SearchTypeValue.COMPANY_NAME),
  });
  smallLoader = false;

  @Input() public viewBlock;
  @Input() public searchValue;
  @Input() public addressBookPrvlg;
  @Input() public addrFormValue;
  @Output() public closeButton = new EventEmitter<string>();
  @Output() public addressObject = new EventEmitter<FedExAddressResponseDTO>();
  @Output() public fromFedexAddressBook = new EventEmitter<boolean>();
  @Output() public emitEmailAddress = new EventEmitter<string>();
  @Output() public hideSaveAddrBtnForSameData = new EventEmitter<boolean>();
  @Output() public hideOnOverlay = new EventEmitter<boolean>();

  constructor(private _cd: ChangeDetectorRef, private _fedexAB: FedexAddressbookService,
    private _shrdFn: SharedFunctionsService, private _shrdt: SharedataService) { }

  ngOnInit() {
    /**
     * set company name as initial value for drop down
     * set results value to be length of address list
     */
    this.searchTypeChange('ONINIT');
    this.searchValue.subscribe(data => {
      this.fedexAddressSearchForm.get('searchValue').setValue(data);
    });
  }

  setResultValue(data) {
    /**
     * set result value to fedexAddress array
     */
    this.fedexAddress = data;
    this.results = this.fedexAddress.length;
  }

  addrBkSearchBody() {
    return {
      searchType: this.fedexAddressSearchForm.get('searchType').value,
      searchValue: this.fedexAddressSearchForm.get('searchValue').value,
      addressBookType: this._fedexAB.fetchAddrBkTypeFrmPrvlg(this.addressBookPrvlg), // user privelge value is applied
      addressType: AddressBookConst_Others.FdxAddressType // user privelge value is applied
    };
  }

  searchTypeChange(flag?) {
    /**
     * change title/caption of Input text field based on user selection of category dropdown
     */
    this.searchTitle = this.FedExAddressSearchType.find(s => s.value === this.fedexAddressSearchForm.get('searchType').value).name;
    if (flag !== 'ONINIT') {
      this.fetchAddressOnFocus(this.fedexAddressSearchForm.get('searchValue').value);
    }

  }

  APIErrorMessage(error: string) {
    /**
     * show error message on API Failure
     * set fedex address data array to empty
     */
    this.setResultValue([]);
    this.apiErrorMessage = this._fedexAB.apiError(error);
  }

  selectValue(val) {
    /**
     * select the address which has been clicked from address list and emit the selected address Object.
     * remove inner Html attributes from company name and nick name
     */
    val.companyName = this.removeStrongTag(val.companyName)
    val.nickName = this.removeStrongTag(val.nickName);
    setTimeout(() => { // sometimes show <strong> tag in emitted data
      this.addressObject.emit(val);
      this.fromFedexAddressBook.emit(true);
      this.closeOverlay();
    }, ConstantsVAR.MILISEC_50);
  }

  ngOnDestroy() {
    this._cd.detach();
    this.subscriptions.forEach((subscription: Subscription) => { subscription.unsubscribe(); });
    Object.keys(this.apiSubscription).forEach(apiName => { this.apiUnsubscribe(apiName); });

  }

  apiUnsubscribe(apiName) {
    /**
     * unsubscribe all subscription
     */
    if (this.apiSubscription[apiName]) { this.apiSubscription[apiName].unsubscribe(); }
  }

  onInputChange() {
    this.fetchAddressOnFocus(this.fedexAddressSearchForm.get('searchValue').value);
  }

  fetchAddressOnFocus(value: string) {
    this.smallLoader = true;
    const apiName = 'checkFedExAddress';
    this.apiUnsubscribe(apiName);
    const addrBkTyp = this._fedexAB.fetchAddrBkTypeFrmPrvlg(this.addressBookPrvlg);
    value = value.trim();
    if (value && value.length > 1 && addrBkTyp.length) {
      this.apiErrorMessage = null;

      this.subscriptions.push(this.apiSubscription[apiName] = this._fedexAB.searchAddressBook(value, addrBkTyp,
        this.fedexAddressSearchForm.get('searchType').value).subscribe(result => {
          this.smallLoader = false;
          this.setFedexAddress(result['output'].contact);
        }, error => {
          this.smallLoader = false;
          this.APIErrorMessage(error);
        }));
    } else {
      this.smallLoader = false;
      this.apiErrorMessage = AddressBookConst.MINIMUN_CHARACTER_SEARCH;
      this.setResultValue([]);
    }

  }

  sortByProperty(a, b) {
    try {
      if (a.toUpperCase() > b.toUpperCase()) {
        return 1;
      } else if (a.toUpperCase() < b.toUpperCase()) {
        return -1;
      } else {
        return 0;
      }
    } catch (err) { }
  }

  fedExAutocomplete(InputValue, resultValue, category) {
    InputValue = InputValue.toLowerCase();
    switch (category) {
      case AddressBookConst.SearchTypeValue.COMPANY_NAME:
        resultValue.map(el => {
          el.companyName = this.autoComplete(el.companyName, InputValue);
        });
        break;

      case AddressBookConst.SearchTypeValue.NICK_NAME:
        resultValue.map(el => {
          el.nickName = this.autoComplete(el.nickName, InputValue);
        });
        break;
    }
  }

  private autoComplete(element, inputValue) {
    /**
     * highlight matching text / string value with corresponding value in the array list
     */
    const textIndex = element.toLowerCase().indexOf(inputValue);
    element = element.substring(0, textIndex) +
      '<strong>' + element.substring(textIndex, textIndex + inputValue.length) + '</strong>' +
      element.substring(textIndex + inputValue.length, element.length);
    return element;
  }

  removeStrongTag(element) {
    /**
     * remove strong HTML tag from selected element
     */
    return element.replace(/<strong>/gi, '').replace(/<\/strong>/gi, '');
  }

  closeOverlay() {
    /**
     * close address book search overlay on clicking close icon (X)
     */
    this.fedexAddressSearchForm.get('searchType').setValue(AddressBookConst.SearchTypeValue.COMPANY_NAME);
    this.closeButton.emit(CSSPROP.HIDESHOW.hide);
    setTimeout(() => { this.hideOnOverlay.emit(false); }, ConstantsVAR.MILISEC_50);
  }

  private setFedexAddress(data) {
    data.sort((a: FedExAddressResponseDTO, b: FedExAddressResponseDTO) => {
      this.sortByProperty(a.address.city, b.address.city);
    }).sort((a: FedExAddressResponseDTO, b: FedExAddressResponseDTO) => {
      this.sortByProperty(a.address.streetLines[AddressBookConst.ADDR_LINE1_POS],
        b.address.streetLines[AddressBookConst.ADDR_LINE1_POS]);
    }).sort((a: FedExAddressResponseDTO, b: FedExAddressResponseDTO) => {
      this.sortByProperty(a.companyName, b.companyName);
    });
    this.setResultValue(data)
    this.fedExAutocomplete(this.fedexAddressSearchForm.get('searchValue').value,
      this.fedexAddress,
      this.fedexAddressSearchForm.get('searchType').value);
  }

  addCountryDataToFedexAddress(data: GetAddressByContactID, country) {
    /**
     * create address from Fedex Address search API Response in complaince with google address_components format
     * declare response value with respect to country, street number, postal code and locality
     * set address data in accordance with google format with long_name, short_name and types, map concerned value to it
     */
    const addressBook = {
      name: data.contact.companyName.name,
      types: ['establishment'],
      address_components: new Array()
    }
    const country_obj = this._fedexAB.setAddressData(country, data.address.countryCode, 'country');
    const street_number = this._fedexAB.setAddressData(data.address.streetLines[AddressBookConst.ADDR_LINE1_POS],
      data.address.streetLines[AddressBookConst.ADDR_LINE1_POS], 'street_number');
    const addrLine2 = this._fedexAB.setAddressData(data.address.streetLines[AddressBookConst.ADDR_LINE2_POS],
      data.address.streetLines[AddressBookConst.ADDR_LINE2_POS], AddressBookConst.ADDRBK_GOOGLE_MAPPINGS_LINE2);
    const postal_code = this._fedexAB.setAddressData(data.address.postalCode, data.address.postalCode, 'postal_code');
    const locality = this._fedexAB.setAddressData(data.address.city, data.address.city, 'locality');
    addressBook.address_components.push(street_number, addrLine2, country_obj, postal_code, locality);
    return addressBook;
  }

  showAddressBookOverlay(block, activity) {
    /**
     * show address book overlay when user clicks on view more results
     */
    const addressBookDiv = document.getElementsByClassName('address-book-div') as HTMLCollectionOf<HTMLElement>;
    const addressSearchDiv = document.getElementById('searchValue' + block) as HTMLElement;
    addressSearchDiv.focus();
    setTimeout(() => {
      try {
        addressSearchDiv.focus();
      } catch (e) { }
    }, ConstantsVAR.MILISEC_100);
    this.hideOnOverlay.emit(true);
    addressBookDiv[block].style.display = activity;
  }

  viewResults(block, viewBlock, array) {
    /**
     * show view results title when address suggestion are more than 5
     * on clicking, show address book search overlay
     * adds inline style as the element is created on the fly
     */
    const parentElement = document.getElementsByClassName('pac-container')[block];
    const div = document.createElement('div')
    div.innerHTML = '<p>view all ' + array.length + ' results from address book</p>';
    const self = this;
    div.addEventListener('mousedown', (e) => {
      this.setResultValue(array);
      this.fedExAutocomplete(this.fedexAddressSearchForm.get('searchValue').value,
        this.fedexAddress,
        this.fedexAddressSearchForm.get('searchType').value);
      self.showAddressBookOverlay(viewBlock, CSSPROP.HIDESHOW.show);
    });

    div.style.textAlign = 'center';
    div.style.fontSize = '14px';
    div.style.textTransform = 'uppercase';
    div.style.fontWeight = '600';
    div.style.color = '#007ab7';
    div.style.cursor = 'pointer'
    parentElement.childNodes[4].appendChild(div);
  }

  removeChildElements(block?) {
    /**
     * remove all fedex related search results when users hits backspace or deleted the search keyword
     */
    const x = document.getElementsByClassName('FxAB');
    while (x[0]) {
      x[0].parentNode.removeChild(x[0]);
    }
  }

  setGoogleLikefedexAddress(inputValue, block, viewBlock, fedexAddressList) {
    /**
     * populate search results from fedex search address API
     * limit search suggestion upto 5
     * if results exceeds more than 5 show view results title at the end of fedex address suggestion
     */
    let companyInName;
    if (inputValue) {
      companyInName = inputValue.toUpperCase();
    } else {
      return false;
    }
    this.removeChildElements();
    let maxA = 0;
    try {
      for (let i = 0; i < fedexAddressList.length; i++) {
        if (companyInName.length > 1) {
          maxA++;
          if (maxA <= ConstantsVAR.FEDEX_ADDR_LIST) {
            this.fedexWithGoogleAutoComplete(i, fedexAddressList[i], companyInName, true, block)
          }
        }
      }
      if (companyInName.length > 1 && fedexAddressList.length > ConstantsVAR.FEDEX_ADDR_LIST) {
        this.viewResults(block, viewBlock, fedexAddressList)
      }
    } catch (err) { }
  }

  fedexWithGoogleAutoComplete(ID, fedexAddress, InputValue, isFedexData, InputBlock) {
    /**
     * create div and add styling with refrence to google auto complete style classes
     * create related html elments and add event listener on selecting address
     */
    let resultValue, nickname, streetLine, city, countryCode, addrBkType;

    if (isFedexData) {
      resultValue = fedexAddress['companyName'] + ', ',
        nickname = '(Nickname: ' + fedexAddress['nickName'] + ' ) ',
        streetLine = fedexAddress['address']['streetLines'][AddressBookConst.ADDR_LINE1_POS] + ', ',
        city = fedexAddress['address']['city'],
        countryCode = fedexAddress['address']['countryCode'],
        addrBkType = fedexAddress['addressBookType'];
    } else { resultValue = ''; } // refactor required

    const textIndex = resultValue.toUpperCase().indexOf(InputValue);
    const parentElement = document.getElementsByClassName('pac-container')[InputBlock];
    const div = document.createElement('div');
    div.setAttribute('class', 'pac-item FxAB');
    div.innerHTML += '<input type="hidden" value="' + ID + '">';
    const iconSpan = document.createElement('span');
    iconSpan.setAttribute('class', 'pac-icon');
    if (!isNaN(ID)) {
      const img = 'icon_address_book';
      // below line may be required - refer US-589330 point no 7
      // const img = (addrBkType === AddressBookConst.bookType.PERSONAL) ? 'icon_address_book' : 'icon_centraladdress_book';
      iconSpan.setAttribute('style', `background: url(./assets/images/${img}.png) no-repeat;
        width: 16px; height: 16px; background-position: 4px 0px;`)
    }
    div.appendChild(iconSpan);
    const itmQry = document.createElement('span');
    itmQry.setAttribute('class', 'pac-item-query');
    resultValue = '<span>' + resultValue.substring(0, textIndex) +
      '<span class="pac-matched">' + resultValue.substring(textIndex, textIndex + InputValue.length) + '</span>' +
      resultValue.substring(textIndex + InputValue.length, resultValue.length) + '</span>'
    itmQry.innerHTML += resultValue;
    if (isFedexData) {
      itmQry.innerHTML += '<span style="color:#757575">' + nickname + streetLine + ' ' + city + ', ' + countryCode + '</span>';
    }
    div.appendChild(itmQry);
    parentElement.insertBefore(div, parentElement.firstChild);
  }

  getEmailId(contactID: number, id) {
    /**
     * get contact email ID by passing contact ID
     */
    const apiName = 'getEmailId_' + id;
    this.apiUnsubscribe(apiName);
    this.subscriptions.push(this.apiSubscription[apiName] = this._fedexAB.getContactEmail(contactID).subscribe(data => {
      if (data.output.hasOwnProperty('shipPartyPreference')) {
        this.emitEmailAddress.emit(this.getFedexEmailfromAPI(data));
        this.setFedexEmail(this.getFedexEmailfromAPI(data));
      } else {
        this.emitEmailAddress.emit('');
        this.setFedexEmail(null);
        // show toaster error if shippartypreference property is not in response
      }
      this._shrdt.setLoaderSrvc(false);
    }, error => {
      this._shrdt.setLoaderSrvc(false);
      this.emitEmailAddress.emit('');
      this.setFedexEmail(null);
      // show toaster for API error
    }));
  }

  getFedexEmailfromAPI(data) {
    /**
     * method to return email address from get email API response object
     */
    const recipient = data.output.shipPartyPreference.notifications.filter(el => {
      return el.receivers[0].notificationReceiverType === AddressBookConst.partyType.RECIPIENT;
    });
    return recipient[0].receivers[0].medias[0].emailAddresses[0].address;
  }

  fedexAddressChange(currentValue, fedexAddressFormData) {
    /**
     * detect if there are any changes in the form which are not matching with fedex address data
     * return true for no changes and false if the data in address form is changed
     */
    if (currentValue && fedexAddressFormData) {
      const aProps = Object.getOwnPropertyNames(fedexAddressFormData);
      let same = true;
      for (let i = 0; i < aProps.length; i++) {
        const propName = aProps[i];
        if (this._fedexAB.emptyForNull(fedexAddressFormData[propName]).toLowerCase()
          !== this._fedexAB.emptyForNull(currentValue[propName]).toLowerCase()) {
          same = false;
        }
      }
      this.hideSaveAddrBtnForSameData.emit(same);
    }
  }

  setFedexEmail(data) {
    /**
     * set fedex email from to fedexaddress form data
     */
    if (this.fedexAddressFormData) {
      this.fedexAddressFormData.e = data;
    }
  }

  setfedexAddressBody(data, countryname) {
    /**
     * create form object to store data from address book API response
     * form object is complaince with addressform control
     */
    this.fedexAddressFormData = {
      cNme: data.contact.companyName.name,
      cPsn: this._fedexAB.emptyForNull(data.contact.personName.fullName),
      cd: this._fedexAB.emptyForNull(data.address.countryCode),
      l1: this._fedexAB.emptyForNull(data.address.streetLines[AddressBookConst.ADDR_LINE1_POS]),
      l2: this._fedexAB.emptyForNull(data.address.streetLines[AddressBookConst.ADDR_LINE2_POS]),
      cntry: countryname,
      pCd: this._fedexAB.emptyForNull(data.address.postalCode),
      cty: this._fedexAB.emptyForNull(data.address.city),
      tel: this._fedexAB.emptyForNull(this.getPhoneNumber(data.contact.phoneNumberDetails)),
      e: '',
      pIn: this._fedexAB.emptyForNull(data.deliveryInstructions)
    }
  }

  getPhoneNumber(data) {
    /**
     * return phone number from get contact address API
     * if number not there then return null value
     */
    return data.find((el) => {
      if (el.number.hasOwnProperty('localNumber')) {
        return el;
      } else {
        el['number']['localNumber'] = null;
        return el;
      }
    }).number.localNumber;
  }

  resetAllData() {
    /**
     * reset all data
     */
    this.FedExAddressSearchType = AddressBookConst.SearchType;
    this.results = 0;
    this.fedexAddress = [];
    this.searchTitle = '';
    this.apiErrorMessage = '';
    this.fedexAddressSearchForm.reset();
  }

  lastElement(index, array) {
    /**
     * return true when the element of the given array is in the last index / position
     */
    return (index === array.length - 1) ? true : false;
  }

  checkFedeExAddress(value: string) {
    /**
     * to check the address in the form is from the fedex address book or from google
     * return true if all data in address form is matching with fedex address book
     */

    if (value && value.length > 1) {
      this._fedexAB.searchAddressBook(value, [AddressBookConst.bookType.PERSONAL]).subscribe(result => {
        const res = this.mapAddress(result['output'].contact, this.addrFormValue);
        if (res.length) {
          res.length === 1 ? this.setEmittedAddress(res[0]) : this.deepMapFork(res, this.addrFormValue);
        }
      }, error => { });
    }
  }

  compareAddr(el, formValue) {
    /**
     * compare address data in the form with respect to fedex address response
     */
    interface FedexAddr {
      cNme: string,
      l1: string,
      cd: string,
      pCd: string,
      cty: string,
      tel: string,
      cPsn: string,
    }
    const tmpAddr1: FedexAddr = {
      cNme: el.companyName,
      l1: el.address.streetLines[AddressBookConst.ADDR_LINE1_POS],
      cd: el.address.countryCode,
      pCd: el.address.postalCode,
      cty: el.address.city,
      tel: el.phoneNumber,
      cPsn: el.contactName
    };

    const tmpAddr2: FedexAddr = {
      cNme: formValue.cNme['_value'],
      l1: formValue.l1['_value'],
      cd: formValue.cd['_value'],
      pCd: formValue.pCd['_value'],
      cty: formValue.cty['_value'],
      tel: formValue.tel['_value'],
      cPsn: formValue.cPsn['_value'],
    };

    return this._shrdFn.isObjectsEquivalent(tmpAddr1, tmpAddr2);
  }

  mapAddress(serviceValue: Array<FedExAddressResponseDTO>, formValue: AddressFormData) {
    /**
     * check data from response data
     * if data from response array exactly matches with address form data then return type is object
     * if no data matches, the return type is undefined
     */
    return serviceValue.filter((el) => {
      return this.compareAddr(el, formValue);
    });
  }

  setEmittedAddress(val: FedExAddressResponseDTO) {
    /**
     * Emit address Object and set fedexaddressbook to true
     */
    val.SEARCHING_TYPE = AddressBookConst.SEARCHING_TYPE_INIT;
    this.addressObject.emit(val);
    this.fromFedexAddressBook.emit(true);
  }

  deepMapFork(data: Array<FedExAddressResponseDTO>, formValue: AddressFormData) {
    /**
     * if addressline 2 value is present and email id is present
     * if above condition is satisfied emit address data and set fedexaddress to true
     */
    if (formValue.l2['_value'] && formValue.e['_value']) {
      data.filter((el) => {
        this._fedexAB.getAddressAndEmailByContactID(el.contactID).subscribe(response => {
          const eml = this.getFedexEmailfromAPI(response[0]),
            l2 = response[1]['output']['partyInfoVO']['party']['address'].streetLines[AddressBookConst.ADDR_LINE2_POS];
          if (this.checkEmailandAddrLn2(eml, l2, formValue)) {
            this.setEmittedAddress(el);
          }
        });
      });
    }
  }

  checkEmailandAddrLn2(email: string, addressLine: string, formValue: AddressFormData) {
    /**
     * return true if email address from fedex address API is matching with email in the address form and
     * line 2 of address from fedex address API is matching with line 2 in the address form
     */
    return (formValue.l2['_value'] === addressLine && formValue.e['_value'] === email)
  }

  /*deepMapAddress(filterVal: Array<FedExAddressResponseDTO>, formValue: AddressFormData) {
    // below is temporary solutions
    for (const el of filterVal) {
      if (this._fedexAB.emptyForNull(formValue.l2['_value']).trim() 
      && this._fedexAB.emptyForNull(formValue.e['_value']).trim()) {
        const apiName = 'getContactID_' + el.contactID;
        this.subscriptions.push(this.apiSubscription[apiName] = this._fedexAB.getAddressFromContactID(el.contactID).subscribe(data => {
          if (this._fedexAB.emptyForNull(data.output.partyInfoVO.party.address.streetLines[AddressBookConst.ADDR_LINE2_POS]).trim() ===
            this._fedexAB.emptyForNull(formValue.l2['_value']).trim()
        ) {
            const apiNameEmail = 'getEmailID_' + el.contactID;
            this.subscriptions.push(this.apiSubscription[apiNameEmail] =
              this._fedexAB.getContactEmail(data.output.partyInfoVO.party.contact.contactId).subscribe(email => {
                const fdxEmial = this.getFedexEmailfromAPI(email)
                if (fdxEmial === this._fedexAB.emptyForNull(formValue.e['_value']).trim()) {
                  this.setEmittedAddress(el);
                  this.apiUnsubscribe(apiName);
                  this.apiUnsubscribe(apiNameEmail);
                }
              }, error => { }));
          }
        }, error => { }));
      } else if
        (!this._fedexAB.emptyForNull(formValue.l2['_value']).trim() 
        && this._fedexAB.emptyForNull(formValue.e['_value']).trim()) {
        const apiNameEmail = 'getEmailID_' + el.contactID;
        this.subscriptions.push(this.apiSubscription[apiNameEmail] =
          this._fedexAB.getContactEmail(el.contactID).subscribe(data => {
            const fdxEmial = this.getFedexEmailfromAPI(data);
            if (this._fedexAB.emptyForNull(fdxEmial).trim() === this._fedexAB.emptyForNull(formValue.e['_value']).trim()) {
              this.setEmittedAddress(el);
              this.apiUnsubscribe(apiNameEmail);
            }
          }, error => { }));
      } else if (this._fedexAB.emptyForNull(formValue.l2['_value']).trim() &&
        !this._fedexAB.emptyForNull(formValue.e['_value']).trim()) {
        const apiName = 'getContactID_' + el.contactID;
        this.subscriptions.push(this.apiSubscription[apiName] = this._fedexAB.getAddressFromContactID(el.contactID).subscribe(data => {
          if (this._fedexAB.emptyForNull(data.output.partyInfoVO.party.address.streetLines[AddressBookConst.ADDR_LINE2_POS]).trim() ===
            this._fedexAB.emptyForNull(formValue.l2['_value']).trim()
          ) {
            this.setEmittedAddress(el);
            this.apiUnsubscribe(apiName);
            }
        }, error => { }));
      }
  }
  } */

}
