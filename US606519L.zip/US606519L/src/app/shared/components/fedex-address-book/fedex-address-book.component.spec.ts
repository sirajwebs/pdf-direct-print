/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved *copyright* Fedex 2018
 *
 * Typescript code in this page
 */
import { ChangeDetectorRef, DebugElement } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpModule } from '@angular/http';
import { By } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { JsEncoderService } from './../../../services/js-encoder.service';
import { FedexAddressBookComponent } from './fedex-address-book.component';
import { FedexAddressbookService } from './../../../services/fedex-addressbook.service';
import { AddressBookDTO, AddressComponentDTO, FedExAddressResponseDTO, AddressSearchDTO,
  GetAddressByContactID, AddressFormData, AddressCopyData
} from './../../models/addressbook.models';
import { of } from 'rxjs/observable/of';
import { Observable } from 'rxjs/Observable';
describe('FedexAddressBookComponent', () => {
  let component: FedexAddressBookComponent;
  let fixture: ComponentFixture<FedexAddressBookComponent>;
  let service: FedexAddressbookService;
  let debugele: DebugElement;
  let csd;
  const inVal = 'tnt';
  const block = 0;
  const viewBlock = true;
  const addressBook = [{
    'contactName': 'fhgfhgfh ', 'nickName': 'Test2',
    'companyName': 'TNT Express', 'address': {
      'streetLines': ['45, Sky Road'],
      'city': 'Melbourne Airport', 'postalCode': '3045', 'countryCode': 'AU', 'residential': !0
    }, 'phoneNumber': '6765765765', 'addressType': 'RECIPIENT',
    'addressBookType': 'PERSONAL', 'contactID': 95074050
  }, {
    'contactName': 'gfdgfgfd ', 'nickName': 'Test5', 'companyName': 'TNT Taqueria',
      'address': {
        'streetLines': ['2114, North 45th Street'], 'city': 'Seattle',
        'postalCode': '98103', 'countryCode': 'US', 'residential': !0
      }, 'phoneNumber': '656456546', 'addressType': 'RECIPIENT', 'addressBookType': 'PERSONAL', 'contactID': 95074679
    }, {
      'contactName': 'gfdgfgfd ', 'nickName': 'Test1', 'companyName': 'TNT Taqueria',
      'address': {
        'streetLines': ['2114, North 45th Street'], 'city': 'Seattle',
        'postalCode': '98103', 'countryCode': 'US', 'residential': !0
      }, 'phoneNumber': '656456546', 'addressType': 'RECIPIENT', 'addressBookType': 'PERSONAL', 'contactID': 95074049
    }, {
      'contactName': 'jason gold', 'nickName': 'jason gold', 'companyName': 'TNT united',
      'address': {
        'streetLines': ['No 10 st paul street'], 'city': 'Longmont',
        'postalCode': '80502', 'countryCode': 'US', 'residential': !0
      }, 'phoneNumber': '9876543210', 'addressType': 'RECIPIENT', 'addressBookType': 'CENTRAL', 'contactID': 95075952
    }]
  const addressBook2 = [
    {
      'contactName': 'fhgfhgfh ', 'nickName': 'Test2',
      'companyName': 'TNT Express', 'address': {
        'streetLines': ['45, Sky Road'],
        'city': 'Melbourne Airport', 'postalCode': '3045', 'countryCode': 'AU', 'residential': !0
      }, 'phoneNumber': '6765765765', 'addressType': 'RECIPIENT',
      'addressBookType': 'PERSONAL', 'contactID': 95074050
    }, {
      'contactName': 'gfdgfgfd ', 'nickName': 'Test5', 'companyName': 'TNT Taqueria',
        'address': {
          'streetLines': ['2114, North 45th Street'], 'city': 'Seattle',
          'postalCode': '98103', 'countryCode': 'US', 'residential': !0
        }, 'phoneNumber': '656456546', 'addressType': 'RECIPIENT', 'addressBookType': 'PERSONAL', 'contactID': 95074679
      }, {
        'contactName': 'gfdgfgfd ', 'nickName': 'Test1', 'companyName': 'TNT Taqueria',
        'address': {
          'streetLines': ['2114, North 45th Street'], 'city': 'Seattle',
          'postalCode': '98103', 'countryCode': 'US', 'residential': !0
        }, 'phoneNumber': '656456546', 'addressType': 'RECIPIENT', 'addressBookType': 'PERSONAL', 'contactID': 95074049
      }, {
        'contactName': 'jason gold', 'nickName': 'jason gold', 'companyName': 'TNT united',
        'address': {
          'streetLines': ['No 10 st paul street'], 'city': 'Longmont',
          'postalCode': '80502', 'countryCode': 'US', 'residential': !0
        }, 'phoneNumber': '9876543210', 'addressType': 'RECIPIENT', 'addressBookType': 'CENTRAL', 'contactID': 95075952
    },
    {
      'contactName': 'jacob gold', 'nickName': 'jacob gold', 'companyName': 'TNT united',
      'address': {
        'streetLines': ['No 10 st paul street'], 'city': 'Longmont',
        'postalCode': '80502', 'countryCode': 'US', 'residential': !0
      }, 'phoneNumber': '9876243210', 'addressType': 'RECIPIENT', 'addressBookType': 'CENTRAL', 'contactID': 95575952
    },
    {
      'contactName': 'mac gold', 'nickName': 'mac gold', 'companyName': 'TNT united',
      'address': {
        'streetLines': ['No 10 st paul street'], 'city': 'Longmont',
        'postalCode': '80502', 'countryCode': 'US', 'residential': !0
      }, 'phoneNumber': '9876243210', 'addressType': 'RECIPIENT', 'addressBookType': 'CENTRAL', 'contactID': 95574952
  }
  ]
  const ID = 1;
  const InputValue = 'TNT';
  const isFedexData = false;
  const InputBlock = 0;
  const contactID = 95079555;
  const contactID2 = 95074303;
  const data = {
    'transactionId': 'aaaaaaa-aaaaaa-aaaa-aaaa-aaaaaaaaaaaa',
    'output': {
      'shipPartyPreference': {
        'contactId': 95079555, 'brokerDetail': {
          'broker': { 'accountNumber': {}, 'tins': [{}] }
        }, 'notifications': [{
          'receivers': [{
            'notificationReceiverType': 'SHIPPER',
            'medias': []
          }], 'events': []
        }, {
          'receivers': [{
            'notificationReceiverType': 'RECIPIENT',
            'medias': [{ 'emailAddresses': [{ 'address': 'ghgf@e.com', 'permissions': {} }] }]
          }], 'events': []
          }]
      }
    }
  };
  const data2 = { 'transactionId': '7091e250-ad0e-4e0e-b714-594e2a7b87db', 'output': {} };
  const countryData: GetAddressByContactID = {
   'contact': {
      'contactId': 95079555, 'nickName': 'sdsadsa',
      'personName': { 'firstName': 'dfdsf', 'lastName':'','fullName': 'dfdsf' },
      'phoneNumberDetails': [{ 'number': { 'localNumber': 54654654 } }], 'companyName': { 'name': 'TNT Taqueria' }
    }, 'address': {
      'streetLines': ['2114, North 45th Street'], 'city': 'Seattle',
      'postalCode': '98103', 'countryCode': 'US', 'residential': true
    }, 'deliveryInstructions': 'fdfdsf'
  };
  const countryName = 'United States';
  const addressBookData = {'name':'TNT Taqueria','types':['establishment'],
    'address_components': [{
      'long_name': '2114, North 45th Street',
      'short_name': '2114, North 45th Street', 'types': ['street_number']
    }, { 'long_name': '', 'short_name': '', 'types': ['addressbook_addrLine2'] },
      { 'long_name': 'United States', 'short_name': 'US', 'types': ['country'] },
      { 'long_name': '98103', 'short_name': '98103', 'types': ['postal_code'] },
      { 'long_name': 'Seattle', 'short_name': 'Seattle', 'types': ['locality'] }]
  }
  const phNumber = [{'number': {'localNumber': '54654654'}, 'permissions': {}}, { 'type': 'FAX', 'number': {}, 'permissions': {}}]
  const phNumberWithNodata = [{'number': {}, 'permissions': {}}, {'type': 'FAX', 'number': {}, 'permissions': {}}]
  const AddressBody = {
    'tins': [], 'contact': {
      'contactId': 95079555, 'nickName': 'sdsadsa',
      'personName': { 'firstName': 'dfdsf', 'fullName': 'dfdsf' },
      'phoneNumberDetails': [{ 'number': { 'localNumber': '54654654' }, 'permissions': {} },
      { 'type': 'FAX', 'number': {}, 'permissions': {} }], 'companyName': { 'name': 'TNT Taqueria' }
    }, 'address': {
      'streetLines': ['2114, North 45th Street'], 'city': 'Seattle',
      'postalCode': '98103', 'countryCode': 'US', 'residential': true
    }, 'deliveryInstructions': 'fdfdsf'
  };
  const addressBodyFormatted = {
    'cNme': 'TNT Taqueria', 'cPsn': 'dfdsf', 'cd': 'US',
    'l1': '2114, North 45th Street', 'l2': '', 'cntry': 'United States',
    'pCd': '98103', 'cty': 'Seattle', 'tel': '54654654', 'e': '', 'pIn': 'fdfdsf'
  }
  const currentValue = {
    'cNme': 'TNT Taqueria', 'cPsn': 'gfdgfgfd', 'cd': 'US', 'l1': '2114, North 45th Street', 'l2': '',
    'cntry': 'United States', 'pCd': '98103', 'cty': 'Seattle', 'tel': '656456546',
    'e': 'fgfdg@w.com', 'pIn': 'bcvbvcbv'
  }
  const currentValue2 = {
    'cNme': 'TNT Taqueria dm', 'cPsn': 'gfdgfgfd', 'cd': 'US', 'l1': '2114, North 45th Street', 'l2': '',
    'cntry': 'United States', 'pCd': '98103', 'cty': 'Seattle', 'tel': '656456546',
    'e': 'fgfdg@w.com', 'pIn': 'bcvbvcbv'
  }
  const formData = {
    'cNme': 'TNT Taqueria', 'cPsn': 'gfdgfgfd',
    'cd': 'US', 'l1': '2114, North 45th Street', 'l2': '', 'cntry': 'United States',
    'pCd': '98103', 'cty': 'Seattle', 'tel': '656456546', 'e': 'fgfdg@w.com', 'pIn': 'bcvbvcbv'
  }
  const setResultData = [{
    'contactName': 'cv', 'nickName': '@@##', 'companyName': 'TNT',
    'address': {
      'streetLines': ['C V Raman Nagar'], 'city': 'Bangalore', 'postalCode': '560093',
      'countryCode': 'IN', 'residential': false
    }, 'phoneNumber': '9876543210',
  },
    {
      'contactName': 'john larke', 'nickName': 'abc6', 'companyName': 'TNT Auto Salvage',
      'address': {
        'streetLines': ['6334, West Gowen Road'], 'city': 'Boise', 'postalCode': '83709',
        'countryCode': 'US', 'residential': true
      }, 'phoneNumber': '333357',
    }]
  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [FedexAddressBookComponent],
      imports: [HttpModule, FormsModule,
        ReactiveFormsModule],
      providers: [
        JsEncoderService,
        ChangeDetectorRef,
        FedexAddressbookService
      ]
    }).compileComponents();
    fixture = TestBed.createComponent(FedexAddressBookComponent);
    component = fixture.componentInstance;
    debugele = fixture.debugElement;
    service = TestBed.get(FedexAddressbookService);
    component.searchValue = of('tnt');
    spyOn(component.emitEmailAddress, 'emit');
    spyOn(component.hideSaveAddrBtnForSameData, 'emit');
    spyOn(component, 'apiUnsubscribe');

  })
  it('should create component', () => {
    expect(component).toBeDefined();
  });
  it('should call searchTypeChange on intiation', async(() => {
    spyOn(component, 'searchTypeChange');
    spyOn(component, 'searchValue').and.returnValue(Observable.of('tnt'));
    
    component.ngOnInit();
    fixture.detectChanges();
    expect(component.searchTypeChange).toHaveBeenCalledWith('ONINIT');
  }))
  it('Should return false in case of null input value', () => {
    let companyInName = 'TNT';
    component.setGoogleLikefedexAddress(inVal, block, viewBlock, addressBook);
    expect(companyInName).toEqual('TNT');
  })
  it('Should return false in case of null input value', () => {
    const setfedexAddressWthFalse = component.setGoogleLikefedexAddress('', block, viewBlock, addressBook);
    expect(setfedexAddressWthFalse).toEqual(false);
  })
  it('removeChildElements has to be called on search input', () => {
    spyOn(component, 'removeChildElements');
    component.setGoogleLikefedexAddress(inVal, block, viewBlock, addressBook);
    expect(component.removeChildElements).toHaveBeenCalled();
  });
  it('Should call fedexWithGoogleAutoComplete on key up', () => {
    // component.setGoogleLikefedexAddress(inVal, block, viewBlock, addressBook);
    // fixture.detectChanges();
    // let input = fixture.debugElement.query(By.css('.address-search input')).nativeElement;
    // input.dispatchEvent(new Event('click'));
    // fixture.whenStable().then(() => {
    //   expect(component.fedexWithGoogleAutoComplete).toHaveBeenCalled();
    // });
    spyOn(component, 'fedexWithGoogleAutoComplete');
    fixture.detectChanges();
    component.fedexWithGoogleAutoComplete(ID, addressBook, InputValue, isFedexData, InputBlock);
    expect(component.fedexWithGoogleAutoComplete).toBeDefined();
  })
  it('it should call fedexWithGoogleAutoComplete', () => {
    spyOn(component, 'fedexWithGoogleAutoComplete');
    const maxA = 0;
    const FEDEX_ADDR_LIST = 5;
    const companyInNameLength = 3;
    component.setGoogleLikefedexAddress(inVal, block, viewBlock, addressBook);
    expect(companyInNameLength).toBeGreaterThan(1);
    expect(maxA).toBeLessThanOrEqual(FEDEX_ADDR_LIST);
    expect(component.fedexWithGoogleAutoComplete).toHaveBeenCalledTimes(4);
  });
  it('It should call view results if fedexAddressList is greater than FEDEX_ADDR_LIST', () => {
    spyOn(component, 'viewResults');
    spyOn(component, 'fedexWithGoogleAutoComplete');
    fixture.detectChanges();
    const companyInNameLength = 3;
    const FEDEX_ADDR_LIST = 1;
    component.setGoogleLikefedexAddress(inVal, block, viewBlock, addressBook2);
    expect(companyInNameLength).toBeGreaterThan(1);
    expect(addressBook.length).toBeGreaterThan(FEDEX_ADDR_LIST);
    expect(component.viewResults).toHaveBeenCalled();
  });

  it('Result value should be empty if isFedExData is false', () => {
    let resultValue = '';
    spyOn(component, 'fedexWithGoogleAutoComplete');
    fixture.detectChanges();
    component.fedexWithGoogleAutoComplete(ID, addressBook, InputValue, false, InputBlock);
    fixture.detectChanges();
    expect(resultValue).toBe('');
  });

  it('it should set fedexWithGoogleAutoComplete', () => {
    spyOn(component, 'fedexWithGoogleAutoComplete');
    fixture.detectChanges();
    component.fedexWithGoogleAutoComplete(ID, addressBook, InputValue, isFedexData, InputBlock);
    fixture.detectChanges();
    expect(fixture.debugElement.query(By.css('.pac-container'))).toBeDefined();
    expect(fixture.debugElement.query(By.css('.pac-item .FxAB'))).toBeDefined();
    expect(fixture.debugElement.query(By.css('.pac-icon'))).toBeDefined();
  });
  it('it should check if ID is number then set the icon background', () => {
    spyOn(component, 'fedexWithGoogleAutoComplete');
    fixture.detectChanges();
    component.fedexWithGoogleAutoComplete(ID, addressBook, InputValue, isFedexData, InputBlock);
    expect(ID).not.toBeNaN();
  });
  it('it should check pac-item-query span is created or not', () => {
    spyOn(component, 'fedexWithGoogleAutoComplete');
    fixture.detectChanges();
    component.fedexWithGoogleAutoComplete(ID, addressBook, InputValue, isFedexData, InputBlock);
    expect(fixture.debugElement.query(By.css('.pac-item-query'))).toBeDefined();
  });
  it('it should check pac-item-query inner html', () => {
    spyOn(component, 'fedexWithGoogleAutoComplete');
    fixture.detectChanges();
    component.fedexWithGoogleAutoComplete(ID, addressBook, InputValue, isFedexData, InputBlock);
    expect(fixture.debugElement.query(By.css('.pac-item-query span .pac-matched'))).toBeDefined();
  });
  it('should call fetch email id subscription', () => {
    component.getEmailId(contactID,1);
    service.getContactEmail(contactID).subscribe((post) => {
      expect(post).toBeTruthy();
    });
  })
  it('should fetch email id', () => {
    const apiName = 'getEmailId';
    component.getEmailId(contactID,1);
    service.getContactEmail(contactID).subscribe((posts) => {
      expect(posts).toContain(data);
    })
  })
  it('should fetch email id in case of null output', () => {
    component.getEmailId(contactID2,1);
    service.getContactEmail(contactID2).subscribe((posts) => {
      expect(posts).toContain(data2);
    })
  })
  it('should expect shipPartyPreference to be true', () => {
    component.getEmailId(contactID,1);
    service.getContactEmail(contactID).subscribe((posts) => {
      expect(posts.output.shipPartyPreference).toBeTruthy();
    })
  })
  it('should expect recepient', () => {
    let recepientData;
    const recipient  = [{
      'receivers': [{
        'notificationReceiverType': 'RECIPIENT',
        'medias': [{ 'emailAddresses': [{ 'address': 'ghgf@e.com', 'permissions': {} }] }]
      }], 'events': []
    }]
    recepientData = recipient;
    spyOn(service, 'getContactEmail').and.returnValue(of(data))
    component.getEmailId(contactID,1);
      service.getContactEmail(contactID)
      service.getContactEmail(contactID).subscribe((post) => {
      expect(post.output.shipPartyPreference).toBeTruthy();
      expect(recepientData).toBe(recipient);
    })
  })
  it('Set Get email id should emit set email id', () => {
    spyOn(component, 'setFedexEmail');
    component.getEmailId(contactID,1);
    service.getContactEmail(contactID).subscribe((posts) => {
      const nativeElement = fixture.nativeElement;
      const field = nativeElement.querySelector('.pac-item');
      const event = new KeyboardEvent('click');
      field.dispatchEvent(event);
      fixture.detectChanges();
      expect(posts.output.shipPartyPreference).toBeTruthy();
      expect(component.emitEmailAddress.emit).toHaveBeenCalled();
      expect(component.setFedexEmail).toHaveBeenCalled();
    })
  })
  it('Set email id & emit null', () => {
    spyOn(service, 'getContactEmail').and.returnValue(of(data2));
    spyOn(component, 'setFedexEmail');
    component.getEmailId(contactID2,1);
    expect(service.getContactEmail).toHaveBeenCalled();
    expect(component.emitEmailAddress.emit).toHaveBeenCalledWith('');
    expect(component.setFedexEmail).toHaveBeenCalledWith(null);
  });
  it('should check for the getContactEmail error call ', () => {
    spyOn(service, 'getContactEmail').and.returnValue(Observable.throw('error'));
    spyOn(component, 'setFedexEmail');
    component.getEmailId(contactID2,1);
    expect(service.getContactEmail).toHaveBeenCalled();
    expect(component.emitEmailAddress.emit).toHaveBeenCalledWith('');
    expect(component.setFedexEmail).toHaveBeenCalledWith(null);
});
  it('Should add the country data to fedex address', () => {
    const addcountryData = component.addCountryDataToFedexAddress(countryData, countryName);
    expect(addcountryData).toEqual(addressBookData);
  });
  it('Should get Phone Number', () => {
    const numValue = component.getPhoneNumber(phNumber);
    expect(numValue).toEqual('54654654');
  })
  it('Should get Phone Number null when no localnumber is null', () => {
    const numValue = component.getPhoneNumber(phNumberWithNodata);
    expect(numValue).toEqual(null);
  });
  it('should set the fedex address body', () => {
    component.setfedexAddressBody(AddressBody, countryName);
    expect(component.fedexAddressFormData).toEqual(addressBodyFormatted);
  })
  it('should set FedEx Email', () => {
    spyOn(component, 'setFedexEmail');
    fixture.detectChanges();
    component.setfedexAddressBody(AddressBody, countryName);
    component.setFedexEmail('');
    expect(component.setFedexEmail).toBeDefined();
    expect(component.fedexAddressFormData).toBeTruthy();
    expect(component.fedexAddressFormData.e).toEqual('');
  });
  it('It should emit data change fedex address', () => {
    component.fedexAddressChange(currentValue, formData);
    const formDataLength = 5;
    expect(currentValue).toBeTruthy();
    expect(formData).toBeTruthy();
    expect(formDataLength).toEqual(5);
    expect(component.hideSaveAddrBtnForSameData.emit).toHaveBeenCalledWith(true);
  })
  it('Should check fedexAddressFormData and current value equality', () => {
    component.fedexAddressChange(currentValue2, formData);
    const same = false;
    const fedexAddressval = service.emptyForNull(formData.cNme);
    const currval = service.emptyForNull(currentValue2.cNme);
    expect(fedexAddressval).not.toEqual(currval);
    expect(same).toEqual(false);
  });
  it('Should call viewResults', () => {
    fixture.detectChanges();
    spyOn(component, 'setResultValue');
    component.viewResults(0, viewBlock, addressBook2);
    let parentElement = fixture.debugElement.nativeElement.querySelector('.pac-container:nth-child(0)');
    let companyNameDD = fixture.debugElement.nativeElement.querySelector('#pcompanyName');
    companyNameDD.keyup();
    fixture.detectChanges();
    let button = fixture.debugElement.nativeElement.querySelector('.pac-container:nth-child(0) .pac-item:nth-child(4)');
    button.mousedown();
    fixture.detectChanges();
    expect(component.setResultValue).toHaveBeenCalled();
  })
  it('should set result value', () => {
   component.setResultValue(setResultData);
    expect(component.fedexAddress).toBe(setResultData); 
  })
  it('should auto complete value with Company_Name', () => {
    component.fedExAutocomplete('TNT', setResultData, 'Company_Name')
    expect(component.fedExAutocomplete).toBeDefined();
  })
  it('should auto complete value with Nick_Name', () => {
    component.fedExAutocomplete('TNT', setResultData, 'Nick_Name')
    expect(component.fedExAutocomplete).toBeDefined();
  })
  it('should auto complete', () => {
    const autoCompleteCheck = (component as any).autoComplete('TNT' , 'tnt')
    expect(autoCompleteCheck).toBeDefined();
  })
  it('should show address book overlay', () => {
    component.showAddressBookOverlay(0, 'block')
    expect(component.showAddressBookOverlay).toBeDefined();
  })
  it('should show address book overlay', () => {
    component.showAddressBookOverlay(0, 'block')
    expect(component.showAddressBookOverlay).toBeDefined();
  })
  it('should show last element', () => {
    component.lastElement(0, setResultData)
    expect(component.lastElement).toBeDefined();
  })
  it('should remove child elements', () => {
    component.removeChildElements(0)
    expect(component.removeChildElements).toBeDefined();
  })
});
