/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved *copyright* Fedex 2018
 *
 * Typescript code in this page
 */
import { FedexTNT, ConstantsVAR, KeyboardKey, NUMBERS } from '../../constants/constants-var';
import { TextMaskPipe } from '../../pipes/text-mask.pipe';
import { UserAccDetails } from 'app/shared/models/login.models';
import { Component, OnInit, Input, Output, EventEmitter, HostListener, SimpleChanges, OnChanges } from '@angular/core';

@Component({
  selector: 'app-account-dropdown',
  templateUrl: './account-dropdown.component.html',
  styleUrls: ['./account-dropdown.component.css']
})
export class AccountDropdownComponent implements OnInit, OnChanges {

  @Input() usrAccObj: Array<UserAccDetails>;
  @Input() setAcc: string;
  @Output() userObject = new EventEmitter<UserAccDetails>(null);
  hideDropdownInner = true;
  dropdownStart: number;
  dropdownDiv: HTMLElement;
  menuItem: number;
  selectedVal = null;
  account = {
    name: ConstantsVAR.EMPTY_STRING,
    type: ConstantsVAR.EMPTY_STRING
  };

  constructor() {
  }

  @HostListener('document:mousemove')
  onDocMouseMove() {
    this.selectedClass(this.selectedVal);
  }

  @HostListener('mousemove', ['$event'])
  onMouseMove(event) {
    // TODO: need to check for efficiency
    event.stopPropagation();
    this.selectedClass(this.selectedVal);
  }

  @HostListener('document:click')
  OutsideClose() {
    this.hideDropDownFunc();
  }

  @HostListener('click', ['$event'])
  InsideClose(event: MouseEvent) {
    event.stopPropagation();
  }

  @HostListener('document:scroll')
  Outsidescroll() {
  // TODO: use debounce or throttle
    this.hideDropDownFunc();
  }

  /*@HostListener('mousewheel')
  wheelscroll() {
    this.enableScroll();
  }*/

@HostListener('document:mousewheel')
  docWheelscroll() {
    this.enableScroll();
  }

  ngOnInit() { }

  ngOnChanges(changes: SimpleChanges) {
    if (changes) {
      if (changes.setAcc) {
        setTimeout(() => {
          const acc = this.usrAccObj.find(el => el.cusAccId === this.setAcc);
          this.setAccNmAndTyp(acc);
          this.dropdownDiv = this.getmenuElm();
          this.menuItem = (document.getElementsByClassName('multipleContent-value') ) ?
          document.getElementsByClassName('multipleContent-value')[NUMBERS.ZERO].clientHeight : NUMBERS.ZERO;
        }, ConstantsVAR.MILISEC_50);
      }
    }
  }

  showHidedropdown() {
    /**
     * show / hide (toggle) list of accounts based on click
     * if only one account is there in the list then return false
     */
    if (this.usrAccObj.length === 1) { return false; }
    this.selectedVal = null;
    this.hideDropdownInner = !this.hideDropdownInner;
  }

  maskAcc(usrAcc: UserAccDetails) {
    /**
     * mask account id only when user account is TNT
     */
    try {
      const maskedName = new TextMaskPipe().transform(usrAcc.cusAccId);
      return (usrAcc.accTyp === FedexTNT.FDX) ? this.maskFedexAccount(usrAcc) :
        usrAcc.cusAccNm + ConstantsVAR.SNGLE_SPC_STR + maskedName;
    } catch (e) { }
  }

  maskFedexAccount(usrAcc: UserAccDetails): string { // this method will be moved to textmask for generic usage
    /*
     * masked 6 digits before three characters of fedex account number
     * ex: ABC1-326 will be ABC1 ******326
     */
    const fdxUsr = usrAcc.cusAccNm ? usrAcc.cusAccNm.split('-') : ConstantsVAR.EMPTY_STRING;
    return fdxUsr[0] + FedexTNT.FDX_MASK + fdxUsr[1];
  }

  setAccNmAndTyp(usr: UserAccDetails) {
    /**
     * set default account name and type of accounts on loading
     */
    this.account.name = this.maskAcc(usr);
    this.account.type = usr.accTyp;
    document.getElementById('csDrpDwn').focus();
  }

  selectedClass(usr: UserAccDetails) {
    /**
     * apply selection class based on value selected from dropdown or hover on the list of accounts
     */
    return (!this.selectedVal) ? (this.maskAcc(usr) === this.account.name) : (usr.cusAccId === this.selectedVal.cusAccId);

  }

  getUsrValue(val: UserAccDetails) {
    /**
     * emit user object when user clicks any account from the list
     */
    this.userObject.emit(val);
    this.setAccNmAndTyp(val);
    this.showHidedropdown();
  }

  mouseMoveval(val: UserAccDetails) {
    /**
     * apply class for hover element in the account list
     */
    this.selectedVal = val;
  }

  dropDownList(event: KeyboardEvent, val: Array<UserAccDetails>) {
    /**
     * keyboard navigation for dropdown list
     * up arrow key press navigate one list up and emits the user object
     * down arrow key press navigate one list down and emits the user object
     * Enter and Space key toggles the dropdown list
     */
    const evt = event.keyCode;
    this.disableScroll();
    switch (evt) {
      case KeyboardKey.KEY_ARROW_DOWN:
        if (this.dropdownStart === val.length - NUMBERS.ONE) { return false; }
        event.preventDefault();
        (this.dropdownStart === val.length - NUMBERS.ONE) ? this.dropdownStart = val.length - NUMBERS.ONE : this.dropdownStart++;
        this.scrollKey();
        break;
      case KeyboardKey.KEY_ARROW_UP:
        if (this.dropdownStart === NUMBERS.ZERO) { return false; }
        event.preventDefault();
        this.scrollKey();
        (this.dropdownStart === NUMBERS.ZERO) ? this.dropdownStart = NUMBERS.ZERO : this.dropdownStart--;
        break;
      case KeyboardKey.KEY_ENTER:
      case KeyboardKey.KEY_SPACEBAR:
        event.preventDefault();
        this.showHidedropdown();
        break;
      case KeyboardKey.KEY_TAB:
        this.hideDropDownFunc();
        break;
    }
    this.selectedVal = val[this.dropdownStart];
    this.userObject.emit(val[this.dropdownStart]);
    this.setAccNmAndTyp(val[this.dropdownStart]);
  }

  dropDownDefault() {
    /**
     * set index of dropdown / navigation based on the selected account name
     */
    this.dropdownStart = this.usrAccObj.findIndex(x => this.maskAcc(x) === this.account.name);
  }

  hideDropDownFunc() {
    /**
     * hide dropdown if user clicks outside the parent Element when dropdown is shown
     * hide dropdown if user scroll when dropdown is shown
     */
    if (!this.hideDropdownInner) { this.hideDropdownInner = true; }
  }

  setImageClass(acctype: string): string {
    return acctype === FedexTNT.FDX ? 'fdxImg' : 'TntImg';
  }

  disableScroll() {
    const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
    const scrollLeft = window.pageXOffset || document.documentElement.scrollLeft;
    window.onscroll = () => window.scrollTo(scrollLeft, scrollTop);
  }

  enableScroll() {
    window.onscroll = () => { };
  }

  scrollKey() {
    if (this.hideDropdownInner) {return false; }
    const top = this.dropdownDiv.scrollTop;
    if (top !== 0) {
      this.dropdownDiv.scrollTo(NUMBERS.ZERO, (top - this.menuItem));
    }
    if ((this.dropdownStart + NUMBERS.ONE) * this.menuItem > this.dropdownDiv.offsetHeight) {
      this.dropdownDiv.scrollTo(NUMBERS.ZERO, (top + this.menuItem));
  }
}

  getmenuElm(): HTMLElement {
    return document.getElementById('content-div');
  }

}
