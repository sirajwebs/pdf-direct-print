
/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved *copyright* FedEx 2018
 *
 * Typescript code in this page
 */
import { Directive, ElementRef, HostListener, Input } from '@angular/core';
import { KEYCODE } from '../constants/constants-var';

@Directive({
  selector: '[appAllowNumber]'
})
export class AllowNumberDirective {
  @Input() allowNumber: boolean;
  constructor(private el: ElementRef) { }

  @HostListener('keydown', ['$event']) onKeyDown(event) {
    const e = <KeyboardEvent>event;
      if ([KEYCODE._46, KEYCODE._8, KEYCODE._9, KEYCODE._27, KEYCODE._13].indexOf(e.keyCode) !== -1 ||
        // Allow: Ctrl+A
        (e.keyCode === KEYCODE._65 && e.ctrlKey === true) ||
        // Allow: Ctrl+C
        (e.keyCode === KEYCODE._67 && e.ctrlKey === true) ||
        // Allow: Ctrl+X
        (e.keyCode === KEYCODE._88 && e.ctrlKey === true) ||
        // Allow: home, end, left, right
        (e.keyCode >= KEYCODE._35 && e.keyCode <= KEYCODE._39)) {
        // let it happen, don't do anything
        return;
      }
      // Ensure that it is a number and stop the keypress
      if ((e.shiftKey || (e.keyCode < KEYCODE._48 || e.keyCode > KEYCODE._57)) && (e.keyCode < KEYCODE._96 || e.keyCode > KEYCODE._105)) {
        e.preventDefault();
      }
    }
}

