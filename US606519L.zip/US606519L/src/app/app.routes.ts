/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved *copyright* FedEx 2018
 *
 * Typescript code in this page
 */
import { PrintComponent } from './shared/components/print/print.component';
import { RouterGuardService } from './services/router-guard.service';
import { LoginComponent } from './components/login/login.component';
import { SupportComponent } from './components/support/support.component';
import { RouterModule, Routes } from '@angular/router';

/**
 * URL and routing navigation for components
 * 'canActivate' is the router guard
 */
export const routes: Routes = [
    {
        path: '',
        redirectTo: 'login',
        pathMatch: 'full'
    },
    {
        path: 'login',
        component: LoginComponent
    },
    {
        path: 'print',
        component: PrintComponent,
        canActivate: [RouterGuardService]
    },
    {
        path: 'support',
        component: SupportComponent,
        canActivate: [RouterGuardService]
    },
    {
        path: 'booking',
        loadChildren: './booking/booking.module#BookingModule',
        canActivate: [RouterGuardService]
    },
    {
        path: '**',
        redirectTo: 'login',
        pathMatch: 'full'
    },
];

export const routing = RouterModule.forRoot(routes, { useHash: true });

export class RouteView { }
