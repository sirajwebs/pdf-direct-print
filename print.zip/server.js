const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');

const PORT = process.env.PORT || 5000;
const DIST_FOLDER = path.join(process.cwd(), 'dist');

// Express server
const app = express();

// Parsers for POST data
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));

app.use(express.static(path.join(DIST_FOLDER, 'sail-frontend')));

// All regular routes use the Universal engine
app.get('*', (req, res) => {
  res.sendFile(path.join(DIST_FOLDER, 'sail-frontend/index.html'));
});

app.listen(PORT, () => {
  console.log(`Frontend running on http://localhost:${PORT}`);
});
