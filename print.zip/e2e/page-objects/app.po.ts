import { $, browser } from 'protractor';

export class AppPage {
  button = $('#do-something-btn');
  welcomeBox = $('#welcome-box');

  async navigateTo() {
    await browser.get(`${browser.baseUrl}/create-shipment`);
  }
}
