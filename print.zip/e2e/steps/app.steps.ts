import { Given, Then, When } from 'cucumber';
import { expect } from 'chai';

import { AppPage } from '../page-objects/app.po';

const page = new AppPage();

Given('I have navigated to the main page', async () => {
  await page.navigateTo();
});

When('I click the button', async () => {
  await page.button.click();
});

Then('it should show the welcome message', async () => {
  expect(await page.button.isPresent()).to.equal(true);
});
