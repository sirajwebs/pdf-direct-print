import { After, Status } from 'cucumber';
import { browser } from 'protractor';

After(function(testCase) {
    const me = this;
    if (testCase.result.status === Status.FAILED) {
        return browser.takeScreenshot().then((screenshot) => {
            return me.attach(screenshot, 'image/png');
        });
    }
    return;
});
