import { setDefaultTimeout } from 'cucumber';

setDefaultTimeout(60_000);
