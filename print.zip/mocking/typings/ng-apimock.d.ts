declare module 'ng-apimock' {
    var ngApiMock: any;

    export = ngApiMock;
}
