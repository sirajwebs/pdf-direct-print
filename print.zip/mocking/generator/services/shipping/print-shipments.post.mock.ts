import { HttpStatusCode, MethodType, MockResponses } from '../../ng-apimock/models/ng-apimock.model';
import { NgApimockTemplate } from '../../ng-apimock/templates/ng-apimock.template';

const responses: MockResponses = {
  default: {
    default: true,
    status: HttpStatusCode.OK
  },
  error: {
    status: HttpStatusCode.BAD_REQUEST
  }
};

export default NgApimockTemplate(
  'agent/print',
  MethodType.POST,
  'printShipments',
  responses
);
