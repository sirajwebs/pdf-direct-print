import { HttpStatusCode, MethodType, MockResponses } from '../../ng-apimock/models/ng-apimock.model';
import { NgApimockTemplate } from '../../ng-apimock/templates/ng-apimock.template';
const responses: MockResponses = {
  default: {
    default: true,
    status: HttpStatusCode.OK,
    data: [
      {
        'id': 'string',
        'shipmentStatus': 'PENDING',
        'accountNumber': 'string',
        'customerReference': 'UN3343',
        'shipmentInformation': {
          'from': {
            'contact': {
              'name': 'Marcel Knoppe',
              'companyName': 'FedEx Express Digital International',
              'telephoneNumber': '0031883939000',
              'email': 'string',
              'customsId': 'string'
            },
            'address': {
              'city': 'HOOFDDORP',
              'postalCode': '2132LR',
              'countryCode': 'NL',
              'residential': false,
              'streetLines': [
                'FedEx Express Digital International',
                'Scorpius 201'
              ]
            }
          },
          'to': {
            'contact': {
              'name': 'Marcel Knoppe',
              'companyName': 'FedEx Express Digital International',
              'telephoneNumber': '0031883939000',
              'email': 'string',
              'customsId': 'string'
            },
            'address': {
              'city': 'HOOFDDORP',
              'postalCode': '2132LR',
              'countryCode': 'NL',
              'residential': false,
              'streetLines': [
                'FedEx Express Digital International',
                'Scorpius 201'
              ]
            }
          },
          'shipmentDocuments': {
            'purpose': 'string',
            'description': 'string',
            'customsValue': {
              'amount': '5',
              'currency': 'EUR'
            }
          },
          'carriageValue': {
            'amount': '5',
            'currency': 'EUR'
          },
          'packageDetails': [
            {
              'packageType': 'string',
              'packagesAmount': 0,
              'weight': {
                'amount': 'string',
                'unit': 'string'
              },
              'dimensions': {
                'height': '31',
                'length': '28',
                'units': 'CM',
                'width': '4'
              }
            }
          ],
          'pickupDropOff': {
            'shipDate': 'string',
            'service': 'string',
            'readyTime': 'string',
            'latestTime': 'string',
            'instructions': 'string',
            'alternativeAddress': {
              'contact': {
                'name': 'Marcel Knoppe',
                'companyName': 'FedEx Express Digital International',
                'telephoneNumber': '0031883939000',
                'email': 'string',
                'customsId': 'string'
              },
              'address': {
                'city': 'HOOFDDORP',
                'postalCode': '2132LR',
                'countryCode': 'NL',
                'residential': false,
                'streetLines': [
                  'FedEx Express Digital International',
                  'Scorpius 201'
                ]
              }
            },
            'pickupDropOffType': 'string'
          }
        },
        'transactionId': 'RE3432SAD'
      },
      {
        'id': 'string',
        'shipmentStatus': 'PENDING',
        'accountNumber': 'string',
        'customerReference': 'ASD32322',
        'shipmentInformation': {
          'from': {
            'contact': {
              'name': 'Marcel Knoppe',
              'companyName': 'FedEx Express Digital International',
              'telephoneNumber': '0031883939000',
              'email': 'string',
              'customsId': 'string'
            },
            'address': {
              'city': 'HOOFDDORP',
              'postalCode': '2132LR',
              'countryCode': 'NL',
              'residential': false,
              'streetLines': [
                'FedEx Express Digital International',
                'Scorpius 201'
              ]
            }
          },
          'to': {
            'contact': {
              'name': 'Marcel Knoppe',
              'companyName': 'FedEx Express Digital International',
              'telephoneNumber': '0031883939000',
              'email': 'string',
              'customsId': 'string'
            },
            'address': {
              'city': 'HOOFDDORP',
              'postalCode': '2132LR',
              'countryCode': 'NL',
              'residential': false,
              'streetLines': [
                'FedEx Express Digital International',
                'Scorpius 201'
              ]
            }
          },
          'shipmentDocuments': {
            'purpose': 'string',
            'description': 'string',
            'customsValue': {
              'amount': '5',
              'currency': 'EUR'
            }
          },
          'carriageValue': {
            'amount': '5',
            'currency': 'EUR'
          },
          'packageDetails': [
            {
              'packageType': 'string',
              'packagesAmount': 0,
              'weight': {
                'amount': 'string',
                'unit': 'string'
              },
              'dimensions': {
                'height': '31',
                'length': '28',
                'units': 'CM',
                'width': '4'
              }
            }
          ],
          'pickupDropOff': {
            'shipDate': 'string',
            'service': 'string',
            'readyTime': 'string',
            'latestTime': 'string',
            'instructions': 'string',
            'alternativeAddress': {
              'contact': {
                'name': 'Marcel Knoppe',
                'companyName': 'FedEx Express Digital International',
                'telephoneNumber': '0031883939000',
                'email': 'string',
                'customsId': 'string'
              },
              'address': {
                'city': 'HOOFDDORP',
                'postalCode': '2132LR',
                'countryCode': 'NL',
                'residential': false,
                'streetLines': [
                  'FedEx Express Digital International',
                  'Scorpius 201'
                ]
              }
            },
            'pickupDropOffType': 'string'
          }
        },
        'transactionId': 'TR3242W'
      }
    ],
  },
  empty: {
    status: HttpStatusCode.OK,
    data: []
  },
  error: {
    status: HttpStatusCode.BAD_REQUEST
  }
};

export default NgApimockTemplate(
  'shipments',
  MethodType.GET,
  'getShipments',
  responses
);
