import { watch } from 'chokidar';
import * as cors from 'cors';
import * as express from 'express';
import * as apimock from '@ng-apimock/core';
import { generateMocks, generatedMocksPath } from './generator';

// tslint:disable:no-var-requires no-require-imports

import serveStatic = require('serve-static');
const devInterface = require('@ng-apimock/dev-interface');

const mockPort = 5554;

generateMocks();

const watcher = watch(`${__dirname}/**/*`);
watcher.on('change', (file: string) => {
  delete require.cache[require.resolve(file)];
  generateMocks();
});

// Process the application mocks
(apimock as any).processor.process({ src: generatedMocksPath });

const app = express();
// Use the ng-apimock middelware
app.use((apimock as any).middleware);
app.use('/dev-interface/', serveStatic(devInterface));
app.use(cors());

app.listen(mockPort, (error: any) => {
  if (!error) {
    console.info(`Ng-Apimock running on port ${String(mockPort)}`);
    console.info(`Ng-Apimock interface running on http://localhost:${String(mockPort)}/dev-interface`);
  }
});
