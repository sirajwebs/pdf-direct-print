export enum Currency {
    EUR = 'EUR'
}
