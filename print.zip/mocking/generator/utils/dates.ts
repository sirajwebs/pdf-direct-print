import * as moment from 'moment';

const dateFormat = 'YYYY-MM-DD';

export function todayMinus(days: number) {
  return moment().subtract({ days: days }).format(dateFormat);
}

export function tomorrow() {
  return moment().add({ days: 1 }).format(dateFormat);
}

export function today() {
  return moment().format(dateFormat);
}

export function yesterday() {
  return moment().subtract({ days: 1 }).format(dateFormat);
}

export function todayMinusTwo() {
  return todayMinus(2);
}

export function todayMinusFour() {
  return todayMinus(4);
}

export function todayMinusSix() {
  return todayMinus(6);
}
