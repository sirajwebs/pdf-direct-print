import { NgApimock, MethodType, MockResponses } from '../models/ng-apimock.model';

export function NgApimockTemplate(expression: string,
  method: MethodType,
  name: string,
  responses: MockResponses
): NgApimock {
  const firstResponseKey = Object.keys(responses)[0];

  return {
    name,
    request: {
      url: expression,
      method: method
    },
    isArray: Array.isArray(responses[firstResponseKey].data),
    responses
  };
}
