import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ServiceWorkerModule } from '@angular/service-worker';

import { ToastrModule } from 'ngx-toastr';

import { ConfigurationModule } from '@shared/configuration';
import { InternationalizationModule } from '@shared/i18n/i18n.module';
import { LayoutModule } from '@shared/components/layout/layout.module';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { environment } from '../environments/environment';
import { ToastComponent } from './shared/components/toast/toast.component';

@NgModule({
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    HttpClientModule,
    ServiceWorkerModule.register('ngsw-worker.js', { enabled: environment.production }),
    ToastrModule.forRoot({
      toastComponent: ToastComponent,
      timeOut: 3000,
      positionClass: 'sail-toast-container',
      tapToDismiss: false,
      preventDuplicates: true,
    }),
    ConfigurationModule,
    InternationalizationModule,
    LayoutModule
  ],
  declarations: [
    AppComponent,
    ToastComponent,
  ],
  entryComponents: [
    ToastComponent
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
