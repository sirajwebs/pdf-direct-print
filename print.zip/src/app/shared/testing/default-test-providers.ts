import { Provider } from '@angular/core';

import { Configuration } from '@shared/configuration';
import { environment } from 'environments/environment';
import { ShippingConfiguration } from '@shared/configuration/shipping-configuration.model';

const CONFIGURATION_PROVIDERS = [
  {
    provide: Configuration,
    useValue: environment.configuration
  },
  {
    provide: ShippingConfiguration,
    deps: [Configuration],
    useFactory: (configuration: Configuration) => configuration.shipping
  }
];

export const DEFAULT_TEST_PROVIDERS: Provider[] = [
  ...CONFIGURATION_PROVIDERS
];
