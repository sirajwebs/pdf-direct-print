import { Observable, of } from 'rxjs';

import { Shipment } from '@shared/models/shipment.model';
import { PendingShipmentsService } from 'app/features/pending-shipments/services/pending-shipments.service';
import { MOCKED_PENDING_SHIPMENTS_RESPONSE } from './pending-shipments.mock';

export const MOCKED_PENDING_SHIPMENTS_SERVICE: Partial<PendingShipmentsService> = {

  getPendingShipments(): Observable<Shipment[]> {
    return of(MOCKED_PENDING_SHIPMENTS_RESPONSE);
  },

  finalizeShipments(): Observable<boolean> {
    return of(true);
  },

  printShipments(): Observable<boolean> {
    return of(true);
  }
};
