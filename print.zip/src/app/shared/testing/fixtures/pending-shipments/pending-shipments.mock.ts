import { Shipment, ShipmentStatus } from '@shared/models/shipment.model';

export const MOCKED_PENDING_SHIPMENTS_RESPONSE: Shipment[] = [
  {
    id: 'string',
    shipmentStatus: ShipmentStatus.PENDING,
    accountNumber: 'string',
    customerReference: 'UN3343',
    transactionId: 'RE3432SAD',
    shipmentInformation: {} as any
  },
];
