import { NgModule, Provider } from '@angular/core';

import { environment } from '../../../environments/environment';
import { Configuration } from './configuration.model';
import { ShippingConfiguration } from './shipping-configuration.model';

const CONFIGURATION_PROVIDERS: Provider[] = [
  {
    provide: Configuration,
    useFactory: () => environment.configuration
  },
  {
    provide: ShippingConfiguration,
    deps: [Configuration],
    useFactory: (configuration: Configuration) => configuration.shipping
  },
];

@NgModule({
  providers: [
    ...CONFIGURATION_PROVIDERS
  ]
})
export class ConfigurationModule {
}
