import { ShippingConfiguration } from './shipping-configuration.model';

export abstract class Configuration {
  public abstract shipping: ShippingConfiguration;
}
