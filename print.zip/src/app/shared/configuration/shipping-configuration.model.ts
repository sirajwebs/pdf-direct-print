export abstract class ShippingConfiguration {
  public abstract fetchPendingShipments: (page: number) => string;
  public abstract createShipment: string;
  public abstract finalizeShipment: string;
  public abstract printShipments: string;
  public abstract printerDetails: string;
}
