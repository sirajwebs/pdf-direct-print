export abstract class PrintingConfiguration {
  public abstract printerDetails: string;
  public abstract printShipments: string;
}
