export interface PrinterList {
    id: string,
    name: string
}

export interface PrintShipment {
    jobId: string,
    printer: string,
    labels: Array<string>
}