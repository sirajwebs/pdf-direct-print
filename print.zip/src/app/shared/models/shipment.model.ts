
export interface Contact {
  name: string;
  companyName: string;
  telephoneNumber: string;
  email: string;
  customsId?: string; // not available in MVP
}

export interface Address {
  city: string;
  postalCode: string;
  countryCode: string;
  residential: boolean;
  streetLines: string[];
}

export interface From {
  contact: Contact;
  address: Address;
}

export interface To {
  contact: Contact;
  address: Address;
}

export interface CustomsValue {
  amount: string;
  currency: string;
}

export interface ShipmentDocuments {
  purpose: string;
  description: string;
  customsValue: CustomsValue;
}

export interface CarriageValue {
  amount: string;
  currency: string;
}

export interface Weight {
  amount: string;
  unit: string;
}

export interface Dimensions {
  height: string;
  length: string;
  units: string;
  width: string;
}

export interface PackageDetail {
  packageType: string;
  packagesAmount: number;
  weight: Weight;
  dimensions?: Dimensions; // not available in MVP
}

export interface AlternativeAddress {
  contact: Contact;
  address: Address;
}

export interface PickupDropOff {
  shipDate: string;
  service: string;
  readyTime: string;
  latestTime: string;
  instructions: string;
  alternativeAddress?: AlternativeAddress; // not available in MVP
  pickupDropOffType?: string; // not available in MVP
}

export interface ShipmentInformation {
  from: From;
  to: To;
  shipmentDocuments?: ShipmentDocuments; // not available in MVP
  carriageValue?: CarriageValue;
  packageDetails: PackageDetail[];
  pickupDropOff: PickupDropOff;
}

export interface Shipment {
  id?: string;
  shipmentStatus: ShipmentStatus;
  accountNumber: string;
  customerReference: string;
  shipmentInformation: ShipmentInformation;
  transactionId?: string;
}

export enum ShipmentStatus {
  PENDING = 'PENDING',
  FINALISED = 'FINALISED'
}

