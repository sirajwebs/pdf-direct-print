import { NgModule } from '@angular/core';

import { SailLoaderComponent } from './loader.component';

@NgModule({
  declarations: [
    SailLoaderComponent
  ],
  exports: [
    SailLoaderComponent
  ]
})
export class SailLoaderModule { }
