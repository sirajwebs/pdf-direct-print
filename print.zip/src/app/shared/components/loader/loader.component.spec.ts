import { createComponentFactory, Spectator } from '@ngneat/spectator';

import { SailLoaderComponent } from './loader.component';

describe('SailLoaderComponent', () => {
  let spectator: Spectator<SailLoaderComponent>;
  const createComponent = createComponentFactory(SailLoaderComponent);

  beforeEach(() => spectator = createComponent());

  it('should create', () => {
    expect(spectator.query('.loader')).toBeTruthy();
  });
});
