import { Component, ChangeDetectionStrategy, Input } from '@angular/core';

@Component({
  selector: 'sail-loader',
  templateUrl: './loader.component.html',
  styleUrls: ['./loader.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class SailLoaderComponent {

  @Input() absolute = true;
}
