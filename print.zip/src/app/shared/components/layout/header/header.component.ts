import { Component, ChangeDetectionStrategy } from '@angular/core';

@Component({
  selector: 'sail-header',
  templateUrl: './header.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class HeaderComponent {
}
