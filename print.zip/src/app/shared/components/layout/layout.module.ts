import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { TranslocoModule } from '@ngneat/transloco';
import { RouterModule } from '@angular/router';

import { HeaderComponent } from './header/header.component';
import { SidebarComponent } from './sidebar/sidebar.component';
import { MainLayoutComponent } from './main-layout/main-layout.component';

@NgModule({
  imports: [
    CommonModule,
    RouterModule,

    TranslocoModule
  ],
  declarations: [
    MainLayoutComponent,
    HeaderComponent,
    SidebarComponent
  ]
})
export class LayoutModule { }
