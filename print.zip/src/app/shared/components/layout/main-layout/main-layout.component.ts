import { Component, ChangeDetectionStrategy } from '@angular/core';

@Component({
  selector: 'sail-main-layout',
  templateUrl: './main-layout.component.html',
  styleUrls: ['./main-layout.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class MainLayoutComponent {

}
