import { createComponentFactory, Spectator } from '@ngneat/spectator';

import { MainLayoutComponent } from './main-layout.component';
import { LayoutModule } from '@shared/components/layout/layout.module';
import { RouterTestingModule } from '@angular/router/testing';

describe('MainLayoutComponent', () => {
  let spectator: Spectator<MainLayoutComponent>;
  const createComponent = createComponentFactory({
    imports: [
      LayoutModule,
      RouterTestingModule.withRoutes([])
    ],
    component: MainLayoutComponent,
  });

  beforeEach(() => spectator = createComponent());

  it(`contains header, sidebar and router-outlet components`, () => {
    expect(spectator.query('sail-header')).toBeVisible();
    expect(spectator.query('sail-sidebar')).toBeVisible();
    expect(spectator.query('router-outlet')).toBeVisible();
  });
});

