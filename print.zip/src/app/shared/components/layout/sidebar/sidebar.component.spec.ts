import { createComponentFactory, Spectator, byText } from '@ngneat/spectator';

import { SidebarComponent } from './sidebar.component';

describe('SidebarComponent', () => {
  let spectator: Spectator<SidebarComponent>;
  const createComponent = createComponentFactory(SidebarComponent);

  beforeEach(() => spectator = createComponent());

  [
    ['Pending shipments', '/pending-shipments'],
    ['Create shipment', '/create-shipment']
  ].forEach(([pageName, link]) => {
    it(`has a link to the ${pageName} page`, () => {
      expect(spectator.query(byText(pageName))).toHaveAttribute('routerLink', link);
    });
  });
});

