import { byText, createComponentFactory, Spectator } from '@ngneat/spectator';

import { SailInputFieldComponent } from './sail-input-field.component';
import { SailInputType } from './sail-input-type.enum';

describe('SailInputFieldComponent', () => {
  let spectator: Spectator<SailInputFieldComponent>;
  const createComponent = createComponentFactory(SailInputFieldComponent);

  beforeEach(() => spectator = createComponent());

  [
    ['an input', SailInputType.TEXT, 'input'],
    ['a textarea', SailInputType.TEXT_AREA, 'textarea'],
    ['a select', SailInputType.SELECT, 'select']
  ].forEach(([name, type, expected]) => {
    it(`generates ${name} with a label`, () => {
      spectator.setInput({
        label: name,
        // @ts-ignore
        type
      });

      expect(spectator.query(expected)).toBeDefined();
      expect(spectator.query('label')).toHaveText(name);
      // the field is not required by default.
      expect(spectator.query(byText('*'))).toBeFalsy();
    });
  });

  it(`allows to set and get a value of a field`, () => {
    spectator.component.value = 'bueno';
    expect(spectator.component.value).toBe('bueno');
  });

  it(`allows to disable a field`, () => {
    spectator.component.setDisabledState(true);
    expect(spectator.component.isDisabled).toBe(true);
  });

  it(`allows to mark ${name} field as required`, () => {
    spectator.setInput({ required: true });

    expect(spectator.query(byText('*'))).toBeTruthy();
  });

  it('renders a select field with specified options', () => {
    spectator.setInput({
      type: SailInputType.SELECT,
      options: ['one', 'two', 'three']
    });

    // It's 4 because of default <option>Please select</option> + 3 options that we have specified.
    expect(spectator.queryAll('option').length).toBe(4);
  });

  it(`calls a handler for onChange event`, () => {
    const spy = spyOn(spectator.component, `onChange`);
    spectator.component.value = 'bueno';
    expect(spy).toHaveBeenCalledWith('bueno');
    expect(spy).toHaveBeenCalledTimes(1);
  });
});
