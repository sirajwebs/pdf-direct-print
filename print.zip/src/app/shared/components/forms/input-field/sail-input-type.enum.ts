export enum SailInputType {
  TEXT = 'text',
  TEXT_AREA = 'textarea',
  SELECT = 'select',
}
