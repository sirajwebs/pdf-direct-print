import { Component, Input, ChangeDetectionStrategy, forwardRef } from '@angular/core';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';

import { SailInputType } from './sail-input-type.enum';

let uniqueId = 0;

@Component({
  selector: 'sail-input-field',
  templateUrl: './sail-input-field.component.html',
  styleUrls: ['./sail-input-field.component.scss'],
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => SailInputFieldComponent),
      multi: true
    }
  ],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class SailInputFieldComponent implements ControlValueAccessor {

  @Input() public label: string;
  @Input() public type: SailInputType = SailInputType.TEXT;
  @Input() public disabled = false;
  @Input() public required = false;

  @Input() public ariaLabel: string;
  @Input() public options: string[] = [];
  public fieldId = `sail-input-field-${uniqueId++}`;

  public readonly SailInputType = SailInputType;

  private _value: any;
  private _isDisabled: boolean;

  get value(): any {
    return this._value;
  }

  set value(value: any) {
    this.writeValue(value);
  }

  get isDisabled(): boolean {
    return this._isDisabled;
  }

  onChange: (_: any) => void = (_: any) => {};
  onTouched: () => void = () => {};

  registerOnChange(fn: any): void {
    this.onChange = fn;
  }

  registerOnTouched(fn: any): void {
    this.onTouched = fn;
  }

  writeValue(value: any): void {
    this._value = value;
    this.onChange(this._value);
  }

  setDisabledState(isDisabled: boolean): void {
    this._isDisabled = isDisabled;
  }

  public trackByFn(index: number) {
    return index;
  }
}
