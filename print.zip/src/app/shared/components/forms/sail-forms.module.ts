import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { SailInputFieldComponent } from './input-field/sail-input-field.component';
import { SailCheckboxComponent } from './checkbox/sail-checkbox.component';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
  ],
  declarations: [
    SailInputFieldComponent,
    SailCheckboxComponent
  ],
  exports: [
    SailInputFieldComponent,
    SailCheckboxComponent
  ],
})
export class SailFormsModule { }
