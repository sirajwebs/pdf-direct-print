import { createComponentFactory } from '@ngneat/spectator';
import { SailCheckboxComponent } from './sail-checkbox.component';

describe('SailCheckboxComponent', () => {
  const createComponent = createComponentFactory(SailCheckboxComponent);

  it('generates a checkbox with a unique id and label', () => {
    const spectator = createComponent({
      props: {
        label: 'Hello World!'
      }
    });

    expect(spectator.query('input')).toHaveAttribute('type', 'checkbox');
    expect(spectator.query('input[id^=sail-input]')).toExist();

    expect(spectator.query('label')).toHaveText('Hello World!');
    expect(spectator.query('label[for^=sail-input]')).toExist();
  });
});
