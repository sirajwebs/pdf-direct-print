import { Component, ChangeDetectionStrategy, forwardRef, Input } from '@angular/core';
import { SailInputFieldComponent } from '@shared/components/forms/input-field/sail-input-field.component';
import { NG_VALUE_ACCESSOR } from '@angular/forms';

@Component({
  selector: 'sail-checkbox',
  templateUrl: './sail-checkbox.component.html',
  styleUrls: ['./sail-checkbox.component.scss'],
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => SailCheckboxComponent),
      multi: true
    }
  ],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class SailCheckboxComponent extends SailInputFieldComponent {

  @Input() checked = false;
  @Input() indeterminate = false;
}
