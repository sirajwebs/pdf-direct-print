import { NgModule } from '@angular/core';

import { TranslocoModule, TRANSLOCO_CONFIG, TranslocoConfig } from '@ngneat/transloco';

import { environment } from '../../../environments/environment';
import { translocoLoader } from './transloco.loader';

const TRANSLOCO_CONFIG_VALUE: TranslocoConfig = {
  availableLangs: ['en'],
  defaultLang: 'en',
  reRenderOnLangChange: true,
  prodMode: environment.production,
  flatten: {
    aot: environment.production,
  },
};

@NgModule({
  imports: [
    TranslocoModule,
  ],
  providers: [
    { provide: TRANSLOCO_CONFIG, useValue: TRANSLOCO_CONFIG_VALUE },
    translocoLoader
  ]
})
export class InternationalizationModule {
}
