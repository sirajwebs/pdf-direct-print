import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { MainLayoutComponent } from '@shared/components/layout/main-layout/main-layout.component';

const routes: Routes = [
  {
    path: '',
    component: MainLayoutComponent,
    children: [
      {
        path: '',
        pathMatch: 'full',
        redirectTo: 'pending-shipments',
      },
      {
        path: 'pending-shipments',
        loadChildren: () => import('./features/pending-shipments/pending-shipments.module').then((m) => m.PendingShipmentsModule),
      },
      {
        path: 'create-shipment',
        loadChildren: () => import('./features/create-shipment/create-shipment.module').then((m) => m.CreateShipmentModule),
      },
      {
        path: 'print-management',
        loadChildren: () => import('./features/print-management/print-management.module').then((m) => m.PrintManagementModule),
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
