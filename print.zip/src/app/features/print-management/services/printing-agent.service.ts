import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

import { PrinterList, PrintShipment } from '@shared/models/printing.model';
import { ShippingConfiguration } from '@shared/configuration/shipping-configuration.model';

@Injectable()
export class PrintingAgentService {

  constructor(
    private readonly httpClient: HttpClient,
    private readonly configuration: ShippingConfiguration,
  ) { }

  public getPrinters(): Observable<PrinterList[]> {
    return this.httpClient.get(this.configuration.printerDetails).pipe(
      map((result) => this.parsePrinters(result))
    );
  }

  public printShipments(printingData: PrintShipment): Observable<any> {
    const body: PrintShipment = { ...printingData };
    return this.httpClient.post(this.configuration.printShipments, body).pipe(
      map(() => true)
    );
  }

  private parsePrinters(result: any): PrinterList[] {
    return result.map((printer: any) => ({
      id: '',
      name: printer,
    }));
  }
}
