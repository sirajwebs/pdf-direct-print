import { TestBed } from '@angular/core/testing';

import { PrintingAgentService } from './printing-agent.service';

describe('PrintingAgentService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: PrintingAgentService = TestBed.get(PrintingAgentService);
    expect(service).toBeTruthy();
  });
});
