import { Injectable } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';

@Injectable()
export class PrintManagementFormService {
  private _form: FormGroup;

  get form(): FormGroup {
    return this._form;
  }

  constructor(
    private fb: FormBuilder,
  ) {
    this.initForm();
  }

  private initForm(): void {
    this._form = this.fb.group({
      preferences: this.fb.group({
        printer: [''],
        pages: [''],
      }),
      pdfLabels: ['']
    })
  }
}
