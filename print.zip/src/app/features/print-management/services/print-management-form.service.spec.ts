import { TestBed } from '@angular/core/testing';

import { PrintManagementFormService } from './print-management-form.service';

describe('PrintManagementFormService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: PrintManagementFormService = TestBed.get(PrintManagementFormService);
    expect(service).toBeTruthy();
  });
});
