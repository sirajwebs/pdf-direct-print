import { ChangeDetectionStrategy, ChangeDetectorRef, Component, Input } from '@angular/core';
import { FormComponent } from '../form-component';

import { PrinterList } from '@shared/models/printing.model';

@Component({
  selector: 'sail-print-preferences',
  templateUrl: './print-preferences.component.html',
  styleUrls: ['./print-preferences.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class PrintPreferencesComponent extends FormComponent {

  @Input() printerList: Array<PrinterList>;

  constructor(
    protected readonly cd: ChangeDetectorRef,
  ) {
    super(cd);
  }

  get preferencesForm() {
    return this.form.get('preferences');
  }
}
