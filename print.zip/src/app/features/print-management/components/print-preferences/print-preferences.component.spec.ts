import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PrintPreferencesComponent } from './print-preferences.component';

describe('PrintPreferencesComponent', () => {
  let component: PrintPreferencesComponent;
  let fixture: ComponentFixture<PrintPreferencesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PrintPreferencesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PrintPreferencesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
