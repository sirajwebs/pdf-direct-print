import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PrintManagementComponent } from './print-management.component';

describe('PrintManagementComponent', () => {
  let component: PrintManagementComponent;
  let fixture: ComponentFixture<PrintManagementComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PrintManagementComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PrintManagementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
