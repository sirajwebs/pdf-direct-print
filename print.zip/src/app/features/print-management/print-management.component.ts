import { Component, ChangeDetectionStrategy, OnInit } from '@angular/core';
import { take } from 'rxjs/operators';

import { PrintingAgentService } from './services/printing-agent.service';
import { PrinterList, PrintShipment } from '@shared/models/printing.model';
import { PrintManagementFormService } from './services/print-management-form.service';

@Component({
  selector: 'sail-print-management',
  templateUrl: './print-management.component.html',
  styleUrls: ['./print-management.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class PrintManagementComponent implements OnInit {

  printers: Array<PrinterList> = [];

  constructor(
    public readonly printingAgentService: PrintingAgentService,
    private readonly formService: PrintManagementFormService,
  ) { }

  ngOnInit() {
    this.getPrinters();
  }

  get form() {
    return this.formService.form;
  }

  public trackByFn(index: number) {
    return index;
  }

  public savePrintPreferences(): void {
    // save preference api
  }

  public printShipments(): void {

    const form = this.form;

    // sample printing labels request body
    const printShipmentBody: PrintShipment = {
      jobId: '',
      printer: '',
      labels: [form?.get('pdfLabels')?.value]
    }
    this.printingAgentService.printShipments(printShipmentBody).subscribe();
  }

  public getPrinters(): void {
    this.printingAgentService.getPrinters().pipe(take(1)).subscribe(data => {
      this.printers = data;
    });
  }

  get printerList() {
    return this.printers.map(el => {
      return el.name;
    })
  }

}
