import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';

import { TranslocoModule } from '@ngneat/transloco';

import { MatDialogModule } from '@angular/material/dialog';
import { SailFormsModule } from '@shared/components/forms/sail-forms.module';

import { PrintManagementComponent } from './print-management.component';
import { PrintManagementRoutingModule } from './print-management-routing.module';
import { PrintingAgentService } from './services/printing-agent.service';
import { PrintManagementFormService } from './services/print-management-form.service';
import { PrintPreferencesComponent } from './components/print-preferences/print-preferences.component';


@NgModule({
  imports: [
    CommonModule,
    ReactiveFormsModule,
    PrintManagementRoutingModule,

    TranslocoModule,
    
    MatDialogModule,
    SailFormsModule
  ],
  declarations: [
    PrintManagementComponent,
    PrintPreferencesComponent
  ],
  providers: [
    PrintingAgentService,
    PrintManagementFormService
  ]
})
export class PrintManagementModule { }
