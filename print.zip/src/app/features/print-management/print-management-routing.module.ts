import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { PrintManagementComponent } from './print-management.component';

const routes: Routes = [
  {
    path: '',
    component: PrintManagementComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PrintManagementRoutingModule { }
