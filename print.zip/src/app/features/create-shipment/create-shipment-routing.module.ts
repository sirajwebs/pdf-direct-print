import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { CreateShipmentComponent } from './create-shipment.component';

const routes: Routes = [
  {
    path: '',
    component: CreateShipmentComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CreateShipmentRoutingModule { }
