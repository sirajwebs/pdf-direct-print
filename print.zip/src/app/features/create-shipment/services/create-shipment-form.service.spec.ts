import { TestBed } from '@angular/core/testing';

// import { CreateShipmentFormService } from './create-shipment-form.service';

describe('CreateShipmentFormService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    // const service: CreateShipmentFormService = TestBed.get(CreateShipmentFormService);
    expect(true).toBeTruthy();
    // TODO
  });
});
