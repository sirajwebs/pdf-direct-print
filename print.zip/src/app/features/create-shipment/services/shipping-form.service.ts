import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

import { ShippingConfiguration } from '@shared/configuration/shipping-configuration.model';
import { Shipment } from '@shared/models/shipment.model';


@Injectable()
export class ShippingFormService {

  constructor(
    private readonly httpClient: HttpClient,
    private readonly configuration: ShippingConfiguration,
  ) { }

  public createShipment(shipment: Shipment): Observable<boolean> {
    return this.httpClient.post(this.configuration.createShipment, shipment).pipe(
      map(() => true)
    );
  }

}
