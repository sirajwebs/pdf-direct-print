import { Injectable } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Shipment, ShipmentStatus } from '@shared/models/shipment.model';

@Injectable()
export class CreateShipmentFormService {

  private _form: FormGroup;

  get form(): FormGroup {
    return this._form;
  }

  constructor(
    private fb: FormBuilder,
  ) {
    this.initForm();
  }

  private initForm(): void {
    this._form = this.fb.group({
      booking: this.fb.group({
        accountNumber: [''], // accountNumber
        customerReference: [''], // customerReference
      }),
      from: this.getContactDetailsForm(), // shipmentInformation.from
      to: this.getContactDetailsForm(), // shipmentInformation.to
      package: this.fb.group({ // packageDetails
        packageType: [''], // packageType
        packagesAmount: [''], // packagesAmount
        weightAmount: [''], // weight.amount
        weightUnit: [''], // weight.unit
        extraLiability: [''], // AUX (toggles carriageValue.* fields)
        carriageValueAmount: [''], // carriageValue.amount
        carriageValueUnit: [''], // carriageValue.unit
      }),
      pickupDropOff: this.fb.group({ // pickupDropOff
        shipDate: [''], // shipDate
        service: [''], // service
        readyTime: [''], // readyTime
        latestTime: [''], // latestTime
        instructions: [''], // instructions
      }),
    });
  }

  private getContactDetailsForm() {
    return this.fb.group({
      name: [''], // contact.name
      companyName: [''], // contact.companyName
      telephoneNumber: [''], // contact.telephoneNumber
      email: [''], // contact.email
      addressLine1: [''], // address.streetLines (array)
      addressLine2: [''], // address.streetLines (array)
      addressLine3: [''], // address.streetLines (array)
      postalCode: [''], // address.postalCode
      city: [''], // address.city
      countryCode: [''], // address.countryCode
    });
  }

  public createShipmentRequestPayload(): Shipment {
    const form = this.form;

    const shipment: Shipment = {
      shipmentStatus: ShipmentStatus.PENDING,
      accountNumber: form.get('booking')?.get('accountNumber')?.value,
      customerReference: form.get('booking')?.get('customerReference')?.value,

      shipmentInformation : {

        from: {
          contact: {
            name: form.get('from')?.get('name')?.value,
            companyName: form.get('from')?.get('companyName')?.value,
            telephoneNumber: form.get('from')?.get('telephoneNumber')?.value,
            email: form.get('from')?.get('email')?.value,
          },
          address: {
            city: form.get('from')?.get('city')?.value,
            postalCode: form.get('from')?.get('postalCode')?.value,
            countryCode: form.get('from')?.get('countryCode')?.value,
            residential: form.get('from')?.get('residential')?.value,
            streetLines: [
              form.get('from')?.get('addressLine1')?.value,
              form.get('from')?.get('addressLine2')?.value,
              form.get('from')?.get('addressLine3')?.value,
            ]
          },
        },

        to: {
          contact: {
            name: form.get('to')?.get('name')?.value,
            companyName: form.get('to')?.get('companyName')?.value,
            telephoneNumber: form.get('to')?.get('telephoneNumber')?.value,
            email: form.get('to')?.get('email')?.value,
          },
          address: {
            city: form.get('to')?.get('city')?.value,
            postalCode: form.get('to')?.get('postalCode')?.value,
            countryCode: form.get('to')?.get('countryCode')?.value,
            residential: form.get('to')?.get('residential')?.value,
            streetLines: [
              form.get('to')?.get('addressLine1')?.value,
              form.get('to')?.get('addressLine2')?.value,
              form.get('to')?.get('addressLine3')?.value,
            ]
          },
        },

        packageDetails: [
          {
            packageType: form.get('package')?.get('packageType')?.value,
            packagesAmount: form.get('package')?.get('packagesAmount')?.value,
            weight: {
              amount: form.get('package')?.get('weightAmount')?.value,
              unit: form.get('package')?.get('weightUnit')?.value,
            },
          },
        ],

        pickupDropOff: {
          shipDate: form.get('pickupDropOff')?.get('shipDate')?.value,
          service: form.get('pickupDropOff')?.get('service')?.value,
          readyTime: form.get('pickupDropOff')?.get('readyTime')?.value,
          latestTime: form.get('pickupDropOff')?.get('latestTime')?.value,
          instructions: form.get('pickupDropOff')?.get('instructions')?.value,
        },

        carriageValue: {
          amount: form.get('package')?.get('amount')?.value,
          currency: form.get('package')?.get('currency')?.value,
        },

      },

    };

    return shipment;
  }
}
