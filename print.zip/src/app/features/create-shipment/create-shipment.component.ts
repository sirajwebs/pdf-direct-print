import { Router } from '@angular/router';
import { Component, ChangeDetectionStrategy } from '@angular/core';
import { first } from 'rxjs/operators';
import { ToastrService } from 'ngx-toastr';

import { CreateShipmentFormService } from './services/create-shipment-form.service';
import { ShippingFormService } from './services/shipping-form.service';

@Component({
  selector: 'sail-create-shipment',
  templateUrl: './create-shipment.component.html',
  styleUrls: ['./create-shipment.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class CreateShipmentComponent {

  constructor(
    private readonly router: Router,
    private readonly shippingFormService: ShippingFormService,
    private readonly formService: CreateShipmentFormService,
    private readonly toastrService: ToastrService,
  ) {}

  get form() {
    return this.formService.form;
  }

  public trackByFn(index: number) {
    return index;
  }

  public createShipment(): void {
    this.shippingFormService.createShipment(this.formService.createShipmentRequestPayload()).pipe(first()).subscribe(() =>  {
      this.toastrService.success('It is now added to pending shipments.', 'Shipment created successfully');
      this.router.navigate(['pending-shipments']);
    });
  }

}

