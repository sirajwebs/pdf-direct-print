import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

import { TranslocoModule } from '@ngneat/transloco';
import { MatDialogModule } from '@angular/material/dialog';

import { SailFormsModule } from '@shared/components/forms/sail-forms.module';
import { CreateShipmentRoutingModule } from './create-shipment-routing.module';
import { ShippingFormService } from './services/shipping-form.service';
import { CreateShipmentComponent } from './create-shipment.component';
import { BookingDetailsComponent } from './components/booking-details/booking-details.component';
import { ContactDetailsComponent } from './components/contact-details/contact-details.component';
import { PackageDetailsComponent } from './components/package-details/package-details.component';
import { ServiceOfferComponent } from './components/service-offer/service-offer.component';
import { CreateShipmentFormService } from './services/create-shipment-form.service';
import { AgreementComponent } from './components/agreement/agreement.component';

@NgModule({
  imports: [
    CommonModule,
    ReactiveFormsModule,
    CreateShipmentRoutingModule,

    TranslocoModule,

    MatDialogModule,
    SailFormsModule,
  ],
  declarations: [
    CreateShipmentComponent,
    BookingDetailsComponent,
    ContactDetailsComponent,
    PackageDetailsComponent,
    ServiceOfferComponent,
    AgreementComponent,
  ],
  providers: [
    ShippingFormService,
    CreateShipmentFormService,
  ],
})
export class CreateShipmentModule { }
