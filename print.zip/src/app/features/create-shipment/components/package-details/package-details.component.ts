import { ChangeDetectionStrategy, ChangeDetectorRef, Component } from '@angular/core';

import { FormComponent } from '../form-component';

@Component({
  selector: 'sail-package-details',
  templateUrl: './package-details.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class PackageDetailsComponent extends FormComponent {

  public packageTypes = [
    'FedEx 10kg box',
    'FedEx 25kg box',
    'FedEx Envelope',
    'Fedex Extra Large Box',
    'FedEx Large Box',
    'FedEx Medium Box',
    'FedEx Pak',
    'FedEx Small Box',
    'FedEx Tube'
  ];
  public weightUnits = ['kg', 'lbs'];

  public readonly currency = [ 'EUR', 'USD' ];

  constructor(
    protected readonly cd: ChangeDetectorRef,
  ) {
    super(cd);
  }

  get packageForm() {
    return this.form.get('package');
  }

  get extraLiabilitySelected(): boolean {
    if (!this.packageForm) {
      return false;
    }
    const extraLiabilityControl = this.packageForm.get('extraLiability');
    return extraLiabilityControl && extraLiabilityControl.value;
  }
}
