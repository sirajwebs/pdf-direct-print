import { ChangeDetectionStrategy, ChangeDetectorRef, Component } from '@angular/core';

import { FormComponent } from '../form-component';

@Component({
  selector: 'sail-service-offer',
  templateUrl: './service-offer.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ServiceOfferComponent extends FormComponent {

  public services = [
    'International First',
    'International Economy',
    'International Priority',
    'International Priority Freight',
    'International Economy Freight'
  ];

  constructor(
    protected readonly cd: ChangeDetectorRef,
  ) {
    super(cd);
  }

  get serviceForm() {
    return this.form.get('pickupDropOff');
  }
}
