import { Component, ChangeDetectionStrategy } from '@angular/core';

@Component({
  selector: 'sail-agreement',
  templateUrl: './agreement.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class AgreementComponent {
}
