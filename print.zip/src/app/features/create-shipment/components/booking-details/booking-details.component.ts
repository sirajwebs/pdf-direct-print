import { ChangeDetectionStrategy, ChangeDetectorRef, Component } from '@angular/core';
import { FormComponent } from '../form-component';

@Component({
  selector: 'sail-booking-details',
  templateUrl: './booking-details.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class BookingDetailsComponent extends FormComponent {

  constructor(
    protected readonly cd: ChangeDetectorRef,
  ) {
    super(cd);
  }

  get bookingForm() {
    return this.form.get('booking');
  }
}
