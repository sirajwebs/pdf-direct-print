import { ChangeDetectorRef, Input, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';

import { SubscriptionHandler } from '@shared/utils/subscription-handler/subscription-handler';

export abstract class FormComponent extends SubscriptionHandler implements OnInit {
  @Input() readonly form: FormGroup;

  constructor(
    protected readonly cd: ChangeDetectorRef,
  ) {
    super();
  }

  ngOnInit(): void {
    this.subscriptions.add(
      this.form.statusChanges.subscribe(() => {
        this.cd.detectChanges();
      })
    );
  }
}
