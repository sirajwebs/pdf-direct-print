import { ChangeDetectionStrategy, ChangeDetectorRef, Component } from '@angular/core';

import { Countries } from '@shared/models/countries.enum';

import { FormComponent } from '../form-component';

@Component({
  selector: 'sail-contact-details',
  templateUrl: './contact-details.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ContactDetailsComponent extends FormComponent {

  public readonly countries = Object.keys(Countries);

  constructor(
    protected readonly cd: ChangeDetectorRef,
  ) {
    super(cd);
  }

  get senderForm() {
    return this.form.get('from');
  }

  get receiverForm() {
    return this.form.get('to');
  }
}
