import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { PendingShipmentsComponent } from './pending-shipments.component';

const routes: Routes = [
  {
    path: '',
    component: PendingShipmentsComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PendingShipmentsRoutingModule { }
