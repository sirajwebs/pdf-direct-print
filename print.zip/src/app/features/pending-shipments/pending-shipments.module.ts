import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MatTableModule } from '@angular/material/table';
import { MatPaginatorModule } from '@angular/material/paginator';
import { TranslocoModule } from '@ngneat/transloco';

import { SailFormsModule } from '@shared/components/forms/sail-forms.module';
import { SailLoaderModule } from '@shared/components/loader/loader.module';

import { PendingShipmentsRoutingModule } from './pending-shipments-routing.module';
import { PendingShipmentsComponent } from './pending-shipments.component';
import { PendingShipmentsService } from './services/pending-shipments.service';

@NgModule({
  imports: [
    CommonModule,
    PendingShipmentsRoutingModule,

    TranslocoModule,
    MatTableModule,
    MatPaginatorModule,

    SailFormsModule,
    SailLoaderModule
  ],
  declarations: [PendingShipmentsComponent],
  providers: [
    PendingShipmentsService
  ]
})
export class PendingShipmentsModule { }
