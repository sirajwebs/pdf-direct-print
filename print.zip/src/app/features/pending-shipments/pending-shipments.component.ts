import { Component, ChangeDetectionStrategy, ViewChild, OnInit } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { SelectionModel } from '@angular/cdk/collections';
import { of, Observable, Subject, merge } from 'rxjs';
import { startWith, switchMap, catchError, tap } from 'rxjs/operators';

import { ToastrService } from 'ngx-toastr';
import { TranslocoService } from '@ngneat/transloco';

import { Shipment } from '@shared/models/shipment.model';

import { PendingShipmentsService } from './services/pending-shipments.service';

@Component({
  selector: 'sail-pending-shipments',
  templateUrl: './pending-shipments.component.html',
  styleUrls: ['./pending-shipments.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class PendingShipmentsComponent implements OnInit {

  displayedColumns: string[] = ['select', 'shipmentStatus', 'shipmentNumber', 'customerReference'];
  selection = new SelectionModel<Shipment>(true, []);
  shipments$: Observable<Shipment[]>;

  private readonly loadingSubject = new Subject<boolean>();
  loading$ = this.loadingSubject.asObservable();
  private readonly fetchShipmentsSubject = new Subject<boolean>();

  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;

  constructor(
    private readonly pendingShipmentsService: PendingShipmentsService,
    private readonly toastrService: ToastrService,
    private readonly translocoService: TranslocoService,
  ) { }

  ngOnInit(): void {
    this.shipments$ = merge(
      this.fetchShipmentsSubject.asObservable(),
      this.paginator.page
    ).pipe(
      startWith({}),
      tap(() => this.loadingSubject.next(true)),
      switchMap(() => this.pendingShipmentsService.getPendingShipments(this.paginator.pageIndex)),
      tap(() => this.loadingSubject.next(false)),
      catchError(() => of([]))
    );
  }

  isAllSelected(shipments: Shipment[]): boolean {
    return shipments.length === this.selection.selected.length;
  }

  masterToggle(shipments: Shipment[]) {
    this.isAllSelected(shipments) ?
      this.selection.clear() :
      shipments.forEach(row => this.selection.select(row));
  }

  /** The label for the checkbox on the passed row */
  checkboxLabel(shipments: Shipment[], row?: Shipment): string {
    if (!row) {
      return `${this.isAllSelected(shipments) ? 'select' : 'deselect'} all`;
    }
    return `${this.selection.isSelected(row) ? 'deselect' : 'select'} row ${row.id}`;
  }

  trackByFn(row?: Shipment): string | undefined {
    return row && row.id;
  }

  finalize(): void {
    this.pendingShipmentsService.finalizeShipments(this.selection.selected)
      .subscribe(() => {
        this.toastrService.success(
          this.translocoService.translate('PENDING_SHIPMENTS.FINALIZE_SUCCESS.MESSAGE'),
          this.translocoService.translate('PENDING_SHIPMENTS.FINALIZE_SUCCESS.TITLE')
        );
        this.pendingShipmentsService.printShipments().subscribe();
        this.selection.clear();
        this.fetchShipmentsSubject.next(true);
      });
  }

  cancelSelection(): void {
    this.selection.clear();
  }
}
