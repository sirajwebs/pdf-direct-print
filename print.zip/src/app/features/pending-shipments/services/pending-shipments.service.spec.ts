import { createHttpFactory, HttpMethod, SpectatorHttp } from '@ngneat/spectator';
import { DEFAULT_TEST_PROVIDERS, MOCKED_PENDING_SHIPMENTS_RESPONSE } from '@testing/index';
import { PendingShipmentsService } from './pending-shipments.service';
import { environment } from 'environments/environment';

describe('Pending shipments service', () => {

  let spectator: SpectatorHttp<PendingShipmentsService>;
  const createHttp = createHttpFactory({
    service: PendingShipmentsService,
    providers: DEFAULT_TEST_PROVIDERS
  });

  beforeEach(() => spectator = createHttp());

  it('fetches the pending shipments', () => {
    spectator.service.getPendingShipments(1).subscribe((shipments) => {
      expect(shipments[0].customerReference).toBe(MOCKED_PENDING_SHIPMENTS_RESPONSE[0].customerReference);
    });

    spectator
      .expectOne(environment.configuration.shipping.fetchPendingShipments(1), HttpMethod.GET)
      .flush(MOCKED_PENDING_SHIPMENTS_RESPONSE);
  });

  it('finalizes shipments', () => {
    spectator.service.finalizeShipments([]).subscribe((result) => {
      expect(result).toBe(true);
    });

    spectator
      .expectOne(environment.configuration.shipping.finalizeShipment, HttpMethod.PATCH)
      .flush({});
  });

  it('prints shipments', () => {
    spectator.service.printShipments().subscribe((result) => {
      expect(result).toBe(true);
    });

    spectator
      .expectOne(environment.configuration.shipping.printShipments, HttpMethod.POST)
      .flush({});
  });

});
