import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

import { ShippingConfiguration } from '@shared/configuration/shipping-configuration.model';
import { Shipment } from '@shared/models/shipment.model';

@Injectable()
export class PendingShipmentsService {

  constructor(
    private readonly httpClient: HttpClient,
    private readonly configuration: ShippingConfiguration
  ) { }

  public getPendingShipments(page: number): Observable<Shipment[]> {
    return this.httpClient.get(this.configuration.fetchPendingShipments(page)).pipe(
      map((result) => this.parseShipment(result))
    );
  }

  public finalizeShipments(shipments: Shipment[]): Observable<boolean> {
    return this.httpClient.patch(this.configuration.finalizeShipment, shipments).pipe(
      map(() => true)
    );
  }

  public printShipments(): Observable<boolean> {
    // TODO: This is just a sample body and must be changed later when we get the real pdf urls
    const body = {
      labels: [
        'https://picqer.com/images/help/install-zebra-printer/picqer-a6-test-label.pdf'
      ]
    };
    return this.httpClient.post(this.configuration.printShipments, body).pipe(
      map(() => true)
    );
  }

  private parseShipment(result: any): Shipment[] {
    return result.map((shipment: any) => ({
      id: shipment.id,
      shipmentStatus: shipment.shipmentStatus,
      accountNumber: shipment.accountNumber,
      customerReference: shipment.customerReference,
      shipmentInformation: shipment.shipmentInformation,
      transactionId: shipment.transactionId,
    }));
  }

}
