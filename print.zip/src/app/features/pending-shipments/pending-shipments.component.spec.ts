import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { Spectator, createComponentFactory, mockProvider } from '@ngneat/spectator';

import {
  ToastrTestingModule,
  MOCKED_PENDING_SHIPMENTS_SERVICE,
  MOCKED_PENDING_SHIPMENTS_RESPONSE,
  DEFAULT_TEST_PROVIDERS
} from '@shared/testing';

import { PendingShipmentsComponent } from './pending-shipments.component';
import { PendingShipmentsModule } from './pending-shipments.module';
import { PendingShipmentsService } from './services/pending-shipments.service';
import { ToastrService } from 'ngx-toastr';

describe('PendingShipmentsComponent', () => {
  let spectator: Spectator<PendingShipmentsComponent>;
  const createComponent = createComponentFactory({
    imports: [
      PendingShipmentsModule,
      ToastrTestingModule,
      NoopAnimationsModule
    ],
    component: PendingShipmentsComponent,
    providers: [
      DEFAULT_TEST_PROVIDERS,
      mockProvider(PendingShipmentsService, MOCKED_PENDING_SHIPMENTS_SERVICE)
    ]
  });

  beforeEach(() => spectator = createComponent());

  it('should render the table and its values properly', () => {
    expect(spectator.query('h1')).toContainText('PENDING_SHIPMENTS.TITLE');
    expect(spectator.query('table th:first-child .checkmark')).toBeVisible();
    expect(spectator.query('table th:nth-child(2)')).toContainText('PENDING_SHIPMENTS.COLUMNS.STATUS');
    expect(spectator.query('table th:nth-child(3)')).toContainText('PENDING_SHIPMENTS.COLUMNS.SHIPMENT_NUMBER');
    expect(spectator.query('tbody td:nth-child(2)')).toContainText(MOCKED_PENDING_SHIPMENTS_RESPONSE[0].shipmentStatus);
    expect(spectator.query('tbody td:nth-child(3)')).toContainText(MOCKED_PENDING_SHIPMENTS_RESPONSE[0].transactionId as string);
    expect(spectator.query('tbody td:nth-child(4)')).toContainText(MOCKED_PENDING_SHIPMENTS_RESPONSE[0].customerReference);
  });

  it('should show the loader when loadingSubject returns true', () => {
    (spectator.component as any).loadingSubject.next(true);
    spectator.detectChanges();
    expect(spectator.query('sail-loader')).toBeVisible();
  });

  it('should retrieve the shipments when the fetchShipmentsSubject emits a value', () => {
    const service = spectator.get(PendingShipmentsService);
    spyOn(service, 'getPendingShipments').and.callThrough();
    (spectator.component as any).fetchShipmentsSubject.next(true);
    expect(service.getPendingShipments).toHaveBeenCalled();
  });

  it('should select all when master selector is clicked', () => {
    const masterSelectorButton = spectator.query('sail-checkbox:first-child input') as HTMLDivElement;
    spectator.click(masterSelectorButton);
    spectator.detectChanges();
    expect(spectator.query('sail-checkbox input:checked')).toBeVisible();
  });

  describe('actions bar', () => {

    beforeEach(() => {
      const masterSelectorButton = spectator.query('sail-checkbox:first-child input') as HTMLDivElement;
      spectator.click(masterSelectorButton);
      spectator.detectChanges();
    });

    it('should show when something is selected', () => {
      expect(spectator.query('.selected-bar')).toBeVisible();
    });

    it('should hide when nothing is selected', () => {
      const masterSelectorButton = spectator.query('sail-checkbox:first-child input') as HTMLDivElement;
      spectator.click(masterSelectorButton);
      spectator.detectChanges();
      expect(spectator.query('.selected-bar')).toBeHidden();
    });

    it('should clear the selection when the cancel button is pressed', () => {
      const cancelButton = spectator.query('.selected-bar button:last-child') as HTMLButtonElement;
      spectator.click(cancelButton);
      spectator.detectChanges();
      expect(spectator.query('.selected-bar')).toBeHidden();
      expect(spectator.component.selection.selected).toHaveLength(0);
    });

    it('should finalize the shipments when the finalize button is pressed', () => {
      const pendingShipmentsService = spectator.get(PendingShipmentsService);
      const toastService = spectator.get(ToastrService);
      spyOn(toastService, 'success').and.callThrough();
      spyOn(pendingShipmentsService, 'getPendingShipments').and.callThrough();
      spyOn(pendingShipmentsService, 'finalizeShipments').and.callThrough();
      spyOn(pendingShipmentsService, 'printShipments').and.callThrough();
      const finalizeButton = spectator.query('.selected-bar button:first-child') as HTMLButtonElement;
      spectator.click(finalizeButton);
      spectator.detectChanges();

      expect(pendingShipmentsService.finalizeShipments).toHaveBeenCalledWith(MOCKED_PENDING_SHIPMENTS_RESPONSE);
      // Should send a success toast
      expect(toastService.success).toHaveBeenCalledWith(
        'PENDING_SHIPMENTS.FINALIZE_SUCCESS.MESSAGE',
        'PENDING_SHIPMENTS.FINALIZE_SUCCESS.TITLE'
      );
      // Should print the labels
      expect(pendingShipmentsService.printShipments).toHaveBeenCalled();
      // Should clear the selection
      expect(spectator.query('.selected-bar')).toBeHidden();
      expect(spectator.component.selection.selected.length).toBe(0);
      // Should fetch the pending shipments again
      expect(pendingShipmentsService.getPendingShipments).toHaveBeenCalled();
    });
  });
});
