// This file is required by karma.conf.js and loads recursively all the .spec and framework files

// tslint:disable:no-import-side-effect

import 'zone.js/dist/zone-testing';

import { getTestBed } from '@angular/core/testing';
import { BrowserDynamicTestingModule, platformBrowserDynamicTesting } from '@angular/platform-browser-dynamic/testing';
import { defineGlobalsInjections } from '@ngneat/spectator';
import { TranslocoModule, TranslocoConfig, TRANSLOCO_CONFIG } from '@ngneat/transloco';

declare const require: any;

const TRANSLOCO_CONFIG_VALUE: TranslocoConfig = {
  availableLangs: ['en'],
  defaultLang: 'en',
  reRenderOnLangChange: false,
  prodMode: true
};

defineGlobalsInjections({
  imports: [TranslocoModule],
  providers: [
    { provide: TRANSLOCO_CONFIG, useValue: TRANSLOCO_CONFIG_VALUE },
  ]
});

// First, initialize the Angular testing environment.
getTestBed().initTestEnvironment(
  BrowserDynamicTestingModule,
  platformBrowserDynamicTesting()
);
// Then we find all the tests.
const context = require.context('./', true, /.spec.ts$/);
// And load the modules.
context.keys().map(context);
