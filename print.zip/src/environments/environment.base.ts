import { Configuration } from '../app/shared/configuration/configuration.model';

function baseConfiguration(
  {
    baseUrl,
    printApiUrl
  }: BaseConfigurationOptions
): Configuration {
  return {

    shipping: {
      fetchPendingShipments: (page: number) => `${baseUrl}/shipments?page=${page}`,
      createShipment: `${baseUrl}/shipments`,
      finalizeShipment: `${baseUrl}/shipments`,
      printShipments: `${printApiUrl}/agent/print`,
      printerDetails: `${printApiUrl}/agent/printers`,
    },
  };
}

type DeepPartial<T> = {
  [P in keyof T]?: DeepPartial<T[P]>;
};

interface BaseConfigurationOptions {
  baseUrl: string;
  printApiUrl: string;
}

export function configuration(
  baseConfigurationOptions: BaseConfigurationOptions,
  overrides: DeepPartial<Configuration>
): Configuration {

  function merge(a: any, b: any): any {
    if (typeof a !== 'object' || typeof b !== 'object' || Array.isArray(a) || Array.isArray(b)) {
      return b;
    }

    const keysA = Object.keys(a);
    const keysB = Object.keys(b);

    return keysA.concat(keysB.filter((key) => keysA.indexOf(key) < 0)).reduce((merged, key) => {

      let value;

      if (keysA.indexOf(key) < 0) {
        value = b[key];
      } else if (keysB.indexOf(key) < 0) {
        value = a[key];
      } else {
        value = merge(a[key], b[key]);
      }

      merged[key] = value;

      return merged;
    }, {} as any);
  }

  return merge(baseConfiguration(baseConfigurationOptions), overrides);
}
