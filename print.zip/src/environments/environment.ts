import { Environment } from './environment.model';
import { configuration } from './environment.base';

export const environment: Environment = {
  production: false,
  configuration: configuration({
    baseUrl: 'https://test.fedex.com/api',
    printApiUrl: 'https://test.fedex.com/print-api'
  }, {})
};
