import { Configuration } from '../app/shared/configuration/configuration.model';

export interface Environment {
  production: boolean;
  configuration: Configuration;
}
