import { Environment } from './environment.model';
import { configuration } from './environment.base';

export const environment: Environment = {
  production: false,
  configuration: configuration({
    baseUrl: 'ngapimock',
    // printApiUrl: 'ngapimock'
    printApiUrl: 'http://localhost:8046'
  }, {})
};
