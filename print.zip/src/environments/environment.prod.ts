import { Environment } from './environment.model';
import { configuration } from './environment.base';

export const environment: Environment = {
  production: true,
  configuration: configuration({
    baseUrl: 'http://localhost:8080',
    printApiUrl: 'http://localhost:8046'
  }, {})
};
