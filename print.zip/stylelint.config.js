module.exports = {
  extends: ['stylelint-config-recommended'],
  rules: {
    'at-rule-no-unknown': [true, {
      ignoreAtRules: [
        'tailwind',
        'apply',
        'variants',
        'responsive',
        'screen'
      ]
    }],
    'selector-type-no-unknown': [true, {
      ignoreTypes: [
        "/^sail-/"
      ]
    }],
    'declaration-block-trailing-semicolon': "always"
  }
};
