/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved *copyright* FedEx 2018
 *
 * Typescript code in this page
 */
import { Component } from '@angular/core';
import { Subscription } from 'rxjs/Subscription';

@Component({
    selector: 'app-filter',
    template: '',
    styles: []
})

export class FilterComponent {

    arrFilter(arrValue: Array<any>, keyValue: string, filterArr: Array<any>): Array<any> {
        if (arrValue) {
            if (arrValue.length > 0) {
                const constVal = arrValue.filter((eachArrVal) => {
                    return filterArr.indexOf(eachArrVal[keyValue]) !== -1;
                });
                return constVal;
            }
        }
    }

    sortByKey(data) {
        return data.sort(function (a, b) {
            const x = a['value'].length;
            const y = b['value'].length;
            return ((x < y) ? 1 : ((x > y) ? -1 : 0));
        });
    }

    callFilter(filterArray: Array<any>, sortInput): Array<any> {
        const sortedArr = this.sortByKey(sortInput);
        for (let i = 0; i < sortedArr.length; i++) {
            filterArray = this.arrFilter(filterArray, sortedArr[i].key, sortedArr[i].value);
        }
        return filterArray;
    }

}
