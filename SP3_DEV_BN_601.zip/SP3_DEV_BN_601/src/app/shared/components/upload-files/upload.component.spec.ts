/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved *copyright* FedEx 2018
 *
 * Typescript code in this page
 */
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { DebugElement } from '@angular/core';

import { UploadComponent } from './upload.component';
import { OverFlowPipe } from 'app/shared/pipes/overFlow.pipe';
import { ConstantsVAR } from 'app/shared/constants/constants-var';
import { emit } from 'cluster';

describe('UploadComponent', () => {
  let component: UploadComponent;
  let fixture: ComponentFixture<UploadComponent>;
  let debugElement: DebugElement;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [UploadComponent, OverFlowPipe]
    })
      .compileComponents();
    fixture = TestBed.createComponent(UploadComponent);
    debugElement = fixture.debugElement;
    fixture.autoDetectChanges();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UploadComponent);
    component = fixture.componentInstance;
    debugElement = fixture.debugElement;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });

  it('show error when user add more than 6 files', () => {
    component.templateFileLength = 6;

    const event = {
      target: {
        files: [
          {
            name: 'Leave & Holiday Policy V4.1_27July18.pdf',
            size: 838907,
            type: 'application/pdf'
          },
          {
            name: 'Leave & Holiday Policy V4.1_27July18.pdf',
            size: 838907,
            type: 'application/pdf'
          },
          {
            name: 'Leave & Holiday Policy V4.1_27July18.pdf',
            size: 838907,
            type: 'application/pdf'
          }, {
            name: 'Leave & Holiday Policy V4.1_27July18.pdf',
            size: 838907,
            type: 'application/pdf'
          }, {
            name: 'Leave & Holiday Policy V4.1_27July18.pdf',
            size: 838907,
            type: 'application/pdf'
          }, {
            name: 'Leave & Holiday Policy V4.1_27July18.pdf',
            size: 838907,
            type: 'application/pdf'
          },
          {
            name: 'Leave & Holiday Policy V4.1_27July18.pdf',
            size: 838907,
            type: 'application/pdf'
          },
          {
            name: 'Leave & Holiday Policy V4.1_27July18.pdf',
            size: 838907,
            type: 'application/pdf'
          }
        ]
      }
    }
    component.fileEvent(event);
    fixture.detectChanges();
    expect(component.fileNumberLimitError).toBe(true);

  });

  it('accept number of pdf files less than 6', () => {
    component.templateFileLength = 6;

    const event = {
      target: {
        files: [
          {
            name: 'Leave & Holiday Policy V4.1_27July18.pdf',
            size: 838907,
            type: 'application/pdf'
          }
        ]
      }
    }
    component.fileEvent(event);
    fixture.detectChanges();
    component.fileDetails.push({
      'id': null,
      'filename': event.target.files[0].name,
      'filesize': (event.target.files[0].size / 1024)
    });

    expect(component.uploadedfiles).not.toBeNull();
  });


  it('show error when size of file name is max 50 char', async () => {
    spyOn(component, 'fileEvent');
    const event = {
      target: {
        files:
        {
          name: 'abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuwxyz.pdf',
          size: 838907,
          type: 'application/pdf'
        }

      }
    }

    component.fileEvent(event);
    fixture.detectChanges();
    expect(component.maximumFileNameSize).toBe(50);
    expect(event.target.files[0].name.length).toBeGreaterThan(50);
    expect(component.maximumFileNameError).toBeTruthy(true);
  })

  it('show error when file type is not pdf', async () => {
    spyOn(component, 'fileEvent');
    const event = {
      target: {
        files:
        {
          name: 'abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuwxyz.doc',
          size: 838907,
          type: 'application/doc'
        }

      }
    }

    component.fileEvent(event);
    fixture.detectChanges();
    const fType = event.target.files[0].name.split('.');
    expect(fType[1]).not.toContain('pdf');
    expect(component.unsupportedFileError).toBe(true);
  });

  it('Upload file when file type is pdf only', async () => {
    spyOn(component, 'fileEvent');
    const event = {
      target: {
        files:
        {
          name: 'abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstu.pdf',
          size: 838907,
          type: 'application/doc'
        }

      }
    }

    component.fileEvent(event);
    fixture.detectChanges();
    const fileType = event.target.files[0].name.split('.');
    expect(fileType[1]).toContain('pdf');
    expect(component.unsupportedFileError).toBe(false);
  });


  it('show error when duplicate file uploading', () => {

    component.templateFileLength = 6;
    component.uploadedfiles = [{
      name: 'Leave & Holiday Policy V4.1_27July18.pdf',
      size: 838907,
      type: 'application/pdf'
    }]

    const event = {
      target: {
        files: [
          {
            name: 'Leave & Holiday Policy V4.1_27July18.pdf',
            size: 838907,
            type: 'application/pdf'
          }
        ]
      }
    }

    component.fileEvent(event);
    fixture.detectChanges();
    expect(component.uploadedfiles).not.toBeNull();
    expect(component.dupFileError).toBe(true);

  });

  it('Upload file when file name is not duplicate',() => {
    component.templateFileLength = 6;
    component.uploadedfiles = [{
      name: 'Leave & Holiday Policy V4.1_27July18.pdf',
      size: 838907,
      type: 'application/pdf'
    }]

    const event = {
      target: {
        files: [
          {
            name: 'abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrst.pdf',
            size: 838907,
            type: 'application/pdf'
          }
        ]
      }
    }

    component.fileEvent(event);
    fixture.detectChanges();

    expect(component.maximumFileNameSize).toBe(50);
    expect(event.target.files[0].name.length).toBe(50);
    expect(component.unsupportedFileError).toBe(false);
    expect(component.dupFileError).toBe(false);

  });

  it('clear/delete file from uploded file list',() => {
    component.templateFileLength = 6;
    component.uploadedfiles = [{
      name: 'Leave & Holiday Policy V4.1_27July18.pdf',
      size: 838907,
      type: 'application/pdf'
    }]

    const event = {
      target: {
        files:[
          {

            name: 'Leave & Holiday Policy V4.1_27July18.pdf',
            size: 838907,
            type: 'application/pdf'
          }]
      }
    }

    component.fileDetails.push({
      'id': null,
      'filename': event.target.files[0].name,
      'filesize': (event.target.files[0].size / 1024)
    });

    component.clearFiles(component.fileDetails[0].filename, component.fileDetails[0]);
    fixture.detectChanges();
    expect(component.dupFileError).toBeFalsy(false)
    expect(component.unsupportedFileError).toBe(false)
    expect(component.fileNumberLimitError).toBe(false)
    expect(component.maximumFileNameError).toBe(false)

  });

  it('should reset all data', () => {
    component.resetAllData();
    fixture.detectChanges();
    expect(component.unsupportedFileError).toBe(false);
    expect(component.dupFileError).toBe(false);
    expect(component.fileExistsError).toBe(false);
    expect(component.fileNumberLimitError).toBe(false);
  });

 it('should show error when file number is more than 6 and file is duplicate',() => {
  component.templateFileLength = 6;
  component.uploadedfiles = [
   
    {
      name: 'dawe.pdf',
     size: 838907,
     type: 'application/pdf'
    }, 
    {
      name: 'hjtot.pdf',
     size: 838907,
     type: 'application/pdf'
    }
]

  const event = {
        target: {
          files: [
            {
              name: 'ab.pdf',
              size: 838907,
              type: 'application/pdf'
            },
            {
              name: 'tyyz.pdf',
              size: 838907,
              type: 'application/pdf'
            },
            {
              name: 'bndrt.pdf',
             size: 838907,
              type: 'application/pdf'
            },
            {
              name: 'sdfg.pdf',
              size: 838907,
              type: 'application/pdf'
            },
            {
              name: 'khk.pdf',
              size: 838907,
             type: 'application/pdf'
            },
            {
              name: 'htdfr.pdf',
             size: 838907,
             type: 'application/pdf'
            },
            {
              name: 'abcdef.pdf',
             size: 838907,
             type: 'application/pdf'
            },
            {
              name: 'abc.pdf',
             size: 838907,
             type: 'application/pdf'
            }, 
            {
              name: 'abcdef.pdf',
             size: 838907,
             type: 'application/pdf'
            }
          ]
        }
      }
 
      component.fileEvent(event);
      fixture.detectChanges();
      expect(component.dupFileError).toBeFalsy();
      expect(component.fileNumberLimitError).toBe(true);
      
});

it('should show error when file name size is more than 50 char', async () => {

  component.uploadedfiles.length = 0;
  component.templateFileLength = 6;
  component.maximumFileNameSize = 50;
  const event = {
    target: {
      files:[
        {

          name: 'aburehfhfghgghghhgbjbgjgrujfghdewuifgsnhdjewtrufooshggbfwefbnfkglpoagdjehfgndmajhetwyudh.pdf',
          size: 838907,
          type: 'application/pdf'
        }]
    }
  }

  component.fileEvent(event);
  fixture.detectChanges();
  expect(component.maximumFileNameError).toBe(true);
 
});

it('should show error when file is not pdf and file is duplicate',() => {

  component.templateFileLength = 6;
  component.uploadedfiles = [{
    name: 'Leave & Holiday Policy V4.1_27July18.pdf',
    size: 838907,
    type: 'application/pdf'
  }]

  const event = {
    target: {
      files:[
        {

          name: 'Leave & Holiday.doc',
          size: 838907,
          type: 'application/pdf'
        }]
    }
  }
 
 
      component.fileEvent(event);
      fixture.detectChanges();

      const fType = event.target.files[0].name.split('.');
      expect(fType[1]).not.toContain('pdf');
      expect(component.unsupportedFileError).toBe(true);
      expect(component.dupFileError).toBeFalsy();
     
  
});

it('show error when file type is not pdf', async () => {

  component.templateFileLength = 6;
  component.uploadedfiles.length = 0;
  const event = {
    target: {
      files:[
        {

          name: 'Leave & Holiday.doc',
          size: 838907,
          type: 'application/pdf'
        }]
    }
  }

  component.fileEvent(event);
  fixture.detectChanges();
  const fType = event.target.files[0].name.split('.');
  expect(fType[1]).not.toContain('pdf');
  expect(component.unsupportedFileError).toBe(true);
});



it('should show error when file name is greater than 50 char and file is duplicate',() => {
  component.templateFileLength = 6;
  component.maximumFileNameSize = 50;
  component.uploadedfiles = [
   
    {
      name: 'dawe.pdf',
     size: 838907,
     type: 'application/pdf'
    }
   
]

  const event = {
        target: {
          files: [
            {
              name: 'aburehfhfghgghghhgbjbgjgrujfghdewuifgsnhdjewtrufooshggbfwefbnfkglpoagdjehfgndmajhetwyudh.pdf',
              size: 838907,
              type: 'application/pdf'
            }
          
          ]
        }
      }
 
      component.fileEvent(event);
      fixture.detectChanges();
      expect(component.dupFileError).toBeFalsy();
      expect(component.maximumFileNameError).toBe(true);
        
});

  it('should emit deleted file array ',() => {
    component.fileDetails = [
      {
       'id':123,
       'filename': 'abcd.pdf',
       'filesize': 8867
   },
   {
    'id':567,
    'filename': 'abcdret.pdf',
    'filesize': 6778
  }

  ];

component.fileDoc.push({
    'fn': component.fileDetails[0].filename
});
component.docDetails.emit(component.fileDoc);
component.clearFiles(component.fileDetails[0].filename, component.fileDetails[0]);
  fixture.detectChanges();
  
  });

});

