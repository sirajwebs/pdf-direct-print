import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BookingExpirationComponent } from './booking-expiration.component';

describe('BookingExpirationComponent', () => {
  let component: BookingExpirationComponent;
  let fixture: ComponentFixture<BookingExpirationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BookingExpirationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BookingExpirationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
