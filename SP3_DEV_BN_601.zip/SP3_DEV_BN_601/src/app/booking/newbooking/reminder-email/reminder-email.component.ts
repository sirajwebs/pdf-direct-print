/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved *copyright* FedEx 2018
 *
 * Typescript code in this page
 */
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-reminder-email',
  templateUrl: './reminder-email.component.html',
  styleUrls: ['./reminder-email.component.css']
})
export class ReminderEmailComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
