import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MessageToSenderComponent } from './message-to-sender.component';

describe('MessageToSenderComponent', () => {
  let component: MessageToSenderComponent;
  let fixture: ComponentFixture<MessageToSenderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MessageToSenderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MessageToSenderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
