/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved (c) FedEx 2018
 *
 * Typescript code in this page
 */

import { FormGroup, FormControl } from '@angular/forms';
import { Component, OnInit, Input, OnDestroy, Output, EventEmitter } from '@angular/core';
import { FORMS } from 'app/shared/constants/forms.properties';
import { SharedataService } from 'app/services/sharedata.service';
import { Subscription } from 'rxjs/Subscription';

@Component({
  selector: 'app-general-section',
  templateUrl: './general-section.component.html',
  styleUrls: ['../create-template.component.css', './general-section.component.css']
})
export class GeneralSectionComponent implements OnInit, OnDestroy {

  @Input() templateDetailsFetch;
  @Output() public generalInfoChange = new EventEmitter<boolean>();

  subscriptions: Array<Subscription> = [];

  showSender = true;
  checkVisiblityError = false;

  readonly FORMS = FORMS;

  generalInfo = new FormGroup({
    paysBy: new FormControl(FORMS.TEMPLATE.PAYSBY.DEFAULT),
    showBookingRef: new FormControl(FORMS.TEMPLATE.SHOW_BKNG_REF.DEFAULT),
    showCustomerRef: new FormControl(FORMS.TEMPLATE.SHOW_CUST_REF.DEFAULT),
    showPrcngEstd: new FormControl(FORMS.TEMPLATE.SHOW_PRICING.DEFAULT),
    generateBookingRef: new FormControl(FORMS.TEMPLATE.GENERATE_BKNG_REF.DEFAULT),
    copyBookingToCustomer: new FormControl(FORMS.TEMPLATE.COPY_BKNG2CUST_REF.DEFAULT),
    shipDateConfirmBy: new FormControl(FORMS.TEMPLATE.SHIP_CONFIRM_BY.DEFAULT),
  });

  constructor(private _shrdt: SharedataService) { }

  ngOnInit() {
    this.sectionsVisibilityOnGeneralFormChange();
  }

  setEditTemplateValues(data) {
    /**
     * patch the template value on loading a edit template page
     */
    this.generalInfo.patchValue({
      paysBy: data.pyr,
      showBookingRef: data.sSidRef,
      showCustomerRef: data.cRFg,
      generateBookingRef: data.gSidReFn,
      copyBookingToCustomer: data.ctRfSmeBkRf,
      shipDateConfirmBy: data.sCnf
    });
  }

  sectionsVisibilityOnGeneralFormChange() {
    this.subscriptions.push(this.generalInfo.valueChanges.subscribe((formVal) => {
      this.onValueChanges();
      this.alterTemplateInteractionsOnFormChange(formVal);
    }));
  }

  onValueChanges() {
    /**
     * get and emit values of template Options data on value change
     */
    Object.keys(this.generalInfo.controls).forEach(key => {
      if (this.generalInfo.get(key).dirty) {
        this.generalInfoChange.emit(true);
      }
    });
  }

  alterTemplateInteractionsOnFormChange(formVal) {
    if (formVal.showBookingRef === false) {
      this.generalInfo.patchValue({
        generateBookingRef: 'false'
      }, { emitEvent: false });
    }
    if (formVal.shipDateConfirmBy === FORMS.TEMPLATE.SHIP_CONFIRM_BY.RECEIVER) {
      this.showSender = false;
    } else {
      this.showSender = true;
    }
    if (formVal.showBookingRef === false &&
      formVal.generateBookingRef === false) {
      this.checkVisiblityError = true;
    } else {
      this.checkVisiblityError = false;
    }

  }

  ngOnDestroy() {
    /**
     * reset datas
     */
    this.subscriptions.forEach((subscription: Subscription) => { subscription.unsubscribe(); });
  }

}
