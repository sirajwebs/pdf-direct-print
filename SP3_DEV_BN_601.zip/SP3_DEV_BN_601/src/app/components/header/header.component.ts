/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved *copyright* FedEx 2018
 *
 * Typescript code in this page
 */
import { CalltokenComponent } from './../../shared/calltoken/calltoken.component';
import { SharedataService } from './../../services/sharedata.service';
import { LoginService } from './../../services/login.service';
import { Component, OnInit, Input, OnChanges, ChangeDetectorRef, OnDestroy, ViewChild } from '@angular/core';
import { Subscription } from 'rxjs/Subscription';
import { ConstantsURL_Others } from './../../shared/constants/constants-urls';
import { SharedFunctionsService } from 'app/services/shared-functions.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css'],
  providers: [SharedFunctionsService]
})

export class HeaderComponent implements OnInit, OnChanges, OnDestroy {

  loggedinUser = '';
  isLoggedIn = false;
  userName: string;
  @Input() noAccount;
  @Input() hideHeaderFooter;
  @ViewChild(CalltokenComponent) public _calltoken: CalltokenComponent;
  subscriptions: Array<Subscription> = [];

  constructor(private _loginService: LoginService,
    private _sharedataService: SharedataService,
    private _shrdFnctns: SharedFunctionsService,
    private _cd: ChangeDetectorRef) {
    /**
     * to check if the user loggedIn to show the header
     */
    this.subscriptions.push(this._sharedataService.isLoggedInSubMsg.subscribe((data) => {
      // TODO, remove this section, optimization / alternative implementations requires
     if (data) {
        this.isLoggedIn = true;
      } else {
        this.isLoggedIn = false;
      }
    }));
  }

  ngOnInit() {
    /**
    * to check if the user loggedIn to show the header and  user details
    */
    window.scrollTo(0, 0);
    this.subscriptions.push(this._sharedataService.loginDetailsMsg.subscribe((loginDetails) => {
      if (loginDetails) {
        if (loginDetails['userProfile']) {
          const uDtls = loginDetails['userProfile'].registeredContactAndAddress.contact.personName;
          this.userName = uDtls.firstName + ' ' + uDtls.lastName;
          this._cd.detectChanges();
          this.isLoggedIn = true;
        } else {
          if (localStorage.getItem('isLoggedIn') === 'true') {
            this.isLoggedIn = false;
            this.logout('');
          }
        }
      }
    }));
  }

  ngOnChanges() {
    /**
     * check if the loggined user has account to use application
     */
    this.subscriptions.push(this._sharedataService.noAccountMsg.subscribe(data => {
      if (data === true) {
        this.noAccount = true;
        localStorage.setItem('noAccount', 'true');
        this._cd.detectChanges();
      } else if (localStorage.getItem('noAccount') === 'true') {
        this.noAccount = true;
        this._cd.detectChanges();
      }
    }));
  }

  appVersion() {
    return ConstantsURL_Others.appVersion;
  }

  navbarClickCkhBookingUrl() {
    this._sharedataService.setSearchInput('');
  }

  logout(flag) {
    /**
     * logout and delete localstorage and navigate back to login
     */
    this.subscriptions.push(this._loginService.logout().subscribe((data) => {
      this.logoutHandling(flag);
    }, error => {
          this.logoutHandling(flag);
    }));
  }

  logoutHandling(flag) {
    this.isLoggedIn = false;
    this._sharedataService.setNoAccount(false);
    this._loginService.deleteAllCookies();
    localStorage.clear();
    sessionStorage.clear();
    sessionStorage.setItem('logoutFlag', flag);
    this._shrdFnctns.windowReload();
  }

  ngOnDestroy() {
    this._cd.detach();
    this.subscriptions.forEach((subscription: Subscription) => { subscription.unsubscribe(); });
  }

}
