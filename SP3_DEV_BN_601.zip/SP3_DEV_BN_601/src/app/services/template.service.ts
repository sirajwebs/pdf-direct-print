/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved (c) Fedex 2018
 *
 * Typescript code in this page
 */
import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/of';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
import 'rxjs/add/observable/throw';
import { ConstantsURL as Constants } from '../shared/constants/constants-urls';
import { BaseService } from './base.service';
import { ConstantsVAR, FedexTNT } from './../shared/constants/constants-var';
import { SharedataService } from './sharedata.service';
import { TemplateBodyDTO } from './../shared/models/template.models';

@Injectable()
export class TemplateService extends BaseService {

  constructor(private _http: Http, private _shrd: SharedataService) { super(); }

  getServiceListDrpdwn(): Observable<any> {
    return this._http
      .get(Constants.CONST_CREATE_TEMPLATE_DROPDOWN_SERVICE_LIST_URL, this.setRequestOptions(ConstantsVAR.ACCESS_TOKEN))
      .map((res) => {
        return this.extractData(res);
      }).catch(this.handleError);
  }

  getPackageListDrpdwn(): Observable<any> {

    // const pkgTyp = this._shrd.isFedexAccount() ? 'F' : 'T';
    const pkgTyp = this._shrd.isFedexAccount() ? FedexTNT.FDX : FedexTNT.TNT;

    return this._http
      .get(Constants.CONST_GET_TEMPLATE_DROPDOWN_PACKAGE_LIST_URL + pkgTyp, this.setRequestOptions(ConstantsVAR.ACCESS_TOKEN))
      .retryWhen(this.handleRetry)
      .map((res) => {
        return this.extractData(res);
      }).catch(this.handleError);
  }

  saveTemplate(requestBody: TemplateBodyDTO, fileVal): Observable<any> {
    return this._http.post(Constants.CONST_CREATE_TEMPLATE_SAVE_TEMPLATE_URL, this.formDataOp(requestBody, fileVal),
    this.setRequestOptions(ConstantsVAR.ACCESS_TOKEN))
      .retryWhen(this.handleRetry)
      .map((res) => {
        return this.extractDataText(res);
      }).catch(this.handleError);
  }

  updateTemplate(requestBody, fileVal): Observable<any> {
    return this._http.post(Constants.CONST_TEMPLATE_CONTEXT +
      Constants.CONST_UPDATE_EDIT_TEMPLATE, this.formDataOp(requestBody, fileVal),
      this.setRequestOptions(ConstantsVAR.ACCESS_TOKEN))
      .retryWhen(this.handleRetry)
      .map((res) => {
        return this.extractDataText(res);
      }).catch(this.handleError);
  }

  getTemplateListDashboard(custAccNo): Observable<any> {
    return this._http.post(Constants.CONST_TEMPLATE_LIST_DASHBOARD_URL, custAccNo,
      this.setRequestOptions(ConstantsVAR.ACCESS_TOKEN))
      .map((res) => {
        return this.extractDataNStatus(res)
      }).catch(this.handleError);
  }

  makeTemplateDefault(requestBody, custAccNo): Observable<any> {
    return this._http.get(Constants.CONST_TEMPLATE_CONTEXT + requestBody.nDtId +
      Constants.CONST_MAKE_TEMPLATE_DEFAULT_URL + custAccNo,
      this.setRequestOptions(ConstantsVAR.ACCESS_TOKEN))
      .map((res) => {
        return this.extractDataText(res)
      }).catch(this.handleError);
  }

  createTemplate(requestBody): Observable<any> {
    return this._http.post(Constants.CONST_TEMPLATE_BASIC_CREATE, requestBody, this.setRequestOptions(ConstantsVAR.ACCESS_TOKEN))
      .map((res) => {
        return this.extractDataText(res)
      }).catch(this.handleError);
  }

  actDeactTemplate(requestBody): Observable<any> {
    return this._http.get(Constants.CONST_TEMPLATE_CONTEXT + requestBody.tId +
      Constants.CONST_ACT_DEACT_TEMPLATE_URL + requestBody.act, this.setRequestOptions(ConstantsVAR.ACCESS_TOKEN))
      .map((res) => {
        return this.extractDataText(res);
      }).catch(this.handleError);
  }

  duplicateTemplate(requestBody): Observable<any> {
    return this._http.get(Constants.CONST_TEMPLATE_CONTEXT + requestBody.refTId +
      Constants.CONST_DUPLICATE_TEMPLATE + requestBody.nTNm,
      this.setRequestOptions(ConstantsVAR.ACCESS_TOKEN))
      .map((res) => {
        return this.extractDataText(res);
      }).catch(this.handleError);
  }

  getTemplateDetails(data): Observable<any> {
    return this._http
      .get(Constants.CONST_FETCH_TEMPLATE_DETAILS_URL + data, this.setRequestOptions(ConstantsVAR.ACCESS_TOKEN))
      .retryWhen(this.handleRetry)
      .map((res) => {
        return this.extractData(res);
      }).catch(this.handleError);
  }

  getDeleteTemplate(val): Observable<any> {
    const getDeleteTemplate = Constants.CONST_TEMPLATE_CONTEXT + val.tId + Constants.CONST_TEMP_DELETE_GET + val.accno;
    return this._http
      .get(getDeleteTemplate, this.setRequestOptions(ConstantsVAR.ACCESS_TOKEN))
      .retryWhen(this.handleRetry)
      .map((res) => {
        return this.extractDataBoolean(res);
      }).catch(this.handleError);
  }

  deleteTemplateNew(id: number, accno): Observable<any> {
    const DeleteTemplate = Constants.CONST_TEMPLATE_CONTEXT + id + Constants.CONST_TEMP_BOOKING_DELETE + accno;
    return this._http
      .delete(DeleteTemplate,
        this.setRequestOptions(ConstantsVAR.ACCESS_TOKEN))
      .retryWhen(this.handleRetry)
      .map((res) => {
        return this.extractDataBoolean(res);
      }).catch(this.handleError);
  }

  checkTemplateName(accNo: string, tmpNm: string): Observable<any> {
    return this._http
      .get(Constants.CONST_CHECK_TEMPLATE_NAME + '?acc_no=' + accNo + '&temp_nm=' + tmpNm,
      this.setRequestOptions(ConstantsVAR.ACCESS_TOKEN))
      .retryWhen(this.handleRetry)
      .map((res) => {
        return this.extractDataText(res);
      }).catch(this.handleError);
  }

  checkTemplateAvailblty(requestBody) {
    return this._http
      .post(Constants.CONST_TEMPLATE_EXISTS, requestBody,
        this.setRequestOptions(ConstantsVAR.ACCESS_TOKEN))
      .map((res) => {
        return this.extractDataText(res);
      }).catch(this.handleError);
  }

  /* setOptions() {
    const headers = new Headers({ 'Authorization': 'Bearer ' + localStorage.getItem(ConstantsVAR.ACCESS_TOKEN) });
    return new RequestOptions({ headers: headers });
  }*/

  formDataOp(requestBody: TemplateBodyDTO, fileVal) { // TODO : set request body type
    const formData = new FormData();
    formData.append('template.json', JSON.stringify(requestBody));
    if (fileVal) {
      for (let i = 0; i < fileVal.length; i++) {
        formData.append('ip.file', fileVal[i]);
      }
    }
    return formData;
  }

}

