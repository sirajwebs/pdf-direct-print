/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved (c) Fedex 2018
 *
 * Typescript code in this page
 */

import { Injectable } from '@angular/core';

@Injectable()
export class JsEncoderService {

  encode(val: string) {
    /**
     * encode given input string to 2 X base64 and return it as string
     */
    const val_e = btoa(val).replace(/=/g, '');
    return btoa(val_e).replace(/=/g, '');
  }

  decode(val: string) {
    /**
     * decode given input string to 2 X base64 and return it as string
     */
    const val_e = atob(val);
    return atob(val_e);
  }

  encodeString(str: string) {
    /**
     * encode given input string with encodeURIComponent to base64 and return it as string
     */
    return window.btoa(encodeURIComponent(str));
  }

  decodeString(str: string) {
    /**
     * encode given input string with decodeURIComponent to base64 and return it as string
     */
    return decodeURIComponent((window.atob(str)));
  }

}
