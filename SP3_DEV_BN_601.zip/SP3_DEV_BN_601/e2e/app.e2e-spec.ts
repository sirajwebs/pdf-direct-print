import { SpiritSourcePage } from './app.po';

describe('spirit-source App', () => {
  let page: SpiritSourcePage;

  beforeEach(() => {
    page = new SpiritSourcePage();
  });

  it('should display welcome message', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('Welcome to app!!');
  });
});
