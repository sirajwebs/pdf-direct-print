/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved *copyright* Fedex 2018
 *
 * Typescript code in this page
 */
import { TokenService } from './../../services/token.service';
import { Component, OnInit, Output, EventEmitter, OnDestroy } from '@angular/core';
import { Subscription } from 'rxjs/Subscription';
import { ConstantsVAR, TokenProperty } from './../constants/constants-var';
import { RetryCallDTO } from '../models/global.models';

@Component({
  selector: 'app-calltoken',
  templateUrl: './calltoken.component.html',
  styleUrls: ['./calltoken.component.css'],
  providers: [TokenService]
})
export class CalltokenComponent implements OnInit, OnDestroy {

  apiSubscription = [];
  subscriptions: Array<Subscription> = [];
  @Output() public emitRetryCall = new EventEmitter<any>();

  constructor(private _tokenSrvce: TokenService) { }

  ngOnInit() { }

  callBaseService(error) {

    /**
     * retry mechanism whenever there is API failure due to token related issue 
     */

    if (typeof error === 'object') {
      error = error.status;
    }

    if ((typeof error === 'undefined' || error === 'undefined' || error === undefined
      || error === ConstantsVAR.API_STATUS_CODE_401 || error === 0) && localStorage.getItem('isLoggedIn') === 'true') {

      const dateAuth = new Date(localStorage.getItem(TokenProperty.OAUTH.GET_TOKEN_CREATED_NAME));
      const creationTimeToken = new Date(dateAuth.setMinutes(dateAuth.getMinutes() + 1)).getTime();

      const dateFdx = new Date(localStorage.getItem(TokenProperty.FEDEX.GET_TOKEN_CREATED_NAME));
      const creationTimeFdxToken = new Date(dateFdx.setMinutes(dateFdx.getMinutes() + 1)).getTime();

      this.checkAndUpdateToken(creationTimeToken, ConstantsVAR.ACCESS_TOKEN_API);
      this.checkAndUpdateToken(creationTimeFdxToken, ConstantsVAR.FEDEX_TOKEN_API);
    }
  }

  checkAndUpdateToken(creationTime, tokenApi) {
    const timeNow = new Date().getTime();
    if (timeNow > creationTime) {
      /**
       * refresh token if it expired the time limit
       */
      const apiName = tokenApi;
      this.apiUnsubscribe(apiName);
      const tknPrprty = this._tokenSrvce.assignTokenCallProperty(tokenApi);

      this.subscriptions.push(this.apiSubscription[apiName] =
        this._tokenSrvce.getToken(tknPrprty.clientID, tknPrprty.clientSecret, tknPrprty.tokenURL).subscribe((data) => {
          if (data) {
            this._tokenSrvce.setToken(tknPrprty, data.access_token);
            return true;
          }
        }));
    }
  }

  apiUnsubscribe(apiName) {
    if (this.apiSubscription[apiName]) { this.apiSubscription[apiName].unsubscribe(); }
  }

  ngOnDestroy() {
    this.subscriptions.forEach((subscription: Subscription) => { subscription.unsubscribe(); });
    Object.keys(this.apiSubscription).forEach(apiName => { this.apiUnsubscribe(apiName); });
  }

  retryServiceCall(error, apiName, data) {
    /**
     * retry service/api call 3 times on failure due to CORS/unauthorised
     */
    if (typeof error === 'object') {
      error = error.status;
    }

    if ((typeof error === 'undefined' || error === 'undefined' || error === undefined
      || error === ConstantsVAR.API_STATUS_CODE_401 || error === ConstantsVAR.API_STATUS_CODE_400 ||
      error === ConstantsVAR.API_STATUS_CODE_403 || error === 0)) {
      const dt: RetryCallDTO = {
        apiName: apiName,
        data: data
      };
      this.emitRetryCall.emit(dt);
    }
  }

}
