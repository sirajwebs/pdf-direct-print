/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved *copyright* FedEx 2018
 *
 * Typescript code in this page
 */
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FilterComponent } from './filter.component';

describe('FilterComponent', () => {
    let component: FilterComponent;
    let fixture: ComponentFixture<FilterComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [FilterComponent]
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(FilterComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should be created', () => {
        expect(component).toBeTruthy();
    });

    it('should call *callFilter* functions to filter array', () => {
        const filterArray =
            [{
                'bId': 1189, 'cNo': null, 'cAccNo': '0510508383', 'bSidNo': 'C1N2BKU88383071619',
                'cRNm': 'C1N2BKU88383071619', 'svcNm': null, 'cCty': 'London', 'cCnty': 'United Kingdom',
                'dCty': 'Atherstone', 'dCnty': 'United Kingdom', 'dDt': null, 'sNm': 'AWAITING COMPLETION',
                'sId': 3, 'colDt': null, 'delvDt': null, 'expDtls': null, 'emlErr': false, 'cDt': '16-07-2019',
                'cnRNm': [], 'booking': null, 'overdue': false
            }, {
                'bId': 1193, 'cNo': null,
                'cAccNo': '0510508383', 'bSidNo': 'IJX3M1JR1313071719', 'cRNm': 'IJX3M1JR1313071719',
                'svcNm': null, 'cCty': 'Berlin', 'cCnty': 'Germany', 'dCty': 'Amsterdam',
                'dCnty': 'Netherlands', 'dDt': null, 'sNm': 'AWAITING COMPLETION', 'sId': 3,
                'colDt': null, 'delvDt': null, 'expDtls': null, 'emlErr': false, 'cDt': '17-07-2019',
                'cnRNm': [], 'booking': null, 'overdue': false
            }, {
                'bId': 1194, 'cNo': null,
                'cAccNo': '0510508383', 'bSidNo': 'XQOGYIFM1313071719', 'cRNm': 'XQOGYIFM1313071719',
                'svcNm': null, 'cCty': 'Berlin', 'cCnty': 'Germany', 'dCty': 'Amsterdam',
                'dCnty': 'Netherlands', 'dDt': null, 'sNm': 'AWAITING COMPLETION', 'sId': 3,
                'colDt': null, 'delvDt': null, 'expDtls': null, 'emlErr': false, 'cDt': '17-07-2019',
                'cnRNm': [], 'booking': null, 'overdue': false
            }]
            , sortInput = [{ key: 'cDt', value: ['25-07-2019'], colm: 'indtN' }];
        component.callFilter(filterArray, sortInput);
        fixture.detectChanges();
    });

    it('should call arrFilter functions to filter array', () => {
        const arrValue = [
            {
                kNm: 'ami'
            },
            {
                kNm: 'tumi'
            },
            {
                kNm: 'se'
            }],
            keyValue = 'kNm',
            filterArr = [
                {
                    kNm: 'ami'
                }];
        component.arrFilter(arrValue, keyValue, filterArr);
        fixture.detectChanges();
    });
});
