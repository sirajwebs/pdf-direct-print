/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved *copyright* FedEx 2018
 *
 * Typescript code in this page
 */
import { AddressFormData } from './addressbook.models';

export interface TemplateListDTO {
    accno?: string;
    def: boolean;
    dt?: string;
    tId: number;
    tNm: string;
    tSts: string;
}

export interface TemplateBodyDTO {
    tNm: string;
    tId: number;
    cAccNo?: number; // remove it later
    pyr: string;
    gSidReFn: boolean;
    ctRfSmeBkRf: boolean;
    sSidRef: boolean;
    cRFg: boolean;
    sPrEs: boolean;
    cnRFg: boolean;
    sCnf: string;
    gDsc: string;
    insV: number;
    insC: string;
    invcV: number | string; // this must be number
    invcC: string;
    svcs: Array<ServicesDTO>;
    pkgs: Array<Packages>;
    adr: Array<AddressFormData>;
    aSCDt: string;
    sSrvs: string;
    aShTm: number | string;
    aPkDm: string;
    defTmp: boolean;
    ptId: number;
    docs: Array<Object>;
    expVal: number;
    cusAccDtls: CustAccDetails;
}

export interface ServicesDTO {
    id: number;
    e: boolean;
    d: boolean;
}

export interface Packages {
    id: number;
    q: number;
    l: string;
    wd: string;
    h: string;
    wg: string;
    enc?: string;
    scale?: string;
}

export interface TemplateAddressDTO {
    cNme: string;
    cPsn: string;
    cd: string;
    cntry: string;
    cty: string;
    e: string;
    l1: string;
    l2: string;
    pCd: string;
    pIn: string;
    tel: string;
    typ: string;
}

export interface SenderOptionsDTO {
    aSCDt: string;
    aPkDm: string;
    sSrvs: string;
    aShTm: string;
}

export interface SenderOptions {
    modifySendRcvDetails: string;
    modifyPkgDetails: string;
    showSenderServices: string;
    enableBookingForward: string;
}

export interface BookingOptionDTO {
    bkngExp: boolean;
}

export interface CustAccDetails {
    cusAccNm: string;
    cusAccId: string;
    accTyp: string;
    ctryCd: string;
}

export interface TemplateType {
    template_type: string;
}

export interface TemplateResponse {
    packageId: number;
    packageNm: string;
}

