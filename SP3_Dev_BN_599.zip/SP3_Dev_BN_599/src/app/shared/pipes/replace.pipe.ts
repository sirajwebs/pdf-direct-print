/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved *copyright* FedEx 2018
 *
 * Typescript code in this page
 */
import { Pipe, PipeTransform } from '@angular/core';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';

@Pipe({ name: 'replaceUnderscore' })
export class ReplaceUnderscore implements PipeTransform {
    constructor(public sanitizer: DomSanitizer) {
    }
    transform(value: string): string {
        if (value) {
            const newValue = value.replace(/_/g, ' ');
            return `${newValue}`;
        }
    }
}
