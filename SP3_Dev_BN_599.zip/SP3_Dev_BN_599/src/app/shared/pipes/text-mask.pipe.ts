/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved *copyright* FedEx 2018
 *
 * Typescript code in this page
 */
import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'textMask'
})
export class TextMaskPipe implements PipeTransform {
  transform(value: string, visibleDigits: number = 4): string {
    if (value) {
      const maskedSection = value.toString().slice(0, -visibleDigits);
      const visibleSection = value.toString().slice(-visibleDigits);
      return maskedSection.replace(/./g, '*') + visibleSection;
    }
  }
}
