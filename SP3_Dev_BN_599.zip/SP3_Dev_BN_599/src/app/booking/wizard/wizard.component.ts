/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved *copyright* FedEx 2018
 *
 * Typescript code in this page
 */
import { ConstantsVAR } from './../../shared/constants/constants-var';
import { SharedataService } from './../../services/sharedata.service';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserAccDetails } from './../../shared/models/login.models';

@Component({
  selector: 'app-wizard',
  templateUrl: './wizard.component.html',
  styleUrls: ['./wizard.component.css']
})
export class WizardComponent implements OnInit {

  firstTimeUser = false;
  showDetails = [false, false, false];
  defaultPage = true;
  accBtnClicked: boolean;
  basicBooking = '';
  accountList: Array<UserAccDetails>;
  selectAccount = new FormGroup({
    accNo: new FormControl('', Validators.required)
  });

  constructor(private _router: Router, private _sharedataService: SharedataService) { }

  ngOnInit() {
    window.scrollTo(0, 0);
    /**
     * get the accounts list to show after selecting the wizard options
     */
    this.setAccountValues();
    /*const accKeyVal = this._jsEcd.decode(localStorage.getItem(ConstantsVAR.ACC_KEY));
    if (accKeyVal) {
      this.accountList = JSON.parse(accKeyVal)['cAccNoLi'];
      this.accountList = [...this.accountList].sort();
    }
    const defAccKeyVal = this._jsEcd.decode(localStorage.getItem(ConstantsVAR.DEF_ACC_KEY));
    if (defAccKeyVal) {
      this.selectAccount.get('accNo').setValue(defAccKeyVal);
    }*/
  }

  createTemplate() {
    this._router.navigate(['/booking/create-template']);
  }

  bkngDetails(z) {
    /**
     * show or hide details
     */
    this.showDetails[z] = !this.showDetails[z];
  }

  continue() {
    /**
     * set the shared subjects data and navigate to the booking page
     */
    this.accBtnClicked = true;
    document.getElementById('REMOVE_MODAL_BACKDROP').click();
    const accountNo = this.selectAccount.get('accNo').value;
    if (accountNo) {
      this.accBtnClicked = true;
      this.defaultPage = true;
      document.getElementById('cancelModal').click();
      if (this.basicBooking === ConstantsVAR.INBOUND) {
        this.getTemplate({ id: ConstantsVAR.INBOUND, accNo: accountNo });
      } else if (this.basicBooking === ConstantsVAR.RETURN) {
        this.getTemplate({ id: ConstantsVAR.RETURN, accNo: accountNo });
      }
      this._router.navigate(['/booking/complete-booking']);
    } else {
      this.selectAccount.get('accNo').markAsTouched();
    }
  }

  close() {
    this.accBtnClicked = false;
    this.defaultPage = true;
    this.setAccountValues();
  }

  returnOrInboundBooking(type) {
     /**
     * check if more than one account present otherwise navigate to continue()
     */
    this.defaultPage = false;
    this.accBtnClicked = false;
    document.getElementById('REMOVE_MODAL_BACKDROP').click();
    this.basicBooking = type;
    if (this.accountList.length === 1) {
      this.selectAccount.patchValue({ 'accNo': this.accountList[0].cusAccId });
      this.continue();
    } else {
      document.getElementById('selectAccountLink').click();
    }
  }

  templateClick() {
    this._sharedataService.setWizardTemp(true);
  }

  getTemplate(templateId) {
    this._sharedataService.setBasicBooking(templateId);
  }

  setAccountValues() { // TODO should be used in shared function
    this.accountList = this._sharedataService.getAccDetails();
    if (!this.accountList) { return; }
    const usrAcc = this.accountList.find(el => el.defAcc === true);
    if (usrAcc) { this.selectAccount.get('accNo').setValue(usrAcc.cusAccId); }
  }

  setCustAcc(val: UserAccDetails) {
    this.selectAccount.get('accNo').setValue(val.cusAccId);
  }
}
