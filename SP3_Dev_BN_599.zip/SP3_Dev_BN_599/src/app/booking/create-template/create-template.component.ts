/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved *copyright* FedEx 2018
 *
 * Typescript code in this page
 */
import { AddressComponent } from './../../shared/components/address/address.component';
import { CalltokenComponent } from './../../shared/calltoken/calltoken.component';
import { PackageWeightsComponent } from './../../shared/components/package-weights/package-weights.component';
import { InsuranceInvoiceComponent } from './../../shared/components/insurance-invoice/insurance-invoice.component';
import { SenderOptionsComponent } from './sender-options/sender-option.component';
import { SharedataService } from 'app/services/sharedata.service';
import { Router } from '@angular/router';
import { EnableServiceComponent } from './enable-service/enable-service.component';
import { Component, OnInit, OnDestroy, ViewChild, ChangeDetectorRef, HostListener } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { TemplateService } from 'app/services/template.service';
import { Subscription } from 'rxjs/Subscription';
import { isNullOrUndefined } from 'util';
import { ConstantsJson, ConstantsVAR, KeyboardKey, FedexTNT, QUERY_PARAMS } from './../../shared/constants/constants-var';
import { BookingOptionsComponent } from './booking-options/booking-options.component';
import { SenderOptionsDTO, TemplateBodyDTO} from './../../shared/models/template.models';
import { FORMS } from 'app/shared/constants/forms.properties';
import { UserAccDetails } from 'app/shared/models/login.models';
import { GeneralSectionComponent } from './general-section/general-section.component';
import { AddressFormData } from 'app/shared/models/addressbook.models';
import { SharedFunctionsService } from 'app/services/shared-functions.service';

@Component({
  selector: 'app-create-template',
  templateUrl: './create-template.component.html',
  styleUrls: ['./create-template.component.css'],
})
export class CreateTemplateComponent implements OnInit, OnDestroy {

  readonly FORMS = FORMS;
  readonly ConstantsVAR = ConstantsVAR;
  subscriptions: Array<Subscription> = [];

  generalInfo = new FormGroup({
    customerAcc: new FormControl({ value: '' , disabled: true}, Validators.required),
    templateName: new FormControl('', [Validators.required]),
    useSenderAddressCheck: new FormControl(),
    useReceiverAddressCheck: new FormControl()
  });

  dupTempForm = new FormGroup({
    duplicateTemplateName: new FormControl('', Validators.required)
  });

  showSections = true;
  collapse_expand: boolean[] = [false];

  getTempDetailsSuccess: boolean;
  getTempDetailsError: boolean;
  templateNm: string;
  templateId: number; // check impact
  addressArray = [];
  errorSaving: boolean;
  fedexContactAddress = [];
  useSenderAddress = false;
  useReceiverAddress = false;
  deleteErrFlg = false;
  FormError = false;

  addressFlagData = JSON.parse(JSON.stringify(ConstantsJson.addressFlagData));

  duplicateTemplateBtnClicked: boolean;
  goodsDesc: string;
  invoiceVal: number;
  invoiceValCurrency: string;
  insuranceVal: number;
  insuranceValCurrency: string;

  templateBody: TemplateBodyDTO;
  // templateBody;
  enableServicesFormData = null; // check***
  packageFormData = null; // check***
  templateDetailsFetch = null; // check***
  tmpltId = '';
  modifySendRcvDetails = ''; // check***
  showSenderServices = ''; // check***
  enableBookingForward: number;
  modifyPkgDetails = ''; // check***
  serviceStatus = '';
  apiSubscription = [];

  gnrlInfoFrmVldtn = null;
  insrInvcFrmVldtn = null;
  enblSrvcFrmVldtn = null;
  packWeighFrmVldtn = null;
  sndrAddrssFrmVldtn = null;
  pckpAddrssFrmVldtn = null;
  dstntnAddrssFrmVldtn = null;
  rcvrAddrssFrmVldtn = null;

  editTempDisableField = false;
  saveBtnClicked = false;
  sndrOptionsData: SenderOptionsDTO;  // check datatype ***
  templateNameConflict: boolean;
  errorSavingTemplate: boolean;
  fileVal = null; // check datatype ***
  fileNm = '';
  insuranceDataEdit = null; // check datatype ***
  pickFlag = false;
  destiFlag = false;

  pickAdresData = {}; // check datatype ***
  sndrAdrData = {}; // check datatype ***
  destiAdresData = {}; // check datatype ***
  rcvrAdrData = {}; // check datatype ***
  defaultTemp = false;
  templateValueChanges = false;
  accountList: Array<UserAccDetails>;
  editFlag = false;
  fileDoc = null; // check***
  tmpNmChkError: boolean;
  tNm = '';
  fromWizard = false;
  closeCancel = 0;
  showModal = [];
  onyes = 0;
  noback = 0;
  templateChanged = 0;

  @ViewChild(CalltokenComponent) public _calltoken: CalltokenComponent;
  @ViewChild(SenderOptionsComponent) public _sndrOptn: SenderOptionsComponent;
  @ViewChild(EnableServiceComponent) public _enblSrvc: EnableServiceComponent;
  @ViewChild(PackageWeightsComponent) public _pckgWght: PackageWeightsComponent;
  @ViewChild(InsuranceInvoiceComponent) public _insrInvc: InsuranceInvoiceComponent;
  @ViewChild('senderAddressBooking') public _sndrAddrssBkng: AddressComponent;
  @ViewChild('pickupAddressBooking') public _pckpAddrssBkng: AddressComponent;
  @ViewChild('receiverAddressBooking') public _rcvrAddrssBkng: AddressComponent;
  @ViewChild('destinationAddressBooking') public _dstntnAddrssBkng: AddressComponent;
  @ViewChild(BookingOptionsComponent) public _bkngOptns: BookingOptionsComponent; // booking option
  @ViewChild(GeneralSectionComponent) public _genSctn: GeneralSectionComponent; // template option

  @HostListener('focusin', ['$event'])
  onFocus(event) {
    this.FormError = false;
  }

  @HostListener('keydown', ['$event'])
  onEscKey(event) {
    if (event.keyCode === KeyboardKey.KEY_ESC && this.closeCancel === 1) {
      this.closeModal();
      if (this.showModal['closeDelete'] === 1) {
        this.timeoutFocus('yes-deleteTemplate', ConstantsVAR.MILISEC_200);
      } else {
        this.changeFocus('cancel');
      }
    }
    if (event.keyCode === KeyboardKey.KEY_ESC && this.onyes === 1) {
      this.closeModal();
      if (this.showModal['closeDelete'] === 1) {
        this.timeoutFocus('yes-deleteTemplate', ConstantsVAR.MILISEC_200);
      } else {
        this.changeFocus('cancel');
      }
      this.onyes = 0;
    }
    if (event.keyCode === KeyboardKey.KEY_ESC && this.showModal['closeDeleteErr'] === 1) {
      this.changeFocus('delete');
      this.showModal['closeDeleteErr'] = 0;
    }
    if (event.keyCode === KeyboardKey.KEY_ESC && this.showModal['closeDelete'] === 1) {
      this.timeoutFocus('delete', ConstantsVAR.MILISEC_200);
      this.showModal['closeDelete'] = 0;
    }
    if (event.keyCode === KeyboardKey.KEY_ESC && this.showModal['closeSaveAsNew'] === 1) {
      this.timeoutFocus('duplicate', ConstantsVAR.MILISEC_200);
      this.showModal['closeSaveAsNew'] = 0;
      this.noback = 0;
    }
    if ((event.shiftKey && event.keyCode === KeyboardKey.KEY_TAB) && this.closeCancel === 1 && this.noback === 1) {
      return false;
    }
    if ((event.shiftKey && event.keyCode === KeyboardKey.KEY_TAB || event.keyCode === KeyboardKey.KEY_TAB)
      && this.showModal['closeDeleteErr'] === 1) {
      return false;
    }
    if ((event.shiftKey && event.keyCode === KeyboardKey.KEY_TAB) &&
      (this.showModal['closeSaveAsNew'] === 1 || this.showModal['closeDelete'] === 1) && this.noback) {
      return false;
    }
  }

  constructor(
    private _template: TemplateService,
    private _router: Router,
    private _shrdt: SharedataService,
    private _cd: ChangeDetectorRef,
    private _shrdFn: SharedFunctionsService
  ) { }

  ngOnInit() {
    /**
     * setting default value for template page validations and options
     */
    Object.freeze(this.FORMS);
    window.scrollTo(0, 0);
    // this.setAccountDetails() // old account set method
    this.setAccountValues();
    this.timeoutFocus('tempName', ConstantsVAR.MILISEC_500);

    this.initiateEditTemplateFetch();

    this.subscriptions.push(this._shrdt.wizardTempMsg.subscribe((data) => {
      if (data) {
        this.fromWizard = true;
      }
    }));

    this.sectionsVisibilityOnGeneralFormChange();

    if (!this.tmpltId) {
      this.generalInfo.get('useSenderAddressCheck').setValue(true);
      this.generalInfo.get('useReceiverAddressCheck').setValue(true);
    }

    this.accountSelectionOnChange();
  }

  initiateEditTemplateFetch() {
    const tID = this._shrdt.getQueryParamsData(QUERY_PARAMS.TEMPLATE_ID);
    this.tmpltId = tID;
    if (tID && !this.getTempDetailsSuccess && !this.getTempDetailsError) {
      this.editTemplateFetch(tID);
    }
  }

  /*  onValueChanges() {
    /**
     * get and emit values of template Options data on value change
      *
      Object.keys(this.generalInfo.controls).forEach(key => {
        if (this.generalInfo.get(key).dirty) {
          this.templateValueChanges = true;
        }
      });
   } */

  alterTemplateInteractionsOnFormChange(formVal) {

    this.templateNm = formVal.templateName;

    if (formVal.useSenderAddressCheck) {
        this.sndrAdrData = this.pickAdresData;
      }

    if (formVal.useReceiverAddressCheck) {
        this.rcvrAdrData = this.destiAdresData;
      }
  }

  accountSelectionOnChange() {
    this.generalInfo.get('customerAcc').valueChanges.subscribe((accVal) => {
      this.assignAccountSelectionType(accVal);
    });
  }

  assignAccountSelectionType(accVal) {
    const prevAccIsFdx = this._shrdt.isFedexAccount();
      if (accVal) {
      const currAccIsFdx = this.isFedex(accVal);
      if (prevAccIsFdx !== currAccIsFdx) {
        if (this.templateValueChanges || this.getTempDetailsSuccess) {
          setTimeout(() => {
            document.getElementById('changeAccLink').click();
          }, ConstantsVAR.MILISEC_200);
        } else {
          this.refreshAllSections(accVal);
      }
  }
        }
      }

  isFedex(accVal: string) {
    const acc = this.accountList.find(el => el.cusAccId === accVal);
    //  return acc.accTyp === FedexTNT.FDX ? true : false;
    return acc.accTyp === FedexTNT.FDX;
      }

  sectionsVisibilityOnGeneralFormChange() {
    this.subscriptions.push(this.generalInfo.valueChanges.subscribe((formVal) => {
      // this.onValueChanges();
      this.alterTemplateInteractionsOnFormChange(formVal);
    }));
  }

  editTemplateFetch(tmpInfo) {
    /**
     * fetch template details from DB , API calls
     */
    this._shrdt.setLoaderSrvc(true);

    const apiName = 'editTemplateFetch';
    this.apiUnsubscribe(apiName);

    this.subscriptions.push(this.apiSubscription[apiName] = this._template.getTemplateDetails(tmpInfo).subscribe(tempdata => {
      this.getTempDetailsSuccess = true;
      this.getTempDetailsError = false;
      this.templateDetailsFetch = tempdata;
      this.templateNm = this.templateDetailsFetch.tNm;
      this.tNm = this.templateDetailsFetch.tNm;
      this.setEditTemplateValues(tempdata);
      this.editFlag = true;
      this.setSndrOptionsData();
      this._shrdt.setLoaderSrvc(false);
      this.templateChanged++;
    }, error => {
      this._shrdt.setLoaderSrvc(false);
      this.getTempDetailsSuccess = false;
      this.getTempDetailsError = true;
      this.retryMechanism(error);
      this._shrdt.templateFetchError(this.getTempDetailsError);
      this._router.navigate(['/booking/templatelist']);
    }));
  }

  setSndrOptionsData() {
    /**
     * set sender options data
     */
    this.sndrOptionsData = {
      'aSCDt': this.templateDetailsFetch.aSCDt,
      'aPkDm': this.templateDetailsFetch.aPkDm,
      'sSrvs': this.templateDetailsFetch.sSrvs,
      'aShTm': this.templateDetailsFetch.aShTm
    };
  }

  ngOnDestroy() {
    /**
     * reset datas
     */
    this._cd.detach();
    this.subscriptions.forEach((subscription: Subscription) => { subscription.unsubscribe(); });
    Object.keys(this.apiSubscription).forEach(apiName => { this.apiUnsubscribe(apiName); });
    this._shrdt.setWizardTemp(false);
    this._shrdt.setSelectedAccountIsFedex(false);
  }

  setEditTemplateValues(data) {
    /**
     * patch the template value on loading a edit template page
     */
    this.generalInfo.patchValue({
      customerAcc: data.cusAccDtls ? data.cusAccDtls.cusAccId : data.cAccNo, // TODO 'cusAccId' to be used when fedex integration is done
      templateName: data.tNm,
    });

    this._genSctn.setEditTemplateValues(data);

    this.setBkngOptionsForEdit(data);
    this.defaultTemp = data.defTmp;
    this.insuranceDataPassEdit(data);
    this.editAddrData(data.adr);
    this.packageFormData = this.templateDetailsFetch.pkgs;
    // delete this.packageFormData['tId'];
    this.templateValueChanges = false;
  }

  setBkngOptionsForEdit(data) {
    if (data.expVal) {
      this._bkngOptns.bookingOptionForm.patchValue({
        showBkngExpr: true,
        bkngExprNoOfDays: data.expVal
      });
    }
    this._bkngOptns.bookingOptionForm.patchValue({ showContentRef: data.cnRFg });
  }

  editAddrData(val) {
    /**
     * address component data populations and validations check ,
     * handling 'copy address' functionality
     */
    this.templateValueChanges = false;
    if (val) {
      for (let i = 0; i < val.length; i++) {
        if (val[i].typ === FORMS.ADDRESS.TYPE.SENDER.ID) {
          this.sndrAdrData = val[i];
          if (!this._cd['destroyed']) {
            this._cd.detectChanges();
          }
          delete this.sndrAdrData['typ'];
        } else if (val[i].typ === FORMS.ADDRESS.TYPE.COLLECTION.ID) {
          this.pickAdresData = val[i];
          if (!this._cd['destroyed']) {
            this._cd.detectChanges();
          }
          delete this.pickAdresData['typ'];
        } else if (val[i].typ === FORMS.ADDRESS.TYPE.RECEIVER.ID) {
          this.rcvrAdrData = val[i];
          if (!this._cd['destroyed']) {
            this._cd.detectChanges();
          }
          delete this.rcvrAdrData['typ'];
        } else if (val[i].typ === FORMS.ADDRESS.TYPE.DELIVERY.ID) {
          this.destiAdresData = val[i];
          if (!this._cd['destroyed']) {
            this._cd.detectChanges();
          }
          delete this.destiAdresData['typ'];
        }
      }

      const sndrProps = Object.getOwnPropertyNames(this.sndrAdrData);
      const pickProps = Object.getOwnPropertyNames(this.pickAdresData);
      const recevProps = Object.getOwnPropertyNames(this.rcvrAdrData);
      const destiProps = Object.getOwnPropertyNames(this.destiAdresData);

      if (sndrProps.length !== pickProps.length) {
        this.generalInfo.get('useSenderAddressCheck').setValue(false, { emitEvent: false });
      }
      if (recevProps.length !== destiProps.length) {
        this.generalInfo.get('useReceiverAddressCheck').setValue(false, { emitEvent: false });
      }

      if (!sndrProps || sndrProps.length === 0) {
        this.generalInfo.get('useSenderAddressCheck').setValue(true, { emitEvent: false });
      }

      if (!recevProps || recevProps.length === 0) {
        this.generalInfo.get('useReceiverAddressCheck').setValue(true, { emitEvent: false });
      }

      for (let j = 0; j < sndrProps.length; j++) {
        const propName = sndrProps[j];
        if (this.sndrAdrData[propName] !== this.pickAdresData[propName]) {
          this.generalInfo.get('useSenderAddressCheck').setValue(false, { emitEvent: false });
          break;
        } else {
          this.generalInfo.get('useSenderAddressCheck').setValue(true, { emitEvent: false });
        }
      }

      for (let k = 0; k < recevProps.length; k++) {
        const recevPropName = recevProps[k];
        if (this.rcvrAdrData[recevPropName] !== this.destiAdresData[recevPropName]) {
          this.generalInfo.get('useReceiverAddressCheck').setValue(false, { emitEvent: false });
          break;
        } else {
          this.generalInfo.get('useReceiverAddressCheck').setValue(true, { emitEvent: false });
        }
      }

      this.sndrAdrData['typ'] = FORMS.ADDRESS.TYPE.SENDER.ID;
      this.destiAdresData['typ'] = FORMS.ADDRESS.TYPE.DELIVERY.ID;
      this.rcvrAdrData['typ'] = FORMS.ADDRESS.TYPE.RECEIVER.ID;
      this.pickAdresData['typ'] = FORMS.ADDRESS.TYPE.COLLECTION.ID;
    }
  }

  boxClose() {
    this.FormError = false;
  }

  getDocDetails(ev) {
    this.fileDoc = ev;
  }

  createTemplate(flag) {
    /**
     * all form dependent component validation on save template
     */
    this.saveBtnClicked = true;

    const gnrlInfoFrmVldtn = this.formValidation();
    this.enblSrvcFrmVldtn = this._enblSrvc.formValidation();
    const bkngOptnsFrmVldtn = this._bkngOptns.formValidations();
    this.insrInvcFrmVldtn = this._insrInvc.formValidation();
    this.packWeighFrmVldtn = this._pckgWght.formValidation();

    const sndrAddrssFrmVldtn = this._sndrAddrssBkng ? this._sndrAddrssBkng.formValidationPattern() : true;
    const pckpAddrssFrmVldtn = this._pckpAddrssBkng ? this._pckpAddrssBkng.formValidationPattern() : true;
    const dstntnAddrssFrmVldtn = this._dstntnAddrssBkng ? this._dstntnAddrssBkng.formValidationPattern() : true;
    const rcvrAddrssFrmVldtn = this._rcvrAddrssBkng ? this._rcvrAddrssBkng.formValidationPattern() : true;

    this.addressArrayCreation();

    if (gnrlInfoFrmVldtn && this.packWeighFrmVldtn && this.insrInvcFrmVldtn && this.enblSrvcFrmVldtn &&
      sndrAddrssFrmVldtn && pckpAddrssFrmVldtn && dstntnAddrssFrmVldtn
      && rcvrAddrssFrmVldtn && bkngOptnsFrmVldtn && this.allFiledsValidation()) {
      this.FormError = false;
      this.createTemplateBody(flag);
    } else {
      this.FormError = true;
    }
  }

  allFiledsValidation() {
    /**
     * duplicate template handling
     */
    if (!this.templateNameConflict) {
      return true;
    } else {
      return false;
    }
  }

  formValidation() {
    /**
     * template page general info form validations
     */
    if (this.generalInfo.invalid) {
      Object.keys(this.generalInfo.controls).forEach(key => {
        if (this.generalInfo.get(key).invalid) {
          this.generalInfo.get(key).markAsTouched();
        }
      });
      return false;
    } else {
      return true;
    }
  }

  insuranceDataPassEdit(data) {
    /**
     * pass data to insut=rance component while loading a template (EDIT)
     */
    this.templateValueChanges = false;
    if (data.insV != null) {
      data.insV = data['insV'].toString();
    }
    this.insuranceDataEdit = {
      'gDsc': data.gDsc,
      'insC': data.insC,
      'insV': data.insV,
      'invcV': data.invcV,
      'invcC': data.invcC
    };
  }


  isFieldRequired(field) {
    return (this.generalInfo.get(field).touched && this.generalInfo.get(field).invalid && this.generalInfo.get(field).hasError('required'));
  }

  fileData(evt) {
    this.fileVal = evt;
  }

  returnBoolean(value) {
    return value ? false : true;
  }

  returnNull(value) {
    return !value ? null : value;
  }

  returnEmptyString(value) {
    return !value ? '' : value;
  }

  createTemplateBody(flag) {
    /**
    * create template request body generation
    */
    this.templateNm = this.generalInfo.get('templateName').value;
    const showBookingRef = this.returnBoolean(!this._genSctn.generalInfo.value.showBookingRef),
    showCustomerRef = this.returnBoolean(!this._genSctn.generalInfo.value.showCustomerRef),
    showEstimatedPrice = this.returnBoolean(!this._genSctn.generalInfo.value.showPrcngEstd),
    showContentRef = this.returnBoolean(!this._bkngOptns.bookingOptionForm.value.showContentRef),
    generateBookingRef = this.returnBoolean(!this._genSctn.generalInfo.value.generateBookingRef),
    copyBookingToCustomer = this.returnBoolean(!this.generalInfo.value.copyBookingToCustomer);

    this.enableServicesFormData = this.returnNull(this.enableServicesFormData);
    this.invoiceVal = this.returnNull(this.invoiceVal);
    this.templateId = this.returnNull(this.tmpltId);

    this.goodsDesc = this.returnEmptyString(this.goodsDesc);
    this.insuranceValCurrency = this.returnEmptyString(this.insuranceValCurrency);
    this.invoiceValCurrency = this.returnEmptyString(this.invoiceValCurrency);

    // to keep zero '0' value and return null for null/undefined
    if (isNullOrUndefined(this.insuranceVal)) {
      this.insuranceVal = null;
    }

    const ptId = this.templateId;
    let updatedDocs = [];
    if (flag === 'DUP') {
      this.templateNm = this.dupTempForm.get('duplicateTemplateName').value;
      this.templateId = null;
      if (this.fileDoc) {
        updatedDocs = this.fileDoc;
      }
    }

    this.templateBody = {
      'tNm': this.templateNm,
      'tId': this.templateId,
      // 'cAccNo': this.generalInfo.get('customerAcc').value, // TODO - to be deleted
      'pyr': this._genSctn.generalInfo.get('paysBy').value,
      'gSidReFn': generateBookingRef,
      'ctRfSmeBkRf': copyBookingToCustomer,
      'sSidRef': showBookingRef,
      'cRFg': showCustomerRef,
      'sPrEs': showEstimatedPrice,
      'cnRFg': showContentRef,
      'sCnf': this._genSctn.generalInfo.get('shipDateConfirmBy').value,
      'gDsc': this.goodsDesc,
      'insC': this.insuranceValCurrency,
      'insV': this.insuranceVal,
      'invcV': this.invoiceVal,
      'invcC': this.invoiceValCurrency,
      'svcs': this.enableServicesFormData,
      'pkgs': this.packageFormData,
      'adr': this.addressArray,
      'aSCDt': this.modifySendRcvDetails,
      'sSrvs': this.showSenderServices,
      'aShTm': this.enableBookingForward,
      'aPkDm': this.modifyPkgDetails,
      'defTmp': this.defaultTemp,
      'ptId': ptId,
      'docs': updatedDocs,
      'expVal': this.expirationDays(),
      'cusAccDtls': this.getSelectedAccDetails()
    };

    if (this.editFlag === true && flag !== 'DUP') {
      this.editSaveTemplate();
    } else {
      if (this.serviceStatus !== 'start' && this.serviceStatus !== 'success') {
        this.createNewTemplate(flag);
      }
    }
  }

  expirationDays() {
    return this._bkngOptns.bookingOptionForm.get('showBkngExpr').value ?
      this._bkngOptns.bookingOptionForm.get('bkngExprNoOfDays').value : null;
  }

  createNewTemplate(flag) {
    /**
     * create new template API call and error handling
     */
    this._shrdt.setLoaderSrvc(true);
    this.errorSaving = false;
    this.serviceStatus = 'start';
    document.getElementById('REMOVE_MODAL_BACKDROP').click();
    const apiName = 'createNewTemplate';
    this.apiUnsubscribe(apiName);

    this.subscriptions.push(this.apiSubscription[apiName] = this._template.saveTemplate(this.templateBody, this.fileVal).subscribe(
      savedata => {
        this._shrdt.setLoaderSrvc(false);
        this.serviceStatus = 'success';
        let tName = this.generalInfo.value.templateName;
        if (flag === 'DUP') {
          tName = this.dupTempForm.get('duplicateTemplateName').value;
          document.getElementById('cancelModal').click();
        }
        let saveSuccessData;
        saveSuccessData = { saveSuccessFlag: true, templateName: tName };
        this._shrdt.changeMessage(saveSuccessData);
        this._router.navigate(['/booking/templatelist']);
      }, error => {
        this._shrdt.setLoaderSrvc(false);
        this.serviceStatus = 'error';
        this.errorSaving = true;
        if (error === ConstantsVAR.API_STATUS_CODE_409) {
          this.templateNameConflict = true;
          this.errorSavingTemplate = false;
        } else {
          this.templateNameConflict = false;
          this.errorSavingTemplate = true;
        }
        this.retryMechanism(error);
      }
    ));
  }

  editSaveTemplate() {
    /**
     * edit and save template API call (update template call)
     */
    if (this.fileDoc) {
      this.templateBody['docs'] = this.fileDoc;
    }
    this.templateBody['tmpSts'] = this.templateDetailsFetch.tmpSts;

    this._shrdt.setLoaderSrvc(true);
    this.errorSaving = false;
    const apiName = 'editSaveTemplate';
    this.apiUnsubscribe(apiName);

    this.subscriptions.push(this.apiSubscription[apiName] = this._template.updateTemplate(this.templateBody, this.fileVal).subscribe(
      savedata => {
        this._shrdt.setLoaderSrvc(false);
        let saveSuccessData;
        const tName = this.generalInfo.value.templateName;
        saveSuccessData = { saveEditSuccessFlag: true, templateName: tName };
        this._shrdt.changeMessage(saveSuccessData);
        this._router.navigate(['/booking/templatelist']);
      }, error => {
        this._shrdt.setLoaderSrvc(false);
        this.errorSaving = true;
        if (error === ConstantsVAR.API_STATUS_CODE_409) {
          this.templateNameConflict = true;
          this.errorSavingTemplate = false;
        } else {
          this.templateNameConflict = false;
          this.errorSavingTemplate = true;
        }
        this.retryMechanism(error);
      }
    ));
  }

  packageData(pkgData) {
    /**
    * event call to receive data from package component
    */
    if (pkgData) {
      if (pkgData.length) {
        this.packageFormData = pkgData;
      }
    }
  }

  formValueChanges(ev) {
    this.templateValueChanges = true;
  }

  enableServiceData(enblSrvcData) {
    /**
    * event call to receive data from service component
    */
    this.enableServicesFormData = enblSrvcData;
  }

  insuranceData(insrData) {
    /**
    * event call to receive data from insurance component
    */
    this.goodsDesc = insrData.goodsDesc;
    this.invoiceVal = insrData.invoiceVal;
    this.invoiceValCurrency = insrData.invoiceValCurrency;
    this.insuranceVal = insrData.insuranceVal;
    this.insuranceValCurrency = insrData.insuranceValCurrency;
  }

  senderOptionData(sndrData) {
    /**
    * event call to receive data from sender option component
    */
    this.modifySendRcvDetails = sndrData.modifySendRcvDetails;
    this.showSenderServices = sndrData.showSenderServices;
    this.enableBookingForward = sndrData.enableBookingForward;
    this.modifyPkgDetails = sndrData.modifyPkgDetails;
  }

  senderAddressData(addrData) {
    /**
    * event call to receive data from sender address
    */
    this.sndrAdrData = addrData;
  }

  pickupAddressData(addrData) {
    /**
    * event call to receive data from pickup address
    */
    this.pickAdresData = addrData;
    if (this.generalInfo.get('useSenderAddressCheck').value) {
      this.sndrAdrData = addrData;
    }
  }

  receiverAddressData(addrData) {
    /**
    * event call to receive data from receiver address
    */
    this.rcvrAdrData = addrData;
  }

  destinationAddressData(addrData) {
    /**
     * event call to receive data from destination address
     */
    this.destiAdresData = addrData;
    if (this.generalInfo.get('useReceiverAddressCheck').value) {
      this.rcvrAdrData = addrData;
    }
  }

  checkAdrNull(data) {
    /**
     * check if any field on address is null or not
     */
    if ((isNullOrUndefined(data.cNme) || (data.cNme === '')) &&
      (isNullOrUndefined(data.cPsn) || (data.cPsn === '')) &&
      (isNullOrUndefined(data.cd) || (data.cd === '')) &&
      (isNullOrUndefined(data.cntry) || (data.cntry === '')) &&
      (isNullOrUndefined(data.cty) || (data.cty === '')) &&
      (isNullOrUndefined(data.e) || (data.e === '')) &&
      (isNullOrUndefined(data.l1) || (data.l1 === '')) &&
      (isNullOrUndefined(data.l2) || (data.l2 === '')) &&
      (isNullOrUndefined(data.pCd) || (data.pCd === '')) &&
      (isNullOrUndefined(data.pIn) || (data.pIn === '')) &&
      (isNullOrUndefined(data.tel) || (data.tel === ''))) {
      return true;
    } else {
      return false;
    }
  }


  createAddrBody(addrData, typ) {
    /**
     * create address request body
     */
    let addressBody: AddressFormData;

    if (isNullOrUndefined(addrData)) {
      addressBody = {
        'cd': '',
        'l1': '',
        'l2': '',
        'cNme': '',
        'cty': '',
        'pCd': '',
        'cntry': '',
        'tel': '',
        'e': '',
        'cPsn': '',
        'pIn': '',
        'vat': '',
        'typ': typ
      };
    } else {
      addressBody = {
        'cd': addrData.cd,
        'l1': addrData.l1,
        'l2': addrData.l2,
        'cNme': addrData.cNme,
        'cty': addrData.cty,
        'pCd': addrData.pCd,
        'cntry': addrData.cntry,
        'tel': addrData.tel,
        'e': addrData.e,
        'cPsn': addrData.cPsn,
        'pIn': addrData.pIn,
        'vat': addrData.vat,
        'typ': typ
      };
    }
    return addressBody;
  }

  addressArrayCreation() {
    /**
     * address data request body creation
     */

    this.addressArray = [];
    this.addressArray.push(
      this.createAddrBody(this.sndrAdrData, FORMS.ADDRESS.TYPE.SENDER.ID),
      this.createAddrBody(this.pickAdresData, FORMS.ADDRESS.TYPE.COLLECTION.ID),
      this.createAddrBody(this.rcvrAdrData, FORMS.ADDRESS.TYPE.RECEIVER.ID),
      this.createAddrBody(this.destiAdresData, FORMS.ADDRESS.TYPE.DELIVERY.ID)
    );
  }

  accordian(sec: number) {
    this.collapse_expand[sec] = !this.collapse_expand[sec];
  }

  checkTempNm(templateNm, flag, event?) {
    /**
     * check for duplicate template name into dashboard before deleting/duplicating
     */
    if (((this.tNm !== templateNm) && flag === 'NEW') || flag === 'DUP') {
      const basicAccNo = this.generalInfo.get('customerAcc').value;
      const apiName = 'checkTempNm';
      this.apiUnsubscribe(apiName);

      this.subscriptions.push(this.apiSubscription[apiName] = this._template.checkTemplateName(basicAccNo, templateNm).subscribe((data) => {
        this.tmpNmChkError = false;
        if (data === 'true') {
          this.templateNameConflict = true;
        } else {
          this.templateNameConflict = false;
        }
        if (flag === 'DUP') {
          if (!this.templateNameConflict) {
            this.createTemplate('DUP');
          }
        }
        if (flag === 'NEW') {
          if (!this.templateNameConflict) {
            try {
              if (event.relatedTarget.className === 'btn-type1') { this.createTemplate('NEW'); }
            } catch (err) { }
          }
        }
      }, error => {
        this.tmpNmChkError = true;
        this.retryMechanism(error);
      }));
    }
  }

  isPatternValid(field) {
    return this.generalInfo.get(field).hasError('pattern') && !this.generalInfo.get(field).hasError('required');
  }

  cancelSaving() {
    /**
     * cancel saving functionality
     */
    document.getElementById('REMOVE_MODAL_BACKDROP').click();
    if (this.templateValueChanges) {
      const cs = document.getElementById('cancelSaving');
      document.getElementById('templateCancelLink').click();
      this.activeModal();
      const chkCs = setInterval(() => {
        if (cs.style.display === 'block') {
          this.changeFocus('no-CancelSaving');
          clearInterval(chkCs);
        }
      }, ConstantsVAR.MILISEC_100)
    } else {
      this.cancelSavingConfirm();
    }
  }

  changeFocus(elementId) {
    try {
      document.getElementById(elementId).focus();
    } catch (e) { }
  }

  closeModal() {
    this.closeCancel = 0;
  }

  activeModal() {
    this.closeCancel = 1;
  }

  isfcs() {
    this.onyes = 1;
    this.noback = 0;
  }

  noBack() {
    this.noback = 1;
  }

  timeoutFocus(ele, time) {
    setTimeout(() => {
      try {
        document.getElementById(ele).focus();
      } catch (e) { }
    }, time);
  }

  closeDeleteErrorModal() {
    this.showModal['closeDeleteErr'] = 0;
    this.timeoutFocus('delete', ConstantsVAR.MILISEC_200);
  }

  closeDeleteModal() {
    this.showModal['closeDelete'] = 0;
    this.timeoutFocus('delete', ConstantsVAR.MILISEC_200);
  }

  dupTmpltBtnFocus() {
    this.noback = this.noback ? 0 : 1;
  }

  cancelSavingConfirm() {
    /**
     * redirection on cancel saving
     */
    if (this.fromWizard) {
      this._router.navigate(['/booking/wizard']);
    } else {
      this._router.navigate(['/booking/templatelist']);
    }
  }

  SaveAsNew() {
    document.getElementById('duplicateTemplateLink').click();
    this.timeoutFocus('duptempName', ConstantsVAR.MILISEC_500);
    this.showModal['closeSaveAsNew'] = 1;
  }

  deleteTemplate() {
    /**
    * delete template  API call to check if template can be deleted or not
    */
    const val = { tId: this.templateDetailsFetch.tId, accno: this.generalInfo.get('customerAcc').value };
    this._shrdt.setLoaderSrvc(true);
    document.getElementById('REMOVE_MODAL_BACKDROP').click();
    const apiName = 'deleteTemplate';
    this.apiUnsubscribe(apiName);

    this.subscriptions.push(this.apiSubscription[apiName] = this._template.getDeleteTemplate(val).subscribe((isSuccess) => {
      if (isSuccess) {
        document.getElementById('deleteTemplateLink').click();
        this.showModal['closeDelete'] = 1;
        this.timeoutFocus('no-deleteTemplate', ConstantsVAR.MILISEC_200);
        this._shrdt.setLoaderSrvc(false);
      }
    }, error => {
      if (error === ConstantsVAR.API_STATUS_CODE_409) {
        this._shrdt.setLoaderSrvc(false);
        document.getElementById('deleteTemplateErrLink').click();
        this.showModal['closeDeleteErr'] = 1;
        this.timeoutFocus('close-deleteTemplateErr', ConstantsVAR.MILISEC_200);
      } else {
        this._shrdt.setLoaderSrvc(false);
        // FAILURE MSG TOASTER
      }
      this.retryMechanism(error);
    }));
  }

  deleteTemplateConfirm() {
    /**
     * delete template confirmation API call and reload the template dashboard data
     */
    this._shrdt.setLoaderSrvc(true);
    const apiName = 'deleteTemplateConfirm';
    this.apiUnsubscribe(apiName);

    this.subscriptions.push(this.apiSubscription[apiName] = this._template.deleteTemplateNew(this.templateDetailsFetch.tId,
      this.generalInfo.get('customerAcc').value).subscribe((isSuccess) => {
        if (isSuccess) {
          this._shrdt.setLoaderSrvc(false);
          this._router.navigate(['/booking/templatelist']);
          this._shrdt.editDeleteMsg(true);
          this._shrdt.setTempDel(this.templateNm);
        } else {
          this._shrdt.setLoaderSrvc(false);
        }
      }, error => {
        this.deleteErrFlg = true;
        this._shrdt.setLoaderSrvc(false);
        this._shrdt.editDeleteMsg(false);
        this.retryMechanism(error);
      }));
  }

  cancelTmpltCopy() {
    /**
     * template copy popup cancel
     */
    this.dupTempForm.get('duplicateTemplateName').markAsTouched();
    this.dupTempForm.get('duplicateTemplateName').reset();
    this.timeoutFocus('duplicate', ConstantsVAR.MILISEC_200);
  }

  duplicateTemplateConfirm() {
    /**
     * duplicate template api call if inputs are valid
     */
    this.duplicateTemplateBtnClicked = true;
    this.dupTempForm.get('duplicateTemplateName').markAsTouched();
    this.templateNm = this.templateDetailsFetch.tNm;
    if (this.dupTempForm.valid) {
      const templateNm = this.dupTempForm.get('duplicateTemplateName').value;
      this.checkTempNm(templateNm, 'DUP');
    }
  }

  addressEmittedData(data, flag) {
    /**
     * copy address data when 'copy address' checkbox is checked
     */
    this.addressFlagData[flag] = data;
    if (this.generalInfo.get('useSenderAddressCheck').value) {
      this.addressFlagData[ConstantsVAR.sndrIdFlg] = this.addressFlagData[ConstantsVAR.pckIdFlg];
    }
    if (this.generalInfo.get('useReceiverAddressCheck').value) {
      this.addressFlagData[ConstantsVAR.rcvrIdFlg] = this.addressFlagData[ConstantsVAR.destIdFlg];
    }
  }

  setAccountValues() {
   // TODO, shared functions
    this.accountList = this._shrdt.getAccDetails();
    if (!this.accountList) { return; }
    const usrAcc = this.accountList.find(el => el.defAcc === true);
    if (usrAcc) { this.generalInfo.get('customerAcc').setValue(usrAcc.cusAccId); }

    this.assignAccountSelectionType(usrAcc.cusAccId);
  }

  setCustAcc(val: UserAccDetails) {
    this.generalInfo.get('customerAcc').setValue(val.cusAccId);
  }

  refreshAllSections(accVal) {
    /**
     * this method will just refresh the show/hide flag to reload the components/sections again
     */
    this._shrdt.setLoaderSrvc(true);
    setTimeout(() => {
      this._shrdt.setLoaderSrvc(false);
    }, ConstantsVAR.MILISEC_1000);

    this._shrdt.setSelectedAccountIsFedex(this.isFedex(accVal));
    this.resetFormsData();
  }

  showSender() {
    return this._genSctn ? this._genSctn.showSender : false;
  }

  getSelectedAccDetails() {
    const usrAcc = this.accountList.find(el => el.cusAccId === this.generalInfo.get('customerAcc').value);
    return this._shrdFn.deleteProp(usrAcc, 'defAcc');
  }

  resetFormsData() {
    this.deleteEditTemplateDEtails();
    this._genSctn.generalInfo.reset();
    setTimeout(() => {
    this._enblSrvc.serviceForm.reset();
    this._sndrOptn.senderOptionForm.reset();
    this._bkngOptns.bookingOptionForm.reset();
      this._pckpAddrssBkng.resetAllData();
      this._sndrAddrssBkng.resetAllData();
      this._dstntnAddrssBkng.resetAllData();
      this._rcvrAddrssBkng.resetAllData();
    this._pckgWght.packageForm.reset();
    this._insrInvc.insuranceForm.reset();

    this.showSections = false;
    setTimeout(() => {
      this.showSections = true;
        this.templateValueChanges = false;
    }, 0);
    }, ConstantsVAR.MILISEC_100);
  }

  deleteEditTemplateDEtails() {
    if (this.getTempDetailsSuccess) {
    this.templateDetailsFetch.pkgs = [];
    this.getTempDetailsSuccess = false;
    this.templateDetailsFetch.svcs = [];
    this.templateDetailsFetch.docs = [];
    this.templateDetailsFetch.adr = [];
    this.templateDetailsFetch.templateServiceEntity = [];
  }
  }

  apiUnsubscribe(apiName: string) {
    if (this.apiSubscription[apiName]) { this.apiSubscription[apiName].unsubscribe(); }
  }

  retryMechanism(error, noBaseAPI?) {
    if (this._calltoken) {
      if (!noBaseAPI) { this._calltoken.callBaseService(error); }
      }
    }

}
