/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved (c) Fedex 2018
 *
 * Typescript code in this page
 */
import { Component, OnInit, EventEmitter, Output, Input, OnChanges, SimpleChanges, OnDestroy } from '@angular/core';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';
import { Subscription } from 'rxjs/Subscription';
import { SenderOptions, SenderOptionsDTO } from './../../../shared/models/template.models';
import { NUMBERS } from './../../../shared/constants/constants-var';

@Component({
  selector: 'app-sender-option',
  templateUrl: './sender-option.component.html',
  styleUrls: ['./sender-option.component.css','./../create-template.component.css']
})

export class SenderOptionsComponent implements OnInit, OnChanges, OnDestroy {
  @Output() public senderOptionData = new EventEmitter<object>();
  @Output() public senderOptChange = new EventEmitter<boolean>();
  @Input() public sndrOptionsData: SenderOptionsDTO;
  public senderOptionForm: FormGroup;
  // senderOptionBody = null; // check***
  senderOptionBody: SenderOptions;
  subscriptions: Array<Subscription> = [];
  maximumDays = Array.from(Array(NUMBERS.FIVE), (element, index) => element = index + NUMBERS.ONE);
  constructor(private _fb: FormBuilder) { }

  ngOnInit() {
    this.senderOptionForm = this._fb.group({
      modifySendRcvDetails: ['true', Validators.required],
      modifyPkgDetails: ['true', Validators.required],
      showSenderServices: ['false', Validators.required],
      enableBookingForward: [NUMBERS.FIVE, Validators.required]
    });
    this.senderOptionCreator(this.senderOptionForm.value);
    this.onValueChanges();
  }

  onValueChanges() {
    /**
     * get and emit values of senderOptions data on value change
     */
    this.subscriptions.push(this.senderOptionForm.valueChanges.subscribe(formData => {
      Object.keys(this.senderOptionForm.controls).forEach(key => {
        if (this.senderOptionForm.get(key).dirty) {
          this.senderOptChange.emit(true);
        }
      });
      this.senderOptionCreator(formData);
    }));
  }

  ngOnChanges(changes: SimpleChanges) {
    this.setSndrOptionsData();
  }

  ngOnDestroy() {
    this.subscriptions.forEach((subscription: Subscription) => { subscription.unsubscribe(); });
  }

  setSndrOptionsData() {
    /**
     * setting up senderOptions data
     */
    if (this.sndrOptionsData) {
      if (this.senderOptionForm) {
        this.setFormValue('modifySendRcvDetails', this.sndrOptionsData.aSCDt); // to be used instead of above if-else
        this.setFormValue('modifyPkgDetails', this.sndrOptionsData.aPkDm); // to be used instead of above if-else
        this.setFormValue('showSenderServices', this.sndrOptionsData.sSrvs); // to be used instead of above if-else
        this.senderOptionForm.patchValue({ enableBookingForward: this.sndrOptionsData.aShTm });
      }
    }
  }

  setFormValue(key: string, value: string) {
    const val = value ? 'true' : 'false';
    this.senderOptionForm.get(key).setValue(val);
  }

  senderOptionCreator(formData: SenderOptions) {
    /**
     * Sender Option body
     */
    this.senderOptionBody = {
      'modifySendRcvDetails': formData.modifySendRcvDetails,
      'modifyPkgDetails': formData.modifyPkgDetails,
      'showSenderServices': formData.showSenderServices,
      'enableBookingForward': formData.enableBookingForward
    };
    this.senderOptionData.emit(this.senderOptionBody);
  }

  formValidation() {
    /**
     * Form validation for sender option
     */
    if (this.senderOptionForm.invalid) {
      Object.keys(this.senderOptionForm.controls).forEach(key => {
        if (this.senderOptionForm.get(key).invalid) {
          this.senderOptionForm.get(key).markAsTouched();
        }
      });
      return false;
    } else {
      return true;
    }
  }


}
