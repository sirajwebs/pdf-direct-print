
/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved (c) Fedex 2018
 *
 * Typescript code in this page
 */
import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { FedexAddressbookService } from './fedex-addressbook.service';
import { JsEncoderService } from './js-encoder.service';
import {
  HttpModule, Http, Response, RequestMethod,
  ResponseOptions, XHRBackend
} from '@angular/http';
import { MockBackend, MockConnection } from '@angular/http/testing';
import { ConstantsURL } from '../shared/constants/constants-urls';
import * as addressBookModel from './../shared/models/addressbook.models';
import { ConstantsVAR } from 'app/shared/constants/constants-var';
import { AddressBookConst } from './../shared/constants/constants-var';

describe('FedexAddressbookService', () => {
  let service: FedexAddressbookService
  let httpMock: HttpTestingController;
  let mockBackend: MockBackend;
  const URL = ConstantsURL;
  const contactId = 94965477;
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, HttpModule],
      providers: [
        JsEncoderService,
        FedexAddressbookService,
        { provide: URL, useValue: URL },
        { provide: MockBackend, useClass: MockBackend },
        { provide: XHRBackend, useExisting: MockBackend }]
    });

    service = TestBed.get(FedexAddressbookService);
    httpMock = TestBed.get(HttpTestingController);
    mockBackend = TestBed.get(MockBackend);

    spyOn(Http.prototype, 'request').and.callThrough();
  });

  afterEach(() => mockBackend.verifyNoPendingRequests());

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('Set address data same as like google', () => {

    const addrsDataconst: addressBookModel.AddressComponentDTO = {
      long_name: 'longName',
      short_name: 'shortname',
      types: ['type']
    }
    const setAddressData = service.setAddressData('longName', 'shortname', 'type');
    expect(setAddressData).toEqual(addrsDataconst);
  });

  it('Should return empty string for null or undefined values', () => {
    const emptyForNull = service.emptyForNull(null);
    expect(emptyForNull).toEqual(ConstantsVAR.EMPTY_STRING);
  });

  it('Should return given value when input is not empty', () => {
    const emptyForNull = service.emptyForNull('abc');
    expect(emptyForNull).toEqual('abc');
  });

  it('Should return Error message on API status - 400 - No contact found', () => {
    const error = {
      _body: '{"errors":[{"code":"CONTACT.NOT.FOUND","message":"No matching contacts found."}]}',
      status: 400
    }
    const apiError = service.apiError(error);
    expect(apiError).toEqual('No matching contacts found.')
  });

  it('Should return Error message on API status - 500 - System Error', () => {
    const error = {
      _body: '{"userMessage":"System Unexpected Error"}',
      status: 500
    }
    const apiError = service.apiError(error)
    expect(apiError).toEqual('System Unexpected Error')
  });

  it('Should return Error message on API status - 403 || 401', () => {
    const error = {
      _body: '{"error":"System Unexpected Error"}',
      status: 403 || 401
    }
    const apiError = service.apiError(error)
    expect(apiError).toEqual(AddressBookConst.APIERROR.MESSAGE)
  });

  it('should get country name from google geocode API - 200', () => {
    const countryCode = 'US';
    const mockResponse = {
      results: [
        {
          address_components: [
            {
              long_name: 'United States',
              short_name: countryCode,
              types: ['country', 'political']
            }
          ]
        }
      ]
    }
    mockBackend.connections.subscribe((connection: MockConnection) => {
      expect(connection.request.url).toBe(URL.GOOGLE_GEOCODE_ROOT_URL + URL.GOOGLE_ROOT_URL_KEY +
        URL.GOOGLE_API_KEY + URL.GOOGLE_GEOCODE_ROOT_URL_COMPONENT + countryCode);
      expect(connection.request.method).toBe(RequestMethod.Get);
      connection.mockRespond(new Response(new ResponseOptions({
        status: 200,
        body: JSON.stringify([mockResponse])
      })));
    });

    service.getCountryFromGoogle(countryCode).subscribe((data) => {
      expect(data).toBeTruthy();
    });
  });

  it('Search Address Book POST success call status 200', () => {
    const searchResponse: addressBookModel.SearchAddressResponse = {
      output: {
        contact: [
          {
            contactName: 'fdsfd',
            nickName: 'a',
            companyName: 'TNT Express',
            address: {
              streetLines: [
                '46, Central Park Drive'
              ],
              city: 'Yandina',
              postalCode: '4561',
              countryCode: 'AU',
              residential: false
            },
            phoneNumber: '7687687',
            addressType: 'RECIPIENT',
            addressBookType: 'PERSONAL',
            contactID: 95079572
          }
        ]
      }
    }
    mockBackend.connections.subscribe((connection: MockConnection) => {
      expect(connection.request.url).toBe(URL.FEDEX_ADDRESS_BOOK.SEARCH);
      expect(connection.request.method).toBe(RequestMethod.Post);
      expect(connection.request.headers.get('Authorization')).toContain('Bearer ');
      connection.mockRespond(new Response(new ResponseOptions({
        status: 200,
        body: JSON.stringify([searchResponse])
      })));
    });

    service.searchAddressBook('TNT', [AddressBookConst.partyType.RECIPIENT]).subscribe((data) => {
      expect(data).toBeTruthy();
    });
  });

  it('Search Address Book POST API Error status 400', () => {

    mockBackend.connections.subscribe((connection: MockConnection) => {
      expect(connection.request.url).toBe(URL.FEDEX_ADDRESS_BOOK.SEARCH);
      expect(connection.request.method).toBe(RequestMethod.Post);
      expect(connection.request.headers.get('Authorization')).toContain('Bearer ');
      connection.mockRespond(new Response(new ResponseOptions({
        status: 400,
      })));
    });

    service.searchAddressBook('TNT EXPRESS sdsdf', [AddressBookConst.partyType.RECIPIENT]).subscribe((data) => {
      expect(data).toBeFalsy();
    });
  });

  it('Save Address Book POST success call status 200', () => {
    const saveAddressObject: addressBookModel.AddressRequestObject = {
      'address': {
        'streetLines': [
          '46, Central Park Drive',
          'line no 2'
        ],
        'city': 'Yandina',
        'postalCode': '4561',
        'countryCode': 'AU',
        'residential': false
      },
      'contact': {
        'nickName': 'yadanajohn',
        'personName': {
          'firstName': 'john',
          'lastName': ''
        },
        'phoneNumberDetails': [
          {
            'type': 'MOBILE',
            'number': {
              'localNumber': '7687687'
            }
          }
        ],
        'companyName': {
          'name': 'TNT Express'
        }
      },
      'deliveryInstructions': 'fdfdsf'
    }
    mockBackend.connections.subscribe((connection: MockConnection) => {
      expect(connection.request.url).toBe(URL.FEDEX_ADDRESS_BOOK.SAVE);
      expect(connection.request.method).toBe(RequestMethod.Post);
      expect(connection.request.headers.get('Authorization')).toContain('Bearer ');
      connection.mockRespond(new Response(new ResponseOptions({
        status: 200,
        body: [saveAddressObject]
      })));
    });

    service.saveAddressBook(saveAddressObject, [AddressBookConst.bookType.PERSONAL]).subscribe((data) => {
      expect(data).toBeTruthy();
    });
  });

  it('Save Address Book POST API Failure status 400 || 500 || 403', () => {
    const saveAddressObject: addressBookModel.AddressRequestObject = {
        'address': {
          'streetLines': [
            '46, Central Park Drive',
            'line no 2'
          ],
          'city': 'Yandina',
          'postalCode': '4561',
          'countryCode': 'AU',
          'residential': false
        },
        'contact': {
          'nickName': 'yadanajohn',
          'personName': {
            'firstName': 'john',
            'lastName': ''
          },
          'phoneNumberDetails': [
            {
              'type': 'MOBILE',
              'number': {
                'localNumber': '7687687'
              }
            }
          ],
          'companyName': {
            'name': 'TNT Express'
          }
        },
        'deliveryInstructions': 'fdfdsf'
      }
      mockBackend.connections.subscribe((connection: MockConnection) => {
        expect(connection.request.url).toBe(URL.FEDEX_ADDRESS_BOOK.SAVE);
        expect(connection.request.method).toBe(RequestMethod.Post);
        expect(connection.request.headers.get('Authorization')).toContain('Bearer ');
        connection.mockRespond(new Response(new ResponseOptions({
          status: 400 || 500 || 403
        })));
      });

    service.saveAddressBook(saveAddressObject, [AddressBookConst.bookType.PERSONAL]).subscribe((data) => {
      expect(data).toBeFalsy();
      }, error => {
      expect(error).toBeTruthy();
    });
  });

  it('Update Address Book PUT success call status 200', () => {
    const updateAddress: addressBookModel.AddressRequestObject = {
      'address': {
        'streetLines': [
          '6334, West Gowen Road',
          ''
        ],
        'city': 'Boise',
        'postalCode': '83709',
        'countryCode': 'US',
        'residential': true
      },
      'contact': {
        'nickName': 'abc6',
        'personName': {
          'firstName': 'john',
          'lastName': 'larke'
        },
        'phoneNumberDetails': [
          {
            'type': 'MOBILE',
            'number': {
              'localNumber': '333356'
            }
          }
        ],
        'companyName': {
          'name': 'TNT Auto Salvage'
        }
      },
      'deliveryInstructions': 'some Instruction'
    }

    mockBackend.connections.subscribe((connection: MockConnection) => {
      expect(connection.request.url).toBe(URL.FEDEX_ADDRESS_BOOK.SAVE + '/' + contactId + '/');
      expect(connection.request.method).toBe(RequestMethod.Put);
      expect(connection.request.headers.get('Authorization')).toContain('Bearer ');
      connection.mockRespond(new Response(new ResponseOptions({
        status: 200,
        body: [updateAddress]
      })));
    });

    service.updateAddressBook(updateAddress, contactId, AddressBookConst.partyType.RECIPIENT).subscribe((data) => {
      expect(data).toBeTruthy();
    });
  });

  it('get Address data from contact id GET success call status 200', () => {
    const getAddress: addressBookModel.GetAddressByContactID = {
      'address': {
        'streetLines': [
          '6334, West Gowen Road',
          ''
        ],
        'city': 'Boise',
        'postalCode': '83709',
        'countryCode': 'US',
        'residential': true
      },
      'contact': {
        'contactId': 94965477,
        'nickName': 'abc6',
        'personName': {
          'firstName': 'john',
          'lastName': 'larke',
          'fullName': 'john larke'
        },
        'phoneNumberDetails': [
          {
            'number': {
              'localNumber': 333356
            }
          }
        ],
        'companyName': {
          'name': 'TNT Auto Salvage'
        }
      },
      'deliveryInstructions': 'some Instruction'
    }
    mockBackend.connections.subscribe((connection: MockConnection) => {
      expect(connection.request.url).toBe(URL.FEDEX_ADDRESS_BOOK.GET + contactId + '/');
      expect(connection.request.method).toBe(RequestMethod.Get);
      expect(connection.request.headers.get('Authorization')).toContain('Bearer ');
      connection.mockRespond(new Response(new ResponseOptions({
        status: 200,
        body: [getAddress]
      })));
    });

    service.getAddressFromContactID(contactId).subscribe((data) => {
      expect(data).toBeTruthy();
    });
  });

  it('get Address data from contact id GET failure call status 500 || 401 || 403', () => {
    mockBackend.connections.subscribe((connection: MockConnection) => {
      expect(connection.request.url).toBe(URL.FEDEX_ADDRESS_BOOK.GET + contactId + '/');
      expect(connection.request.method).toBe(RequestMethod.Get);
      expect(connection.request.headers.get('Authorization')).toContain('Bearer ');
      connection.mockRespond(new Response(new ResponseOptions({
        status: 500 || 403 || 401,
      })));
    });

    service.getAddressFromContactID(contactId).subscribe((data) => {
      expect(data).toBeFalsy();
    }, error => {
      expect(error).toBeTruthy();
    });
  });

  it('get contact email from contact id GET success call status 200', () => {
    const getEmail: addressBookModel.GetEmailResponse = {
      'output': {
        'shipPartyPreference': {
            'contactId': 94965477,
            'notifications': [
                {
                    'receivers': [
                        {
                            'notificationReceiverType': 'RECIPIENT',
                            'medias': [
                                {
                                    'emailAddresses': [
                                        {
                                            'address': 'testing@fedex.com',
                                        }
                                    ]
                                }
                            ]
                        }
                    ]
                }
            ]
        }
    }
    }

    mockBackend.connections.subscribe((connection: MockConnection) => {
      expect(connection.request.url).toBe(URL.FEDEX_ADDRESS_BOOK.EMAIL.URL + contactId + URL.FEDEX_ADDRESS_BOOK.EMAIL.PREFERENCES);
      expect(connection.request.method).toBe(RequestMethod.Get);
      expect(connection.request.headers.get('Authorization')).toContain('Bearer ');
      connection.mockRespond(new Response(new ResponseOptions({
        status: 200,
        body: [getEmail]
      })));
    });

    service.getContactEmail(contactId).subscribe((data) => {
      expect(data).toBeTruthy();
    });
  });

  it('get contact email from contact id GET failure call status 500 || 401 || 403 ', () => {

    mockBackend.connections.subscribe((connection: MockConnection) => {
      expect(connection.request.url).toBe(URL.FEDEX_ADDRESS_BOOK.EMAIL.URL + contactId + URL.FEDEX_ADDRESS_BOOK.EMAIL.PREFERENCES);
      expect(connection.request.method).toBe(RequestMethod.Get);
      expect(connection.request.headers.get('Authorization')).toContain('Bearer ');
      connection.mockRespond(new Response(new ResponseOptions({
        status: 500 || 401 || 403
      })));
    });

    service.getContactEmail(contactId).subscribe((data) => {
      expect(data).toBeFalsy();
    }, error => {
      expect(error).toBeTruthy();
    });
  });

  it('update contact email from contact id PUT success call status 200', () => {
    const email = 'test@test.com';
    const putEmail: addressBookModel.UpdateEmailRequest = {
      'shipPartyPreference': {
        'contactId': contactId,
        'notifications': [
            {
                'receivers': [
                    {
                        'notificationReceiverType': 'RECIPIENT',
                        'medias': [
                            {
                                'emailAddresses': [
                                    {
                                        'address': email
                                    }
                                ]
                            }
                        ]
                    }
                ]
            }
        ]
    }
    }

    mockBackend.connections.subscribe((connection: MockConnection) => {
      expect(connection.request.url).toBe(URL.FEDEX_ADDRESS_BOOK.EMAIL.URL + contactId + URL.FEDEX_ADDRESS_BOOK.EMAIL.PREFERENCES);
      expect(connection.request.method).toBe(RequestMethod.Put);
      expect(connection.request.headers.get('Authorization')).toContain('Bearer ');
      connection.mockRespond(new Response(new ResponseOptions({
        status: 200,
        body: [putEmail]
      })));
    });

    service.updateContactEmail(contactId, email).subscribe((data) => {
      expect(data).toBeTruthy();
    });
  });

  it('update contact email from contact id PUT failure call status 401 || 400 || 500 || 403', () => {
    const email = 'test@test.com';
    mockBackend.connections.subscribe((connection: MockConnection) => {
      expect(connection.request.url).toBe(URL.FEDEX_ADDRESS_BOOK.EMAIL.URL + contactId + URL.FEDEX_ADDRESS_BOOK.EMAIL.PREFERENCES);
      expect(connection.request.method).toBe(RequestMethod.Put);
      expect(connection.request.headers.get('Authorization')).toContain('Bearer ');
      connection.mockRespond(new Response(new ResponseOptions({
        status: 400 || 401 || 500 || 403
      })));
    });

    service.updateContactEmail(contactId, email).subscribe((data) => {
      expect(data).toBeFalsy();
    }, error => {
      expect(error).toBeTruthy();
    });
  });

  it('should fetch address book type from privilege and retun an array', () => {
    const addrObject = {
      personalCtrl : true,
      centralView: true
    }
    const responseArray = [AddressBookConst.bookType.PERSONAL, AddressBookConst.bookType.CENTRAL]
    const addrRes = service.fetchAddrBkTypeFrmPrvlg(addrObject);
    expect(JSON.stringify(addrRes)).toEqual(JSON.stringify(responseArray));
  });

  it('should return company Id', () => {
    const result = service.getCompanyId();
    expect(result).toBe(false)
  });
});
