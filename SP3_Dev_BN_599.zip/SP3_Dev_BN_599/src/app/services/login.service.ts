/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved *Copyright* Fedex 2018
 *
 * Typescript code in this page
 */
import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import 'rxjs/add/operator/toPromise';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/of';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
import 'rxjs/add/observable/throw';
import { ConstantsURL as Constants } from '../shared/constants/constants-urls';
import { BaseService } from './base.service';
import { LoginResponseV2, LoginRequestV2, AssociatedAccResponse } from './../shared/models/login.models';
import { ConstantsVAR } from './../shared/constants/constants-var';

@Injectable()

export class LoginService extends BaseService {
    constructor(private _http: Http) {
        super();
    }

    postLogin(loginbody): Observable<LoginResponseV2> {
       const loginRequest: LoginRequestV2 = {
            userName: loginbody.user,
            password: loginbody.pass
        };
        return this._http
            .post(Constants.CONST_LOGIN + Constants.CONST_LOGIN_V2, loginRequest, this.setRequestOptions(ConstantsVAR.FEDEX_TOKEN))
            .map((res) => {
                return this.extractData(res);
            }).catch(this.handleErrorAll);
    }

    logout() {
        return this._http
            .put(Constants.CONST_LOGIN + Constants.CONST_LOGOUT_V1, '', this.setRequestOptions(ConstantsVAR.FEDEX_TOKEN))
            .retry(1)
            .map((res) => {
                return this.extractData(res);
            }).catch(this.handleErrorAll);
    }

    actc(data):Observable<AssociatedAccResponse> {
        return this._http
            .post(Constants.CONST_LOGIN + Constants.CONST_LOGIN_ACTC, data, this.setRequestOptions(ConstantsVAR.FEDEX_TOKEN))
            .retry(1)
            .map((res) => {
                return this.extractData(res);
            }).catch(this.handleError);
    }

    deleteAllCookies() {
        /**
         * delete all cookies except the LAST ACTIVE ACCOUNT
         */
        const cookies = document.cookie.split(';');
        let value;
        for (let i = 0; i < cookies.length; i++) {
            const cookie = cookies[i];
            const eqPos = cookie.indexOf('=');
            const name = eqPos > -1 ? cookie.substr(0, eqPos) : cookie;
            if (name === ConstantsVAR.LAST_ACTIVE_ACCOUNT) {
                value = cookie.substr(eqPos + 1, cookie.length);
            }
            document.cookie = cookie + '=;expires=Thu, 01 Jan 1970 00:00:00 GMT';
            if (i === cookies.length - 1) {
                document.cookie = ConstantsVAR.LAST_ACTIVE_ACCOUNT + '=' + value;
            }
        }
    }
}
