/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved (c) Fedex 2018
 *
 * Typescript code in this page
 */
import { TestBed, inject } from '@angular/core/testing';
import { SharedFunctionsService } from './shared-functions.service';
import { ConstantsVAR, DateConstants } from './../shared/constants/constants-var';

describe('SharedFunctionsService', () => {
  let service: SharedFunctionsService;
  const dateVal = 'Tue Jun 25 2019 07:31:23:641 GMT+0530 (India Standard Time)';
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [SharedFunctionsService]
    });
    service = TestBed.get(SharedFunctionsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should return date in JSON format', () => {
    const returnDate = service.getDateInJson(dateVal);
    expect(returnDate).toBe('2019-06-25T07:31:23.641Z');
  });

  it('should return only date', () => {
    const returnDate = service.getOnlyDate(dateVal);
    expect(returnDate).toBe('2019-06-25');
  });

  it('should return only time in hour(s) and minute(s)', () => {
    const returnDate = service.getOnlyTimeInHourMinutes(dateVal);
    expect(returnDate).toBe('07:31');
  });

  it('should append zero (0) when number is less than 10 and return', () => {
    const value = 8;
    const resultValue = service.appendZeroToVal(value);
    expect(resultValue).toBe('08');
  });

  it('should return actual number when number is greater than 10', () => {
    const value = 11;
    const resultValue = service.appendZeroToVal(value);
    expect(resultValue).toBe(11);
  });

  it('should return Date Object in user readble format', () => {
    const returnDate = service.convertDateToUserFormat(dateVal);
    expect(returnDate).toBe('Tuesday, June 25 2019');
  });

  it('should return Date based on timezone', () => {
    const dateObject = {
      dstOffset: 0,
      rawOffset: 19800 // timezone is Asia / Calcutta
    }
    const returnDate = service.getDateFromTimezone(dateObject);
    // expect(returnDate).toBe(new Date(dateVal));
  });

  it('should format date', () => {
   const val = 'Tuesday, June 25 2019';
   const resultValue = service.formatDate(val);
   expect(resultValue).toBe('2019-06-25T00:00:00.000Z');
  });

  it('should return true for same day if date are equal', () => {
   const d1 = new Date(dateVal);
   const d2 = new Date(dateVal);
   const resultValue = service.sameDay(d1, d2);
   expect(resultValue).toBe(true);
  });

  it('should return false for same day if date are not equal', () => {
   const d1 = new Date(dateVal);
   const d2 = new Date('Wed Jun 26 2019 07:31:23:641 GMT+0530 (India Standard Time)');
   const resultValue = service.sameDay(d1, d2);
   expect(resultValue).toBe(false);
  });

  it('should return true when object is null', () => {
    const obj = {
      abc : null,
      def: null
    }

    const returnValue = service.checkObjectProprtsForNull(obj);
    expect(returnValue).toBe(true);
  });
});
